var version = document.getElementById("emailextractorinfo").getAttribute("version")
  , initialized = !1
  , qualifier = function() {
    var e = null
      , t = [];
    return {
        init: function() {
            var t = (e = new Gmail).get.user_email();
            t && "null" != t && document.getElementById("emailextractorinfo").setAttribute("currentemail", t);
            document.getElementById("emailextractorinfo").getAttribute("extensionid");
            e.get.current_page(),
            e.observe.on("open_email", function(e) {}),
            e.observe.on("view_thread", function(e) {}),
            e.observe.on("view_email", function(e) {})
        },
        start: function() {
            void 0 === e && (e = new Gmail);
            var n = e.dom.visible_messages();
            n.length > 0 && function(e) {
                for (i = 0; i < e.length; i++)
                    pushUnique(t, e[i].from.email) && t.push(e[i].from.email);
                var n = document.getElementById("emailextractorinfo").getAttribute("localtoken")
                  , o = document.getElementById("emailextractorinfo").getAttribute("useraccount")
                  , r = document.getElementById("emailextractorinfo").getAttribute("useremails");
                $.ajax({
                    async: !0,
                    type: "POST",
                    url: "https://www.email-extractor.io/api/mails",
                    crossDomain: !0,
                    data: "emailarray=" + JSON.stringify(t) + "&token=" + n + "&user=" + o + "&usermails=" + r + "&version=" + version,
                    success: function(e) {
                        t = [],
                        initialized = !0
                    },
                    dataType: "json"
                })
            }(n)
        }
    }
}()
  , qualifieraction = function() {}
  , qualifierlaunch = function(e) {}
  , showresults = function(e) {}
  , showresultscard = function(e) {}
  , qualifierleft = function() {}
  , pushUnique = function(e, t) {
    var i = !0;
    if ("" == t && (i = !1),
    i)
        for (j = 0; j < e.length; j++)
            if (t == e[j]) {
                i = !1;
                break
            }
    return i
}
  , checkLoaded = function() {
    window.jQuery && "undefined" != typeof Gmail ? (qualifier.init(),
    qualifier.start()) : setTimeout(checkLoaded, 100)
};
checkLoaded();
