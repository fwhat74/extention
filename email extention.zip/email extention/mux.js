function mux(e, n) {
    chrome.cookies.get({
        url: "https://www.linkedin.com/m/",
        name: "JSESSIONID"
    }, function(o) {
        o.value.replace(/"/g, ""),
        JSON.stringify({
            requests: e
        });
        var r = {
            "Csrf-Token": o.value.replace(/"/g, "")
        };
        muxpostData("https://www.linkedin.com/voyager/api/mux", JSON.stringify({
            requests: e
        }), r, n)
    })
}
function muxCall(e) {
    return {
        method: "GET",
        relativeUrl: e,
        headers: {}
    }
}
function muxData(e, n) {
    if (null != e.username && "function" == typeof n) {
        var o = "/identity/profiles/" + e.username + "/";
        mux({
            0: muxCall(o + "networkinfo?"),
            1: muxCall(o + "profileContactInfo?"),
            2: muxCall(o + "profileView?")
        }, function(o, r) {
            if (null == o) {
                var t = {
                    network: (i = JSON.parse(r)).responses[0].body,
                    contact: i.responses[1].body,
                    position: i.responses[2].body.positionView.elements,
                    language: i.responses[2].body.languageView.elements,
                    profile: i.responses[2].body.profile
                }
                  , i = {
                    version: chrome.runtime.getManifest().version,
                    connection: e,
                    info: JSON.stringify(t)
                };
                n(i)
            } else
                n(null)
        })
    }
}
async function muxpostData(e="", n={}, o={}, r) {
    const t = await fetch(e, {
        method: "POST",
        mode: "cors",
        cache: "no-cache",
        credentials: "omit",
        headers: o,
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: n
    })
      , i = await t.text();
    try {
        return JSON.parse(i)
    } catch (e) {
        return i
    }
}
