"object" != typeof JSON && (JSON = {}),
function() {
    "use strict";
    function f(e) {
        return e < 10 ? "0" + e : e
    }
    var cx, escapable, gap, indent, meta, rep;
    function quote(e) {
        return escapable.lastIndex = 0,
        escapable.test(e) ? '"' + e.replace(escapable, function(e) {
            var t = meta[e];
            return "string" == typeof t ? t : "\\u" + ("0000" + e.charCodeAt(0).toString(16)).slice(-4)
        }) + '"' : '"' + e + '"'
    }
    function str(e, t) {
        var n, r, i, o, s, a = gap, u = t[e];
        switch (u && "object" == typeof u && "function" == typeof u.toJSON && (u = u.toJSON(e)),
        "function" == typeof rep && (u = rep.call(t, e, u)),
        typeof u) {
        case "string":
            return quote(u);
        case "number":
            return isFinite(u) ? String(u) : "null";
        case "boolean":
        case "null":
            return String(u);
        case "object":
            if (!u)
                return "null";
            if (gap += indent,
            s = [],
            "[object Array]" === Object.prototype.toString.apply(u)) {
                for (o = u.length,
                n = 0; n < o; n += 1)
                    s[n] = str(n, u) || "null";
                return i = 0 === s.length ? "[]" : gap ? "[\n" + gap + s.join(",\n" + gap) + "\n" + a + "]" : "[" + s.join(",") + "]",
                gap = a,
                i
            }
            if (rep && "object" == typeof rep)
                for (o = rep.length,
                n = 0; n < o; n += 1)
                    "string" == typeof rep[n] && (i = str(r = rep[n], u)) && s.push(quote(r) + (gap ? ": " : ":") + i);
            else
                for (r in u)
                    Object.prototype.hasOwnProperty.call(u, r) && (i = str(r, u)) && s.push(quote(r) + (gap ? ": " : ":") + i);
            return i = 0 === s.length ? "{}" : gap ? "{\n" + gap + s.join(",\n" + gap) + "\n" + a + "}" : "{" + s.join(",") + "}",
            gap = a,
            i
        }
    }
    "function" != typeof Date.prototype.toJSON && (Date.prototype.toJSON = function() {
        return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + f(this.getUTCMonth() + 1) + "-" + f(this.getUTCDate()) + "T" + f(this.getUTCHours()) + ":" + f(this.getUTCMinutes()) + ":" + f(this.getUTCSeconds()) + "Z" : null
    }
    ,
    String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function() {
        return this.valueOf()
    }
    ),
    "function" != typeof JSON.stringify && (escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
    meta = {
        "\b": "\\b",
        "\t": "\\t",
        "\n": "\\n",
        "\f": "\\f",
        "\r": "\\r",
        '"': '\\"',
        "\\": "\\\\"
    },
    JSON.stringify = function(e, t, n) {
        var r;
        if (gap = "",
        indent = "",
        "number" == typeof n)
            for (r = 0; r < n; r += 1)
                indent += " ";
        else
            "string" == typeof n && (indent = n);
        if (rep = t,
        t && "function" != typeof t && ("object" != typeof t || "number" != typeof t.length))
            throw new Error("JSON.stringify");
        return str("", {
            "": e
        })
    }
    ),
    "function" != typeof JSON.parse && (cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
    JSON.parse = function(text, reviver) {
        var j;
        function walk(e, t) {
            var n, r, i = e[t];
            if (i && "object" == typeof i)
                for (n in i)
                    Object.prototype.hasOwnProperty.call(i, n) && (void 0 !== (r = walk(i, n)) ? i[n] = r : delete i[n]);
            return reviver.call(e, t, i)
        }
        if (text = String(text),
        cx.lastIndex = 0,
        cx.test(text) && (text = text.replace(cx, function(e) {
            return "\\u" + ("0000" + e.charCodeAt(0).toString(16)).slice(-4)
        })),
        /^[\],:{}\s]*$/.test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, "")))
            return j = eval("(" + text + ")"),
            "function" == typeof reviver ? walk({
                "": j
            }, "") : j;
        throw new SyntaxError("JSON.parse")
    }
    )
}(),
function() {
    var e, t = "StripeCheckout.require".split("."), n = t[t.length - 1], r = this;
    for (e = 0; e < t.length - 1; e++)
        r = r[t[e]] = r[t[e]] || {};
    void 0 === r[n] && (r[n] = function() {
        var e = {}
          , t = {}
          , n = function(e, t) {
            for (var n, r, i = [], o = 0, s = (n = /^\.\.?(\/|$)/.test(t) ? [e, t].join("/").split("/") : t.split("/")).length; o < s; o++)
                ".." == (r = n[o]) ? i.pop() : "." != r && "" != r && i.push(r);
            return i.join("/")
        }
          , r = function(e) {
            return e.split("/").slice(0, -1).join("/")
        }
          , i = function(o) {
            return function(o, s) {
                var a, u, c = n(s, o), l = n(c, "./index");
                if (a = t[c] || t[l])
                    return a;
                if (u = e[c] || e[c = l])
                    return a = {
                        id: c,
                        exports: {}
                    },
                    t[c] = a.exports,
                    u(a.exports, function(e) {
                        return i(e, r(c))
                    }, a),
                    t[c] = a.exports;
                throw "module " + o + " not found"
            }(o, "")
        };
        return i.define = function(t) {
            for (var n in t)
                e[n] = t[n]
        }
        ,
        i.modules = e,
        i.cache = t,
        i
    }
    .call())
}(),
StripeCheckout.require.define({
    "vendor/cookie": function(e, t, n) {
        var r = {}
          , i = /\+/g;
        function o(e, t) {
            for (var n in e = e || {},
            t)
                "object" == typeof source[n] ? e[n] = o(e[n], source[n]) : e[n] = source[n];
            return e
        }
        function s(e) {
            return e
        }
        function a(e) {
            return decodeURIComponent(e.replace(i, " "))
        }
        function u(e) {
            0 === e.indexOf('"') && (e = e.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\"));
            try {
                return c.json ? JSON.parse(e) : e
            } catch (e) {}
        }
        var c = r.set = r.get = function(e, t, n) {
            if (void 0 !== t) {
                if ("number" == typeof (n = o(n, c.defaults)).expires) {
                    var r = n.expires
                      , i = n.expires = new Date;
                    i.setDate(i.getDate() + r)
                }
                return t = c.json ? JSON.stringify(t) : String(t),
                document.cookie = [c.raw ? e : encodeURIComponent(e), "=", c.raw ? t : encodeURIComponent(t), n.expires ? "; expires=" + n.expires.toUTCString() : "", n.path ? "; path=" + n.path : "", n.domain ? "; domain=" + n.domain : "", n.secure ? "; secure" : ""].join("")
            }
            for (var l = c.raw ? s : a, p = document.cookie.split("; "), h = e ? void 0 : {}, f = 0, d = p.length; f < d; f++) {
                var m = p[f].split("=")
                  , g = l(m.shift())
                  , y = l(m.join("="));
                if (e && e === g) {
                    h = u(y);
                    break
                }
                e || (h[g] = u(y))
            }
            return h
        }
        ;
        c.defaults = {},
        r.remove = function(e, t) {
            return void 0 !== r.get(e) && (r.set(e, "", o(t, {
                expires: -1
            })),
            !0)
        }
        ,
        n.exports = r
    }
}),
StripeCheckout.require.define({
    "vendor/ready": function(e, t, n) {
        !function(e, t) {
            void 0 !== n ? n.exports = t() : "function" == typeof define && "object" == typeof define.amd ? define(t) : this.domready = t()
        }(0, function(e) {
            var t, n = [], r = document, i = r.documentElement, o = i.doScroll, s = (o ? /^loaded|^c/ : /^loaded|c/).test(r.readyState);
            function a(e) {
                for (s = 1; e = n.shift(); )
                    e()
            }
            return r.addEventListener && r.addEventListener("DOMContentLoaded", t = function() {
                r.removeEventListener("DOMContentLoaded", t, !1),
                a()
            }
            , !1),
            o && r.attachEvent("onreadystatechange", t = function() {
                /^c/.test(r.readyState) && (r.detachEvent("onreadystatechange", t),
                a())
            }
            ),
            e = o ? function(t) {
                self != top ? s ? t() : n.push(t) : function() {
                    try {
                        i.doScroll("left")
                    } catch (n) {
                        return setTimeout(function() {
                            e(t)
                        }, 50)
                    }
                    t()
                }()
            }
            : function(e) {
                s ? e() : n.push(e)
            }
        })
    }
}),
function() {
    Array.prototype.indexOf || (Array.prototype.indexOf = function(e, t) {
        var n, r, i, o;
        for (i = this.length,
        r = o = n = t || 0; n <= i ? o < i : o > i; r = n <= i ? ++o : --o)
            if (this[r] === e)
                return r;
        return -1
    }
    )
}
.call(this),
StripeCheckout.require.define({
    "lib/helpers": function(e, t, n) {
        (function() {
            var e, t, r;
            r = function(e) {
                return function() {
                    var n;
                    return (n = t.userAgent.match(e)) && parseInt(n[1])
                }
            }
            ,
            e = function(e) {
                return function() {
                    return e() && !t.isWindowsPhone()
                }
            }
            ,
            t = {
                userAgent: window.navigator.userAgent,
                escape: function(e) {
                    return e && ("" + e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;")
                },
                trim: function(e) {
                    return e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "")
                },
                sanitizeURL: function(e) {
                    var n, r, i, o, s;
                    if (e) {
                        for (e = t.trim(e),
                        r = !1,
                        o = 0,
                        s = (n = ["data:", "http:", "https:"]).length; o < s; o++)
                            if (i = n[o],
                            0 === e.indexOf(i)) {
                                r = !0;
                                break
                            }
                        return r ? encodeURI(e) : null
                    }
                },
                iOSVersion: r(/(?:iPhone OS |iPad; CPU OS )(\d+)_\d+/),
                iOSMinorVersion: r(/(?:iPhone OS |iPad; CPU OS )\d+_(\d+)/),
                iOSBuildVersion: r(/(?:iPhone OS |iPad; CPU OS )\d+_\d+_(\d+)/),
                androidWebkitVersion: r(/Mozilla\/5\.0.*Android.*AppleWebKit\/([\d]+)/),
                androidVersion: r(/Android (\d+)\.\d+/),
                firefoxVersion: r(/Firefox\/(\d+)\.\d+/),
                chromeVersion: r(/Chrome\/(\d+)\.\d+/),
                safariVersion: r(/Version\/(\d+)\.\d+ Safari/),
                iOSChromeVersion: r(/CriOS\/(\d+)\.\d+/),
                iOSNativeVersion: r(/Stripe\/(\d+)\.\d+/),
                ieVersion: r(/(?:MSIE |Trident\/.*rv:)(\d{1,2})\./),
                isiOSChrome: function() {
                    return /CriOS/.test(t.userAgent)
                },
                isiOSWebView: function() {
                    return /(iPhone|iPod|iPad).*AppleWebKit((?!.*Safari)|(.*\([^)]*like[^)]*Safari[^)]*\)))/i.test(t.userAgent)
                },
                getiOSWebViewType: function() {
                    if (t.isiOSWebView())
                        return window.indexedDB ? "WKWebView" : "UIWebView"
                },
                isiOS: e(function() {
                    return /(iPhone|iPad|iPod)/i.test(t.userAgent)
                }),
                isiOSNative: function() {
                    return this.isiOS() && this.iOSNativeVersion() >= 3
                },
                isiPad: function() {
                    return /(iPad)/i.test(t.userAgent)
                },
                isMac: e(function() {
                    return /mac/i.test(t.userAgent)
                }),
                isWindowsPhone: function() {
                    return /(Windows\sPhone|IEMobile)/i.test(t.userAgent)
                },
                isWindowsOS: function() {
                    return /(Windows NT \d\.\d)/i.test(t.userAgent)
                },
                isIE: function() {
                    return /(MSIE ([0-9]{1,}[\.0-9]{0,})|Trident\/)/i.test(t.userAgent)
                },
                isChrome: function() {
                    return "chrome"in window
                },
                isSafari: e(function() {
                    var e;
                    return e = t.userAgent,
                    /Safari/i.test(e) && !/Chrome/i.test(e)
                }),
                isFirefox: e(function() {
                    return null != t.firefoxVersion()
                }),
                isAndroidBrowser: function() {
                    var e;
                    return (e = t.androidWebkitVersion()) && e < 537
                },
                isAndroidChrome: function() {
                    var e;
                    return (e = t.androidWebkitVersion()) && e >= 537
                },
                isAndroidDevice: e(function() {
                    return /Android/.test(t.userAgent)
                }),
                isAndroidWebView: function() {
                    return t.isAndroidChrome() && /Version\/\d+\.\d+/.test(t.userAgent)
                },
                isAndroidFacebookApp: function() {
                    return t.isAndroidChrome() && /FBAV\/\d+\.\d+/.test(t.userAgent)
                },
                isNativeWebContainer: function() {
                    return null != window.cordova || /GSA\/\d+\.\d+/.test(t.userAgent)
                },
                isSupportedMobileOS: function() {
                    return t.isiOS() || t.isAndroidDevice()
                },
                isAndroidWebapp: function() {
                    var e;
                    return !!t.isAndroidChrome() && ((e = document.getElementsByName("apple-mobile-web-app-capable")[0] || document.getElementsByName("mobile-web-app-capable")[0]) && "yes" === e.content)
                },
                isiOSBroken: function() {
                    var e;
                    if (e = t.iOSChromeVersion(),
                    9 === t.iOSVersion() && t.iOSMinorVersion() >= 2 && e && e <= 47)
                        return !0;
                    if (t.isiPad() && 8 === t.iOSVersion())
                        switch (t.iOSMinorVersion()) {
                        case 0:
                            return !0;
                        case 1:
                            return t.iOSBuildVersion() < 1
                        }
                    return !1
                },
                isUserGesture: function() {
                    var e, t;
                    return "click" === (e = null != (t = window.event) ? t.type : void 0) || "touchstart" === e || "touchend" === e
                },
                isInsideFrame: function() {
                    return window.top !== window.self
                },
                isFallback: function() {
                    var e, n, r, i;
                    return !("postMessage"in window && !window.postMessageDisabled && !(document.documentMode && document.documentMode < 8)) || (!!((e = t.androidVersion()) && e < 4) || (!!((i = t.iOSVersion()) && i < 6) || (!!((r = t.firefoxVersion()) && r < 11) || !!((n = t.iOSChromeVersion()) && n < 36))))
                },
                isSmallScreen: function() {
                    return Math.min(window.screen.availHeight, window.screen.availWidth) <= 640 || /FakeCheckoutMobile/.test(t.userAgent)
                },
                pad: function(e, t, n) {
                    return null == t && (t = 2),
                    null == n && (n = "0"),
                    (e += "").length > t ? e : new Array(t - e.length + 1).join(n) + e
                },
                requestAnimationFrame: function(e) {
                    return ("function" == typeof window.requestAnimationFrame ? window.requestAnimationFrame(e) : void 0) || ("function" == typeof window.webkitRequestAnimationFrame ? window.webkitRequestAnimationFrame(e) : void 0) || window.setTimeout(e, 100)
                },
                requestAnimationInterval: function(e, n) {
                    var r, i;
                    return i = new Date,
                    (r = function() {
                        var o, s;
                        return o = t.requestAnimationFrame(r),
                        s = new Date,
                        n - (s - i) <= 0 && (i = s,
                        e()),
                        o
                    }
                    )()
                },
                getQueryParameterByName: function(e) {
                    var t;
                    return (t = RegExp("[?&]" + e + "=([^&]*)").exec(window.location.search)) && decodeURIComponent(t[1].replace(/\+/g, " "))
                },
                addQueryParameter: function(e, t, n) {
                    var r, i;
                    return i = encodeURIComponent(t) + "=" + encodeURIComponent(n),
                    (r = new String(e).split("#"))[0] += -1 !== r[0].indexOf("?") ? "&" : "?",
                    r[0] += i,
                    r.join("#")
                },
                bind: function(e, t, n) {
                    return e.addEventListener ? e.addEventListener(t, n, !1) : e.attachEvent("on" + t, n)
                },
                unbind: function(e, t, n) {
                    return e.removeEventListener ? e.removeEventListener(t, n, !1) : e.detachEvent("on" + t, n)
                },
                host: function(e) {
                    var t, n;
                    return (t = document.createElement("div")).innerHTML = '<a href="' + this.escape(e) + '">x</a>',
                    (n = t.firstChild).protocol + "//" + n.host
                },
                strip: function(e) {
                    var t, n, r;
                    return (t = document.createElement("div")).innerHTML = e,
                    null != (n = null != (r = t.textContent) ? r : t.innerText) ? n : ""
                },
                replaceFullWidthNumbers: function(e) {
                    var t, n, r, i, o, s, a;
                    for ("０１２３４５６７８９",
                    "0123456789",
                    i = "",
                    o = 0,
                    s = (a = (r = e.value).split("")).length; o < s; o++)
                        t = a[o],
                        (n = "０１２３４５６７８９".indexOf(t)) > -1 && (t = "0123456789"[n]),
                        i += t;
                    if (r !== i)
                        return e.value = i
                },
                setAutocomplete: function(e, n) {
                    var r;
                    if (r = t.chromeVersion() > 14 || t.safariVersion() > 7,
                    "cc-csc" === n || /^cc-/.test(n) && !r ? e.setAttribute("autocomplete", "off") : (e.setAttribute("x-autocompletetype", n),
                    e.setAttribute("autocompletetype", n)),
                    "country-name" !== n && "language" !== n && "sex" !== n && "gender-identity" !== n && (e.setAttribute("autocorrect", "off"),
                    e.setAttribute("spellcheck", "off")),
                    !/name|honorific/.test(n) && "locality" !== n && "city" !== n && "adminstrative-area" !== n && "state" !== n && "province" !== n && "region" !== n && "language" !== n && "org" !== n && "organization-title" !== n && "sex" !== n && "gender-identity" !== n)
                        return e.setAttribute("autocapitalize", "off")
                },
                hashCode: function(e) {
                    var t, n, r, i;
                    for (t = 5381,
                    n = r = 0,
                    i = e.length; r < i; n = r += 1)
                        t = (t << 5) + t + e.charCodeAt(n);
                    return (t >>> 0) % 65535
                },
                stripeUrlPrefix: function() {
                    var e;
                    return (e = window.location.hostname.match("^([a-z-]*)checkout.")) ? e[1] : ""
                },
                clientLocale: function() {
                    return (window.navigator.languages || [])[0] || window.navigator.userLanguage || window.navigator.language
                },
                dashToCamelCase: function(e) {
                    return e.replace(/-(\w)/g, function(e, t) {
                        return t.toUpperCase()
                    })
                },
                camelToDashCase: function(e) {
                    return e.replace(/([A-Z])/g, function(e) {
                        return "-" + e.toLowerCase()
                    })
                },
                isArray: Array.isArray || function(e) {
                    return "[object Array]" === {}.toString.call(e)
                }
            },
            n.exports = t
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "lib/spellChecker": function(e, t, n) {
        (function() {
            var e;
            n.exports = {
                levenshtein: e = function(e, t) {
                    var n, r, i, o, s, a, u, c, l;
                    if (o = e.length,
                    s = t.length,
                    n = [],
                    !o)
                        return s;
                    if (!s)
                        return o;
                    for (r = a = 0; 0 <= o ? a <= o : a >= o; r = 0 <= o ? ++a : --a)
                        n[r] = [r];
                    for (i = u = 1; 1 <= s ? u <= s : u >= s; i = 1 <= s ? ++u : --u)
                        n[0][i] = i;
                    for (r = c = 1; 1 <= o ? c <= o : c >= o; r = 1 <= o ? ++c : --c)
                        for (i = l = 1; 1 <= s ? l <= s : l >= s; i = 1 <= s ? ++l : --l)
                            e[r - 1] === t[i - 1] ? n[r][i] = n[r - 1][i - 1] : n[r][i] = Math.min(n[r - 1][i], n[r][i - 1], n[r - 1][i - 1]) + 1;
                    return n[o][s]
                }
                ,
                suggest: function(t, n, r) {
                    var i, o, s, a, u, c;
                    for (null == r && (r = 1 / 0),
                    o = 1 / 0,
                    s = null,
                    u = 0,
                    c = t.length; u < c; u++)
                        a = t[u],
                        (i = e(a, n)) < o && (o = i,
                        s = a);
                    return o < r ? s : null
                }
            }
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "lib/optionHelpers": function(e, t, n) {
        (function() {
            var e, r, i, o, s, a, u, c, l, p;
            i = t("lib/helpers"),
            r = function(e) {
                var t, n, r, i;
                for (n in t = {},
                e)
                    "function" == (i = typeof (r = e[n])) || "object" === i ? t[n] = "" + r : t[n] = r;
                return JSON.stringify(t)
            }
            ,
            a = function(e) {
                switch (typeof e) {
                case "function":
                    return '"' + e + '"';
                case "object":
                    return r(e);
                default:
                    return "" + JSON.stringify(e)
                }
            }
            ,
            p = function(e, t) {
                return e.length - 3 > t ? e.slice(0, t - 3) + "..." : e
            }
            ,
            e = function(e) {
                return p(a(e), 50)
            }
            ,
            s = function(e, t) {
                var n;
                return (null != (n = t.__originals) ? n[e] : void 0) || (t.buttonIntegration ? "data-" + i.camelToDashCase(e) : e)
            }
            ,
            u = function(e) {
                return "false" !== e && !1 !== e && null != e
            }
            ,
            c = function(e) {
                return "number" == typeof e ? e : "string" == typeof e ? parseInt(e) : void 0
            }
            ,
            l = function(e) {
                return null == e ? "" : "" + e
            }
            ,
            o = function(e) {
                return e
            }
            ,
            n.exports = {
                prettyPrint: s,
                flatten: r,
                repr: a,
                truncate: p,
                dumpObject: e,
                toBoolean: u,
                toNumber: c,
                toString: l,
                identity: o
            }
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "lib/paymentMethods": function(e, t, n) {
        (function() {
            var e, r, i, o, s, a, u, c, l, p, h, f, d, m, g, y, v, b, k, w, S, C, O, x, T, A, _, E, I = {}.hasOwnProperty, N = [].indexOf || function(e) {
                for (var t = 0, n = this.length; t < n; t++)
                    if (t in this && this[t] === e)
                        return t;
                return -1
            }
            ;
            for (g in d = t("lib/helpers"),
            v = t("lib/optionHelpers"),
            x = (b = t("lib/optionValidator")).severities,
            e = x.ERROR,
            a = x.WARNING,
            i = (T = b.importances).OPTIONAL,
            s = T.REQUIRED,
            T.PRIVATE,
            u = function(e, t, n) {
                var r;
                return "boolean" !== typeof t && "auto" !== t ? (r = v.prettyPrint("alipay", n),
                {
                    type: a,
                    message: "The '" + r + "' option can be true, false, or 'auto', but instead we found " + v.dumpObject(t) + "."
                }) : null
            }
            ,
            r = {
                alipay: {
                    method: {
                        importance: s,
                        spec: b.ignore,
                        checkContext: b.ignore
                    },
                    enabled: {
                        importance: s,
                        spec: u,
                        checkContext: b.ignore,
                        default: !1
                    },
                    reusable: {
                        importance: i,
                        spec: b.isNullableBoolean,
                        checkContext: b.ignore,
                        default: !1
                    }
                },
                card: {
                    method: {
                        importance: s,
                        spec: b.ignore,
                        checkContext: b.ignore
                    },
                    enabled: {
                        importance: i,
                        spec: b.isBoolean,
                        checkContext: b.ignore,
                        default: !0
                    }
                },
                bitcoin: {
                    method: {
                        importance: s,
                        spec: b.ignore,
                        checkContext: b.ignore
                    },
                    enabled: {
                        importance: i,
                        spec: b.isBoolean,
                        checkContext: b.ignore,
                        default: !1
                    }
                }
            },
            m = function(e) {
                return e in r
            }
            ,
            (_ = function() {
                var e;
                for (A in e = [],
                r)
                    e.push("'" + A + "'");
                return e
            }())[(E = _.length) - 1] = "or " + _[E - 1],
            o = _.join(", "),
            k = function(t) {
                return m(t) ? null : (v.dumpObject(methodSettings.method),
                {
                    type: e,
                    message: "'" + t + "' is not a valid payment method. It must be one of " + o
                })
            }
            ,
            f = function(t) {
                var n, i, o, s, a;
                return null != (n = k(t.method)) ? n : (o = r[t.method],
                i = (a = b.validate(o, t)).errors,
                s = a.warnings,
                (i = i.concat(s)).length > 0 ? {
                    type: e,
                    message: "Error when checking the '" + t.method + "' method:\n" + i[0].toString()
                } : null)
            }
            ,
            S = function(t, n) {
                var r, i;
                return "string" == typeof t ? k(t) : null != (null != t ? t.method : void 0) ? f(r = t) : (i = v.dumpObject(r),
                {
                    type: e,
                    message: "All elements of paymentMethods need to be either an object with a 'method' property or one of these strings: " + o + ".\n At index " + n + " we found '" + i + "' which was neither."
                })
            }
            ,
            l = function(t) {
                var n, r, i, o, s, a, u;
                for (o = function() {
                    var e, n, i;
                    for (i = [],
                    e = 0,
                    n = t.length; e < n; e++)
                        "string" == typeof (r = t[e]) ? i.push(r) : null != (null != r ? r.method : void 0) ? i.push(r.method) : i.push(null);
                    return i
                }(),
                n = s = 0,
                a = (u = (i = o.concat().sort()).slice(1)).length; s < a; n = ++s)
                    if ((r = u[n]) === i[n])
                        return {
                            type: e,
                            message: "You've configured the payment method '" + r + "' multiple times."
                        };
                return null
            }
            ,
            p = function(t) {
                var n, r, i, o;
                return null != t.alipay || null != t.bitcoin || null != t.alipayReusable ? (n = v.prettyPrint("alipay", t),
                r = v.prettyPrint("alipayReusable", t),
                i = v.prettyPrint("bitcoin", t),
                o = v.prettyPrint("paymentMethods", t),
                {
                    type: e,
                    message: "Setting any of the the '" + n + "', '" + r + "', or '" + i + "' options is disallowed if you are using '" + o + "'."
                }) : null
            }
            ,
            h = function(e, t) {
                var n, r;
                for (n in r = [],
                e)
                    null == t[n] ? r.push(t[n] = e[n].default) : r.push(void 0);
                return r
            }
            ,
            w = function(e, t) {
                var n;
                return h(r[e], n = {
                    method: e,
                    enabled: t
                }),
                n
            }
            ,
            c = function(e, t) {
                var n;
                return h(r.alipay, n = {
                    method: "alipay",
                    enabled: e,
                    reusable: t
                }),
                n
            }
            ,
            C = function(e) {
                var t, n, i, o, s, a;
                for (n in o = [],
                t = {},
                r)
                    t[n] = !1;
                for (s = 0,
                a = e.length; s < a; s++)
                    "string" == typeof (n = e[s]) ? (o.push(w(n, !0)),
                    t[n] = !0) : (null == (i = n).enabled && (i.enabled = !0),
                    h(r[i.method], i),
                    t[i.method] = !0,
                    o.push(i));
                for (n in t)
                    t[n] || o.push(w(n, !1));
                return o
            }
            ,
            y = function(e) {
                var t, n, r, i, o;
                for (r = {},
                t = [],
                i = 0,
                o = e.length; i < o; i++)
                    r[(n = e[i]).method] = n,
                    !1 !== n.enabled && t.push(n.method);
                return {
                    settings: r,
                    enabled: t
                }
            }
            ,
            O = {
                alipayEnabled: u,
                spec: function(t, n, r) {
                    var i, o, s, a, u;
                    if (null === n)
                        return null;
                    if (!d.isArray(n))
                        return {
                            type: e,
                            message: "Looking for an Array, but instead we found '" + (null === n ? "null" : typeof n) + "'."
                        };
                    for (o = a = 0,
                    u = n.length; a < u; o = ++a)
                        if (s = n[o],
                        null != (i = S(s, o)))
                            return i;
                    return null
                },
                checkContext: function(e, t, n) {
                    var r;
                    return null != (r = p(n)) ? r : null != t ? l(t) : void 0
                },
                canonicalize: function(e) {
                    var t, n, r, i, o;
                    for (r in i = {},
                    t = ["bitcoin", "alipay", "alipayReusable"],
                    e)
                        I.call(e, r) && (o = e[r],
                        N.call(t, r) < 0 && (i[r] = o));
                    return null != e.paymentMethods ? i.paymentMethods = y(C(e.paymentMethods)) : (n = e.alipay || e.alipayReusable || !1,
                    i.paymentMethods = y([w("card", !0), w("bitcoin", e.bitcoin || !1), c(n, e.alipayReusable)])),
                    i
                },
                methods: function() {
                    var e;
                    for (g in e = [],
                    r)
                        e.push(g);
                    return e
                }()
            },
            r)
                O[g] = g;
            n.exports = O
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "lib/optionSpecs": function(e, t, n) {
        (function() {
            var e, r, i, o, s, a, u, c, l, p, h, f, d, m, g, y, v, b, k, w, S;
            for (g in m = t("lib/helpers"),
            y = t("lib/optionHelpers"),
            k = t("lib/paymentMethods"),
            (w = (v = t("lib/optionValidator")).severities).ERROR,
            f = w.WARNING,
            S = v.importances,
            a = S.OPTIONAL,
            p = S.REQUIRED,
            s = S.EVENTUALLY_REQUIRED,
            l = S.PRIVATE,
            "button",
            "custom",
            "string",
            h = "url",
            "boolean",
            "number",
            "null-string",
            "null-url",
            "null-boolean",
            "null-number",
            u = {
                address: {
                    importance: l,
                    type: c = "other",
                    checkContext: function(e, t, n) {
                        var r, i;
                        return r = y.prettyPrint("address", n),
                        i = y.prettyPrint("billingAddress", n),
                        {
                            type: f,
                            message: "'" + r + "' is deprecated.  Use '" + i + "' instead."
                        }
                    }
                },
                alipay: {
                    importance: a,
                    type: c,
                    coerceTo: function(e) {
                        return "auto" === e ? e : y.toBoolean(e)
                    },
                    spec: function(e, t, n) {
                        return null === t ? null : k.alipayEnabled(e, t, n)
                    }
                },
                alipayReusable: {
                    importance: a,
                    type: "null-boolean",
                    checkContext: v.xRequiresY("alipayReusable", "alipay")
                },
                allowRememberMe: {
                    importance: a,
                    type: "null-boolean",
                    default: !0
                },
                amount: {
                    importance: a,
                    type: "null-number"
                },
                billingAddress: {
                    importance: a,
                    type: "null-boolean"
                },
                bitcoin: {
                    importance: a,
                    type: "null-boolean"
                },
                buttonIntegration: {
                    importance: l,
                    type: "boolean",
                    default: !1
                },
                closed: {
                    only: "custom",
                    importance: a,
                    type: c
                },
                color: {
                    importance: l,
                    type: "string"
                },
                currency: {
                    importance: a,
                    type: "null-string",
                    default: "usd"
                },
                description: {
                    importance: a,
                    type: "null-string"
                },
                email: {
                    importance: a,
                    type: "null-string"
                },
                image: {
                    importance: a,
                    type: "null-url"
                },
                key: {
                    importance: p,
                    type: "string"
                },
                label: {
                    only: "button",
                    importance: a,
                    type: "null-string"
                },
                locale: {
                    importance: a,
                    type: "null-string"
                },
                name: {
                    importance: a,
                    type: "null-string"
                },
                nostyle: {
                    importance: l,
                    type: "boolean"
                },
                notrack: {
                    importance: l,
                    type: "boolean"
                },
                opened: {
                    only: "custom",
                    importance: a,
                    type: c
                },
                panelLabel: {
                    importance: a,
                    type: "null-string"
                },
                paymentMethods: {
                    only: "custom",
                    importance: a,
                    type: c,
                    spec: k.spec,
                    checkContext: k.checkContext
                },
                referrer: {
                    importance: l,
                    type: h
                },
                shippingAddress: {
                    importance: a,
                    type: "null-boolean",
                    checkContext: v.xRequiresY("shippingAddress", "billingAddress")
                },
                supportsTokenCallback: {
                    importance: l,
                    type: "boolean"
                },
                timeLoaded: {
                    importance: l,
                    type: c
                },
                token: {
                    importance: s,
                    type: c
                },
                trace: {
                    importance: l,
                    type: "boolean"
                },
                url: {
                    importance: l,
                    type: h
                },
                zipCode: {
                    importance: a,
                    type: "null-boolean"
                },
                __originals: {
                    importance: l,
                    type: c
                }
            })
                null == (b = u[g]).coerceTo && (b.coerceTo = function() {
                    switch (b.type) {
                    case "string":
                    case "null-string":
                        return y.toString;
                    case "boolean":
                    case "null-boolean":
                        return y.toBoolean;
                    case "number":
                    case "null-number":
                        return y.toNumber;
                    case h:
                    case "null-url":
                        return m.sanitizeURL;
                    case c:
                        return y.identity
                    }
                }()),
                null == b.spec && (b.spec = function() {
                    switch (b.type) {
                    case "string":
                    case h:
                        return v.isString;
                    case "boolean":
                        return v.isBoolean;
                    case "number":
                        return v.isNumber;
                    case "null-string":
                    case "null-url":
                        return v.isNullableString;
                    case "null-boolean":
                        return v.isNullableBoolean;
                    case "null-number":
                        return v.isNullableNumber;
                    case c:
                        return v.ignore
                    }
                }()),
                null == b.checkContext && (b.checkContext = v.ignore);
            e = (d = function(e) {
                var t, n, r, i, o, c;
                for (g in n = e.only,
                t = e.isConfigure,
                r = {},
                u)
                    if (null == (c = u[g]).only || c.only === n) {
                        for (i in b = {},
                        c)
                            o = c[i],
                            b[i] = "importance" === i && o === s ? t ? a : p : o;
                        r[g] = b
                    }
                return r
            }
            )({
                only: "button",
                isConfigure: !0
            }),
            r = d({
                only: "button",
                isConfigure: !1
            }),
            i = d({
                only: "custom",
                isConfigure: !0
            }),
            o = d({
                only: "custom",
                isConfigure: !1
            }),
            n.exports = {
                _OPTIONS: u,
                types: {
                    STRING: "string",
                    BOOLEAN: "boolean",
                    NUMBER: "number",
                    NULLABLE_STRING: "null-string",
                    NULLABLE_URL: "null-url",
                    NULLABLE_BOOLEAN: "null-boolean",
                    NULLABLE_NUMBER: "null-number",
                    URL: h,
                    OTHER: c
                },
                buttonConfigureOptions: e,
                buttonOpenOptions: r,
                customConfigureOptions: i,
                customOpenOptions: o,
                all: [e, r, i, o]
            }
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "lib/optionValidator": function(e, t, n) {
        (function() {
            var e, r, i, o, s, a, u, c, l, p, h, f, d, m, g, y, v, b, k, w, S, C, O, x, T, A, _ = [].indexOf || function(e) {
                for (var t = 0, n = this.length; t < n; t++)
                    if (t in this && this[t] === e)
                        return t;
                return -1
            }
            ;
            x = t("lib/spellChecker"),
            S = t("lib/optionHelpers"),
            k = function(e) {
                return "required" === e || "eventually-required" === e
            }
            ,
            f = function(e) {
                var t, n;
                return {
                    all: e,
                    required: function() {
                        var r;
                        for (t in r = [],
                        e)
                            n = e[t],
                            k(n.importance) && r.push(t);
                        return r
                    }(),
                    suggestable: function() {
                        var r;
                        for (t in r = [],
                        e)
                            "private" !== (n = e[t]).importance && r.push(t);
                        return r
                    }()
                }
            }
            ,
            O = function(e, t) {
                var n;
                return (n = typeof t) !== e ? (null === t && (n = "null"),
                {
                    type: "warning",
                    message: "Looking for type '" + e + "', but instead we found '" + n + "'."
                }) : null
            }
            ,
            C = function(e, t) {
                return null === t ? null : O(e, t)
            }
            ,
            w = function(e, t, n) {
                return O("string", t)
            }
            ,
            m = function(e, t, n) {
                return O("boolean", t)
            }
            ,
            b = function(e, t, n) {
                return O("number", t)
            }
            ,
            v = function(e, t, n) {
                return C("string", t)
            }
            ,
            g = function(e, t, n) {
                return C("boolean", t)
            }
            ,
            y = function(e, t, n) {
                return C("number", t)
            }
            ,
            d = function() {
                return null
            }
            ,
            A = function(e, t) {
                return function(n, r, i) {
                    if (!i[t])
                        return {
                            type: "warning",
                            message: "'" + S.prettyPrint(t, i) + "' must be enabled whenever '" + S.prettyPrint(e, i) + "' is."
                        }
                }
            }
            ,
            e = function() {
                function e(e, t) {
                    this.rawOptions = e,
                    this.key = t
                }
                return e.prototype.toString = function() {
                    return "'" + S.prettyPrint(this.key, this.rawOptions) + "' is a required option, but was not found."
                }
                ,
                e.prototype.trackedInfo = function() {
                    return {
                        result: "ErrorMissingRequired",
                        key: this.key
                    }
                }
                ,
                e
            }(),
            r = function() {
                function e(e, t, n) {
                    this.rawOptions = e,
                    this.expected = t,
                    this.actual = n
                }
                return e.prototype.toString = function() {
                    var e;
                    return e = S.prettyPrint(this.expected, this.rawOptions),
                    "Unrecognized option '" + S.prettyPrint(this.actual, this.rawOptions) + "'. Did you mean '" + e + "'? ('" + e + "' is required)"
                }
                ,
                e.prototype.trackedInfo = function() {
                    return {
                        result: "ErrorMisspelledRequired",
                        expected: this.expected,
                        actual: this.actual
                    }
                }
                ,
                e
            }(),
            o = function() {
                function e(e, t, n) {
                    this.rawOptions = e,
                    this.expected = t,
                    this.actual = n
                }
                return e.prototype.toString = function() {
                    var e;
                    return e = S.prettyPrint(this.expected, this.rawOptions),
                    "Unrecognized option '" + S.prettyPrint(this.actual, this.rawOptions) + "'. Did you mean '" + e + "'?"
                }
                ,
                e.prototype.trackedInfo = function() {
                    return {
                        result: "WarnMisspelledOptional",
                        expected: this.expected,
                        actual: this.actual
                    }
                }
                ,
                e
            }(),
            a = function() {
                function e(e, t) {
                    this.rawOptions = e,
                    this.key = t
                }
                return e.prototype.toString = function() {
                    return "Unrecognized option '" + S.prettyPrint(this.key, this.rawOptions) + "'."
                }
                ,
                e.prototype.trackedInfo = function() {
                    return {
                        result: "WarnUnrecognized",
                        key: this.key
                    }
                }
                ,
                e
            }(),
            s = function() {
                function e(e, t, n) {
                    this.rawOptions = e,
                    this.key = t,
                    this.message = n
                }
                return e.prototype.toString = function() {
                    return "Type mismatch for option '" + S.prettyPrint(this.key, this.rawOptions) + "':\n" + this.message
                }
                ,
                e.prototype.trackedInfo = function() {
                    return {
                        result: "WarnOptionTypeError",
                        key: this.key,
                        message: this.message
                    }
                }
                ,
                e
            }(),
            i = function() {
                function e(e, t, n) {
                    this.rawOptions = e,
                    this.key = t,
                    this.message = n
                }
                return e.prototype.toString = function() {
                    return this.message
                }
                ,
                e.prototype.trackedInfo = function() {
                    return {
                        result: "WarnBadContext",
                        key: this.key,
                        message: this.message
                    }
                }
                ,
                e
            }(),
            h = function(e, t, n) {
                var r;
                return r = f(e),
                null != n && null != r.all[t] ? r.all[t].coerceTo(n) : n
            }
            ,
            l = function(t, n, r) {
                var i, o, s, a, u;
                for (i = n.errors,
                n.warnings,
                s = 0,
                a = (u = t.required).length; s < a; s++)
                    (o = u[s])in r || i.push(new e(r,o))
            }
            ,
            p = function(t, n, i) {
                var s, u, c, l, p, h, f;
                for (p in u = n.errors,
                f = n.warnings,
                4,
                i)
                    p in t.all || (h = x.suggest(t.suggestable, p, 4),
                    _.call(t.required, h) >= 0 ? (l = function() {
                        var t, n, r;
                        for (r = [],
                        c = t = 0,
                        n = u.length; t < n; c = ++t)
                            (s = u[c])instanceof e && s.key === h && r.push(c);
                        return r
                    }()).length > 0 ? (c = l[0],
                    u[c] = new r(i,h,p)) : f.push(new a(p)) : null != h ? f.push(new o(i,h,p)) : f.push(new a(i,p)))
            }
            ,
            c = function(e, t, n) {
                var r, i, o, a, u, c, l, p;
                for (u in i = t.errors,
                p = t.warnings,
                o = {},
                n)
                    l = n[u],
                    u in e.all && (o[u] = l);
                for (u in o)
                    l = o[u],
                    (r = e.all[u].spec(u, l, n)) && (c = r.type,
                    a = r.message,
                    "error" === c ? i.push(new s(n,u,a)) : p.push(new s(n,u,a)))
            }
            ,
            u = function(e, t, n) {
                var r, o, s, a, u, c, l, p;
                for (u in o = t.errors,
                p = t.warnings,
                s = {},
                n)
                    l = n[u],
                    u in e.all && (s[u] = l);
                for (u in s)
                    l = s[u],
                    (r = e.all[u].checkContext(u, l, n)) && (c = r.type,
                    a = r.message,
                    "error" === c ? o.push(new i(n,u,a)) : p.push(new i(n,u,a)))
            }
            ,
            T = function(e, t) {
                var n, r, i;
                return n = f(e),
                l(n, {
                    errors: r = [],
                    warnings: i = []
                }, t),
                p(n, {
                    errors: r,
                    warnings: i
                }, t),
                c(n, {
                    errors: r,
                    warnings: i
                }, t),
                u(n, {
                    errors: r,
                    warnings: i
                }, t),
                {
                    errors: r,
                    warnings: i
                }
            }
            ,
            n.exports = {
                ErrorMissingRequired: e,
                ErrorMisspelledRequired: r,
                WarnMisspelledOptional: o,
                WarnUnrecognized: a,
                WarnOptionTypeError: s,
                WarnBadContext: i,
                severities: {
                    ERROR: "error",
                    WARNING: "warning"
                },
                importances: {
                    OPTIONAL: "optional",
                    REQUIRED: "required",
                    EVENTUALLY_REQUIRED: "eventually-required",
                    PRIVATE: "private"
                },
                simpleTypeCheck: O,
                simpleNullableTypeCheck: C,
                isString: w,
                isBoolean: m,
                isNumber: b,
                isNullableString: v,
                isNullableBoolean: g,
                isNullableNumber: y,
                ignore: d,
                xRequiresY: A,
                coerceOption: h,
                validate: T
            }
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "lib/optionParser": function(e, t, n) {
        (function() {
            var e, r, i, o, s, a, u, c, l, p, h;
            p = t("lib/tracker"),
            i = t("lib/helpers"),
            a = t("lib/optionValidator"),
            s = t("lib/optionSpecs"),
            e = function(e, t) {
                var n, r;
                return null != e[t] ? e[t] : null != e[r = t.toLowerCase()] ? e[r] : null != e[n = i.camelToDashCase(t)] ? e[n] : void 0
            }
            ,
            o = function(e) {
                return ("string" == typeof e || e instanceof String) && !/^pk_test_.*$/.test(e)
            }
            ,
            r = function(e, t) {
                return "StripeCheckout." + e + ": " + t + "\nYou can learn about the available configuration options in the Checkout docs:\nhttps://stripe.com/docs/checkout"
            }
            ,
            h = function(e, t, n, r) {
                var i, o, s, a;
                for (i in o = {
                    "optchecker-origin": t
                },
                a = r.trackedInfo())
                    s = a[i],
                    o["optchecker-" + i] = s;
                switch (e) {
                case "error":
                    p.track.configError(o, n);
                    break;
                case "warning":
                    p.track.configWarning(o, n)
                }
            }
            ,
            c = function(e, t) {
                var n, r, i;
                for (n in r = {},
                e)
                    i = e[n],
                    r["optchecker-" + n] = i;
                return p.track.configSummary(r, t)
            }
            ,
            u = function(e, t, n) {
                return h("error", e, t, n)
            }
            ,
            l = function(e, t, n) {
                return h("warning", e, t, n)
            }
            ,
            n.exports = {
                coerceButtonOption: function(e, t) {
                    return a.coerceOption(s.buttonConfigureOptions, e, t)
                },
                parse: function(t) {
                    var n, r, i, o, u;
                    for (r in null == t && (t = {}),
                    o = {},
                    n = t.buttonIntegration ? s.buttonOpenOptions : s.customOpenOptions)
                        i = n[r],
                        null == (u = e(t, r)) && null != i.default && (u = i.default),
                        o[r] = a.coerceOption(n, r, u);
                    return o.shippingAddress && (o.billingAddress = !0),
                    null != t.address && "false" !== t.address && !1 !== t.address && (o.billingAddress = !0),
                    o.billingAddress && (o.zipCode = !1),
                    o
                },
                checkUsage: function(e, t, n) {
                    var i, p, h, f, d, m, g, y, v, b, k, w, S, C;
                    for (null == n && (n = !1),
                    g = o(t.key) || n,
                    f = "configure" === e,
                    i = t.buttonIntegration ? f ? s.buttonConfigureOptions : s.buttonOpenOptions : f ? s.customConfigureOptions : s.customOpenOptions,
                    h = (C = a.validate(i, t)).errors,
                    v = C.warnings,
                    d = h.length,
                    m = v.length,
                    c({
                        origin: e,
                        numErrors: d,
                        numWarnings: m
                    }, t),
                    b = 0,
                    w = h.length; b < w; b++)
                        p = h[b],
                        g || "undefined" != typeof console && null !== console && console.error(r(e, p.toString())),
                        u(e, t, p);
                    for (g || (g = d > 0),
                    k = 0,
                    S = v.length; k < S; k++)
                        y = v[k],
                        g || "undefined" != typeof console && null !== console && console.warn(r(e, y.toString())),
                        l(e, t, y)
                }
            }
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "lib/rpc": function(e, t, n) {
        (function() {
            var e, r, i, o = function(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            }, s = [].slice;
            r = t("lib/helpers"),
            i = t("lib/tracker"),
            e = function() {
                function e(e, t) {
                    var n;
                    null == t && (t = {}),
                    this.processMessage = o(this.processMessage, this),
                    this.sendMessage = o(this.sendMessage, this),
                    this.invoke = o(this.invoke, this),
                    this.startSession = o(this.startSession, this),
                    this.rpcID = 0,
                    this.target = e,
                    this.callbacks = {},
                    this.readyQueue = [],
                    this.readyStatus = !1,
                    this.methods = {},
                    r.bind(window, "message", (n = this,
                    function() {
                        var e;
                        return e = 1 <= arguments.length ? s.call(arguments, 0) : [],
                        n.message.apply(n, e)
                    }
                    ))
                }
                return e.prototype.startSession = function() {
                    return this.sendMessage("frameReady"),
                    this.frameReady()
                }
                ,
                e.prototype.invoke = function() {
                    var e, t, n;
                    return t = arguments[0],
                    e = 2 <= arguments.length ? s.call(arguments, 1) : [],
                    i.trace.rpcInvoke(t),
                    this.ready((n = this,
                    function() {
                        return n.sendMessage(t, e)
                    }
                    ))
                }
                ,
                e.prototype.message = function(e) {
                    var t;
                    t = !1;
                    try {
                        t = e.source === this.target
                    } catch (e) {}
                    if (t)
                        return this.processMessage(e.data)
                }
                ,
                e.prototype.ready = function(e) {
                    return this.readyStatus ? e() : this.readyQueue.push(e)
                }
                ,
                e.prototype.frameCallback = function(e, t) {
                    var n;
                    return "function" == typeof (n = this.callbacks)[e] && n[e](t),
                    delete this.callbacks[e],
                    !0
                }
                ,
                e.prototype.frameReady = function() {
                    var e, t, n;
                    for (this.readyStatus = !0,
                    t = 0,
                    n = (e = this.readyQueue.slice(0)).length; t < n; t++)
                        (0,
                        e[t])();
                    return !1
                }
                ,
                e.prototype.isAlive = function() {
                    return !0
                }
                ,
                e.prototype.sendMessage = function(e, t) {
                    var n, r, o, s;
                    if (null == t && (t = []),
                    r = ++this.rpcID,
                    "function" == typeof t[t.length - 1] && (this.callbacks[r] = t.pop()),
                    o = JSON.stringify({
                        method: e,
                        args: t,
                        id: r
                    }),
                    null != (null != (s = this.target) ? s.postMessage : void 0))
                        return this.target.postMessage(o, "*"),
                        i.trace.rpcPostMessage(e, t, r);
                    if (n = new Error("Unable to communicate with Checkout. Please contact support@stripe.com if the problem persists."),
                    null == this.methods.rpcError)
                        throw n;
                    this.methods.rpcError(n)
                }
                ,
                e.prototype.processMessage = function(e) {
                    var t, n, r, i;
                    try {
                        e = JSON.parse(e)
                    } catch (e) {
                        return
                    }
                    if (-1 !== ["frameReady", "frameCallback", "isAlive"].indexOf(e.method) ? (n = null,
                    null != (t = this[e.method]) && (n = t.apply(this, e.args))) : n = "function" == typeof (r = this.methods)[i = e.method] ? r[i].apply(r, e.args) : void 0,
                    "frameCallback" !== e.method)
                        return this.invoke("frameCallback", e.id, n)
                }
                ,
                e
            }(),
            n.exports = e
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "lib/uuid": function(e, t, n) {
        (function() {
            var e;
            e = function() {
                return (65536 * (1 + Math.random()) | 0).toString(16).substring(1)
            }
            ,
            n.exports.generate = function() {
                return "-",
                e() + e() + "-" + e() + "-" + e() + "-" + e() + "-" + e() + e() + e()
            }
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "lib/pixel": function(e, t, n) {
        (function() {
            var e, t, r, i, o, s, a, u, c;
            r = function() {
                return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
                    var t;
                    return t = 16 * Math.random() | 0,
                    ("x" === e ? t : 3 & t | 8).toString(16)
                })
            }
            ,
            u = function(e, t, n) {
                var r, i;
                return null == n && (n = {}),
                !0 === n.expires && (n.expires = -1),
                "number" == typeof n.expires && ((i = new Date).setTime(i.getTime() + 24 * n.expires * 60 * 60 * 1e3),
                n.expires = i),
                null == n.path && (n.path = "/"),
                t = (t + "").replace(/[^!#-+\--:<-\[\]-~]/g, encodeURIComponent),
                r = encodeURIComponent(e) + "=" + t,
                n.expires && (r += ";expires=" + n.expires.toGMTString()),
                n.path && (r += ";path=" + n.path),
                n.domain && (r += ";domain=" + n.domain),
                document.cookie = r
            }
            ,
            i = function(e) {
                var t, n, r, i, o, s, a;
                for (s = 0,
                a = (n = document.cookie.split("; ")).length; s < a; s++)
                    if (r = (t = n[s]).indexOf("="),
                    i = decodeURIComponent(t.substr(0, r)),
                    o = decodeURIComponent(t.substr(r + 1)),
                    i === e)
                        return o;
                return null
            }
            ,
            t = function(e) {
                return "string" == typeof e ? encodeURIComponent(e) : encodeURIComponent(JSON.stringify(e))
            }
            ,
            a = function(e, n, r) {
                var i, o, s;
                return null == n && (n = {}),
                n.i = (new Date).getTime(),
                n = function() {
                    var e;
                    for (o in e = [],
                    n)
                        s = n[o],
                        e.push(o + "=" + t(s));
                    return e
                }().join("&"),
                i = new Image,
                r && (i.onload = r),
                i.src = e + "?" + n,
                !0
            }
            ,
            e = function() {
                var e;
                switch (null != (e = window.navigator.doNotTrack) ? e.toString().toLowerCase() : void 0) {
                case "1":
                case "yes":
                case "true":
                    return !1;
                default:
                    return !0
                }
            }
            ,
            s = function() {
                var t;
                if (!e())
                    return "DNT";
                try {
                    return (t = localStorage.getItem("lsid")) || (t = r(),
                    localStorage.setItem("lsid", t)),
                    t
                } catch (e) {
                    return e,
                    "NA"
                }
            }
            ,
            o = function() {
                var t;
                if (!e())
                    return "DNT";
                try {
                    return t = i("cid") || r(),
                    u("cid", t, {
                        expires: 7200,
                        domain: ".stripe.com"
                    }),
                    t
                } catch (e) {
                    return e,
                    "NA"
                }
            }
            ,
            c = function(e, t, n) {
                var r, i, u;
                for (r in null == t && (t = {}),
                i = {
                    event: e,
                    rf: document.referrer,
                    sc: window.location.search
                },
                t)
                    u = t[r],
                    i[r] = u;
                return i.lsid || (i.lsid = s()),
                i.cid || (i.cid = o()),
                a("https://q.stripe.com", i, n)
            }
            ,
            n.exports.track = c,
            n.exports.getLocalStorageID = s,
            n.exports.getCookieID = o
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "vendor/base64": function(e, t, n) {
        n.exports.encode = function(e) {
            var t, n, r, i, o, s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", a = 0, u = 0, c = "", l = [];
            if (!e)
                return e;
            e = function(e) {
                var t, n, r, i, o = "";
                for (t = n = 0,
                r = (e = (e + "").replace(/\r\n/g, "\n").replace(/\r/g, "\n")).length,
                i = 0; i < r; i++) {
                    var s = e.charCodeAt(i)
                      , a = null;
                    s < 128 ? n++ : a = s > 127 && s < 2048 ? String.fromCharCode(s >> 6 | 192, 63 & s | 128) : String.fromCharCode(s >> 12 | 224, s >> 6 & 63 | 128, 63 & s | 128),
                    null !== a && (n > t && (o += e.substring(t, n)),
                    o += a,
                    t = n = i + 1)
                }
                return n > t && (o += e.substring(t, e.length)),
                o
            }(e);
            do {
                t = (o = e.charCodeAt(a++) << 16 | e.charCodeAt(a++) << 8 | e.charCodeAt(a++)) >> 18 & 63,
                n = o >> 12 & 63,
                r = o >> 6 & 63,
                i = 63 & o,
                l[u++] = s.charAt(t) + s.charAt(n) + s.charAt(r) + s.charAt(i)
            } while (a < e.length);
            switch (c = l.join(""),
            e.length % 3) {
            case 1:
                c = c.slice(0, -2) + "==";
                break;
            case 2:
                c = c.slice(0, -1) + "="
            }
            return c
        }
    }
}),
StripeCheckout.require.define({
    "lib/tracker": function(e, t, n) {
        (function() {
            var e, r, i, o, s, a, u, c, l, p, h, f = [].indexOf || function(e) {
                for (var t = 0, n = this.length; t < n; t++)
                    if (t in this && this[t] === e)
                        return t;
                return -1
            }
            ;
            h = t("lib/uuid"),
            s = t("lib/pixel"),
            e = t("vendor/base64"),
            i = t("lib/helpers"),
            r = {
                enabled: !1,
                tracingEnabled: !1,
                eventNamePrefix: "checkout.",
                distinctId: h.generate(),
                mixpanelKey: null
            },
            a = {},
            (p = {}).setEnabled = function(e) {
                return r.enabled = e
            }
            ,
            p.setTracingEnabled = function(e) {
                return r.tracingEnabled = e
            }
            ,
            p.setDistinctID = function(e) {
                if (e)
                    return r.distinctId = e
            }
            ,
            p.getDistinctID = function() {
                return r.distinctId
            }
            ,
            p.setMixpanelKey = function(e) {
                return r.mixpanelKey = e
            }
            ,
            p.track = {
                outerOpen: function(e) {
                    return l("outer.open", e, ["key"], {
                        appendStateParameters: !1
                    })
                },
                manhattanStatusSet: function(e) {
                    return l("outer.manhattanStatus", {
                        isEnabled: e
                    })
                },
                viewport: function(e) {
                    return l("outer.viewport", {
                        viewport: e
                    })
                },
                iOSWebViewType: function() {
                    var e;
                    if (e = i.getiOSWebViewType())
                        return l("inner.iOSWebViewType", {
                            type: e
                        })
                },
                open: function(e) {
                    var t, n;
                    for (t in e)
                        n = e[t],
                        a["option-" + t] = n;
                    return l("open")
                },
                close: function(e) {
                    return l("close", e, ["withToken"])
                },
                configSummary: function(e, t) {
                    var n, r;
                    for (n in t)
                        r = t[n],
                        a["option-" + n] = r;
                    return l("config.summary", e, ["optchecker-origin", "optchecker-numErrors", "optchecker-numWarnings"])
                },
                configError: function(e, t) {
                    var n, r;
                    for (n in t)
                        r = t[n],
                        a["option-" + n] = r;
                    return l("config.error", e, ["optchecker-origin", "optchecker-result"])
                },
                configWarning: function(e, t) {
                    var n, r;
                    for (n in t)
                        r = t[n],
                        a["option-" + n] = r;
                    return l("config.warning", e, ["optchecker-origin", "optchecker-result"])
                },
                keyOverride: function(e) {
                    return l("config.keyOverride", e, ["configure", "open"])
                },
                localeOverride: function(e) {
                    return l("config.localeOverride", e, ["configure", "open"])
                },
                imageOverride: function(e) {
                    return l("config.imageOverride", e, ["configure", "open"])
                },
                rememberMe: function(e) {
                    return l("checkbox.rememberMe", e, ["checked"])
                },
                authorizeAccount: function() {
                    return l("account.authorize")
                },
                login: function() {
                    return l("account.authorize.success")
                },
                wrongVerificationCode: function() {
                    return l("account.authorize.fail")
                },
                keepMeLoggedIn: function(e) {
                    return l("checkbox.keepMeLoggedIn", e, ["checked"])
                },
                logout: function() {
                    return l("account.logout")
                },
                submit: function() {
                    return l("submit")
                },
                invalid: function(e) {
                    if (null == e.err && null == e.fields)
                        throw new Error("Cannot track invalid because err or fields should be provided");
                    return l("invalid", e)
                },
                tokenError: function(e) {
                    return l("token.error", {
                        message: e,
                        type: "exception"
                    })
                },
                moreInfo: function() {
                    return l("moreInfoLink.click")
                },
                accountCreateSuccess: function() {
                    return l("account.create.success")
                },
                accountCreateFail: function() {
                    return l("account.create.fail")
                },
                addressAutocompleteShow: function() {
                    return l("addressAutoComplete.show")
                },
                addressAutocompleteResultSelected: function() {
                    return l("addressAutocomplete.result.selected")
                },
                back: function(e) {
                    return l("back", e, ["from_step", "to_step"])
                },
                token: function(e) {
                    return l("token", e, ["stripe_token"])
                },
                i18nLocKeyMissing: function(e) {
                    return l("i18n.loc.missingKey", {
                        template_key: e
                    })
                },
                i18nLocPartiallyReplacedTemplate: function(e, t) {
                    return l("i18n.loc.partiallyReplacedTemplate", {
                        template_key: e,
                        template_value: t
                    })
                },
                i18nFormatLocaleMissing: function(e) {
                    return l("i18n.format.localeMissing", {
                        locale: e
                    })
                },
                phoneVerificationShow: function() {
                    return l("phoneVerification.show")
                },
                phoneVerificationCreate: function(e) {
                    return l("phoneVerification.create", e, ["use_sms"])
                },
                phoneVerificationAuthorize: function(e) {
                    return l("fraudCodeVerification.authorize", e, ["valid"])
                },
                addressVerificationShow: function() {
                    return l("addressVerification.show")
                },
                alert: function(e) {
                    return l("alert", e)
                }
            },
            p.trace = {
                trigger: function(e, t) {
                    var n, r;
                    if (n = ["didResize", "viewAddedToDOM", "valueDidChange", "checkedDidChange", "keyUp", "keyDown", "keyPress", "keyInput", "click", "blur"],
                    "checkout" === (e = e.split("."))[e.length - 1] && e.pop(),
                    e = e.join("."),
                    f.call(n, e) < 0)
                        return null == this._triggerQueue && (this._triggerQueue = {}),
                        this._triggerQueue[e] = c(t),
                        null != this._triggerTimeout ? this._triggerTimeout : this._triggerTimeout = setTimeout((r = this,
                        function() {
                            var n;
                            for (e in n = r._triggerQueue)
                                t = n[e],
                                u("trigger." + e, {
                                    args: t
                                });
                            return r._triggerQueue = {},
                            r._triggerTimeout = null
                        }
                        ), 0)
                },
                rpcInvoke: function(e) {
                    return u("rpc.invoke." + e)
                },
                rpcPostMessage: function(e, t, n) {
                    return u("rpc.postMessage." + e, {
                        id: n,
                        args: c(t)
                    })
                }
            },
            p.state = {
                setUIType: function(e) {
                    return a["st-ui-type"] = e
                },
                setUIIntegration: function(e) {
                    return a["st-ui-integration"] = e
                },
                setAccountsEnabled: function(e) {
                    return a["st-accounts-enabled"] = e
                },
                setRememberMeEnabled: function(e) {
                    return a["st-remember-me-enabled"] = e
                },
                setRememberMeChecked: function(e) {
                    return a["st-remember-me-checked"] = e
                },
                setAccountCreated: function(e) {
                    return a["st-account-created"] = e
                },
                setLoggedIn: function(e) {
                    return a["st-logged-in"] = e
                },
                setVariants: function(e) {
                    var t, n, r;
                    for (t in r = [],
                    e)
                        n = e[t],
                        r.push(a["st-variant-" + t] = n);
                    return r
                },
                setPhoneVerificationShown: function(e) {
                    return a["st-phone-verification-shown"] = e
                },
                setAddressVerificationShown: function(e) {
                    return a["st-address-verification-shown"] = e
                },
                setAlipayShouldDisplay: function(e) {
                    return a["st-alipay-should-display"] = e
                },
                setRequestedLocale: function(e) {
                    return a["st-locale"] = e
                }
            },
            p.dontTrack = function(e) {
                var t;
                return t = r.enabled,
                r.enabled = !1,
                e(),
                r.enabled = t
            }
            ,
            u = function(e, t, n, i) {
                if (null == t && (t = {}),
                null == n && (n = []),
                null == i && (i = {}),
                r.tracingEnabled)
                    return e = "trace." + e,
                    i.excludeMixpanel = !0,
                    l.apply(this, arguments)
            }
            ,
            l = function(e, t, n, i) {
                var u, c, l, p, f, d, m;
                if (null == t && (t = {}),
                null == n && (n = []),
                null == i && (i = {}),
                r.enabled) {
                    if ((p = function() {
                        var e, r, i;
                        for (i = [],
                        e = 0,
                        r = n.length; e < r; e++)
                            (l = n[e])in t || i.push(l);
                        return i
                    }()).length > 0)
                        throw new Error("Missing required data (" + p.join(", ") + ") for tracking " + e + ".");
                    if (t.distinct_id = r.distinctId,
                    t.eventId = h.generate(),
                    null == i.appendStateParameters && (i.appendStateParameters = !0),
                    i.appendStateParameters)
                        for (c in a)
                            f = a[c],
                            t[c] = f;
                    for (t.h = screen.height,
                    t.w = screen.width,
                    f = d = 0,
                    m = t.length; d < m; f = ++d)
                        c = t[f],
                        f instanceof Array && f.sort();
                    return u = "" + r.eventNamePrefix + e,
                    i.excludeMixpanel || o.track(u, t),
                    s.track(u, t)
                }
            }
            ,
            (o = {}).track = function(t, n) {
                var i, o;
                if (null == n && (n = {}),
                "undefined" != typeof $ && null !== $ && null != r.mixpanelKey)
                    return delete (o = $.extend({
                        token: r.mixpanelKey,
                        userAgent: window.navigator.userAgent
                    }, n)).stripe_token,
                    i = e.encode(JSON.stringify({
                        event: t,
                        properties: o
                    })),
                    (new Image).src = "https://api.mixpanel.com/track/?ip=1&img=1&data=" + i
            }
            ,
            c = function(e) {
                var t, n, r;
                if (e instanceof Array)
                    return JSON.stringify(function() {
                        var t, n, i;
                        for (i = [],
                        t = 0,
                        n = e.length; t < n; t++)
                            r = e[t],
                            i.push(c(r));
                        return i
                    }());
                if (null != e && null != e.target && null != e.type)
                    return c({
                        type: e.type,
                        target_id: e.target.id
                    });
                if (e instanceof Object) {
                    if (e.constructor === Object) {
                        for (t in n = {},
                        e)
                            r = e[t],
                            n[t] = c(r);
                        return JSON.stringify(n)
                    }
                    return e.toString()
                }
                return e
            }
            ,
            n.exports = p
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "outer/lib/fallbackRpc": function(e, t, n) {
        (function() {
            var e, t, r, i, o, s = function(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            };
            t = 1,
            r = null,
            i = null,
            o = /^#?\d+&/,
            e = function() {
                function e(e, t) {
                    this.invokeTarget = s(this.invokeTarget, this),
                    this.target = e,
                    this.host = t
                }
                return e.prototype.invokeTarget = function(e) {
                    var n;
                    return e = +new Date + t++ + "&" + encodeURIComponent(e),
                    n = this.host + "",
                    this.target.location = n.replace(/#.*$/, "") + "#" + e
                }
                ,
                e.prototype.receiveMessage = function(e, t) {
                    return null == t && (t = 100),
                    r && clearInterval(r),
                    r = setInterval(function() {
                        var t;
                        if ((t = decodeURIComponent(window.location.hash)) !== i && o.test(t))
                            return window.location.hash = "",
                            i = t,
                            e({
                                data: t.replace(o, "")
                            })
                    }, t)
                }
                ,
                e
            }(),
            n.exports = e
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "outer/lib/utils": function(e, t, n) {
        (function() {
            var e, t, r, i, o, s, a, u, c, l, p, h, f, d, m = [].indexOf || function(e) {
                for (var t = 0, n = this.length; t < n; t++)
                    if (t in this && this[t] === e)
                        return t;
                return -1
            }
            ;
            e = function(e) {
                return document.querySelectorAll(e)
            }
            ,
            t = function(e) {
                var t, n, r, i, o, s;
                if ("function" == typeof document.getElementsByClassName)
                    return document.getElementsByClassName(e);
                if ("function" == typeof document.querySelectorAll)
                    return document.querySelectorAll("." + e);
                for (n = new RegExp("(^|\\s)" + e + "(\\s|$)"),
                s = [],
                r = 0,
                i = (o = document.getElementsByTagName("*")).length; r < i; r++)
                    t = o[r],
                    n.test(t.className) && s.push(t);
                return s
            }
            ,
            s = function(e, t) {
                var n;
                return "function" == typeof e.hasAttribute ? e.hasAttribute(t) : !(!(n = e.getAttributeNode(t)) || !n.specified && !n.nodeValue)
            }
            ,
            d = function(e, t, n, r) {
                if (null == n && (n = {}),
                null == r && (r = !0),
                window.jQuery)
                    return jQuery(e).trigger(t, n)
            }
            ,
            r = function(e, t) {
                return e.className += " " + t
            }
            ,
            a = function(e, t) {
                return m.call(e.className.split(" "), t) >= 0
            }
            ,
            o = function(e, t) {
                return e.style.cssText += ";" + t
            }
            ,
            c = function(e, t) {
                return e.parentNode.insertBefore(t, e)
            }
            ,
            u = function(e, t) {
                return e.parentNode.insertBefore(t, e.nextSibling)
            }
            ,
            i = function(e, t) {
                return e.appendChild(t)
            }
            ,
            p = function(e) {
                var t;
                return null != (t = e.parentNode) ? t.removeChild(e) : void 0
            }
            ,
            l = function(e) {
                var t;
                for (t = []; (e = e.parentNode) && e !== document && m.call(t, e) < 0; )
                    t.push(e);
                return t
            }
            ,
            h = function(e) {
                var t;
                return (t = document.createElement("a")).href = e,
                "" + t.href
            }
            ,
            f = function(e, t) {
                return "innerText"in e ? e.innerText = t : e.textContent = t,
                t
            }
            ,
            n.exports = {
                $: e,
                $$: t,
                hasAttr: s,
                trigger: d,
                addClass: r,
                hasClass: a,
                css: o,
                insertBefore: c,
                insertAfter: u,
                append: i,
                remove: p,
                parents: l,
                resolve: h,
                text: f
            }
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "outer/controllers/app": function(e, t, n) {
        (function() {
            var e, r, i, o, s, a, u = function(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            };
            r = t("outer/controllers/checkout"),
            i = t("outer/controllers/tokenCallback"),
            t("lib/rpc"),
            o = t("lib/optionParser"),
            s = t("lib/tracker"),
            a = t("outer/lib/utils"),
            e = function() {
                function e(e) {
                    var t, n;
                    null == e && (e = {}),
                    this.setForceAppType = u(this.setForceAppType, this),
                    this.setForceView = u(this.setForceView, this),
                    this.setForceManhattan = u(this.setForceManhattan, this),
                    this.getHost = u(this.getHost, this),
                    this.setHost = u(this.setHost, this),
                    this.configure = u(this.configure, this),
                    this.close = u(this.close, this),
                    this.open = u(this.open, this),
                    this.configurations = {},
                    this.checkouts = {},
                    this.constructorOptions = {
                        host: "https://checkout.stripe.com",
                        forceManhattan: !1,
                        forceView: !1,
                        forceAppType: !1
                    },
                    this.timeLoaded = Math.floor((new Date).getTime() / 1e3),
                    this.totalButtons = 0,
                    0 === (null != (t = window.Prototype) && null != (n = t.Version) ? n.indexOf("1.6") : void 0) && console.error("Stripe Checkout is not compatible with your version of Prototype.js. Please upgrade to version 1.7 or greater.")
                }
                return e.prototype.open = function(e, t) {
                    var n, s, u, c, l;
                    if (null == e && (e = {}),
                    null == t && (t = null),
                    u = {
                        referrer: document.referrer,
                        url: document.URL,
                        timeLoaded: this.timeLoaded
                    },
                    t && this.configurations[t])
                        for (s in l = this.configurations[t])
                            c = l[s],
                            u[s] = c;
                    for (s in e)
                        c = e[s],
                        u[s] = c;
                    return u.image && (u.image = a.resolve(u.image)),
                    o.checkUsage("open", u),
                    this.validateOptions(e, "open"),
                    t ? (n = this.checkouts[t],
                    null == e.token && null == e.onToken || n.setOnToken(new i(e))) : n = new r(new i(e),this.constructorOptions,e),
                    this.trackOpen(n, u),
                    this.trackViewport(),
                    n.open(u)
                }
                ,
                e.prototype.close = function(e) {
                    var t;
                    return null != (t = this.checkouts[e]) ? t.close() : void 0
                }
                ,
                e.prototype.configure = function(e, t) {
                    return null == t && (t = {}),
                    e instanceof Object && (t = e,
                    e = "button" + this.totalButtons++),
                    this.enableTracker(t),
                    o.checkUsage("configure", t),
                    t.image && (t.image = a.resolve(t.image)),
                    this.validateOptions(t, "configure"),
                    this.configurations[e] = t,
                    this.checkouts[e] = new r(new i(t),this.constructorOptions,t),
                    this.checkouts[e].preload(t),
                    {
                        open: (n = this,
                        function(t) {
                            return n.open(t, e)
                        }
                        ),
                        close: function(t) {
                            return function() {
                                return t.close(e)
                            }
                        }(this)
                    };
                    var n
                }
                ,
                e.prototype.validateOptions = function(e, t) {
                    try {
                        return JSON.stringify(e)
                    } catch (e) {
                        throw new Error("Stripe Checkout was unable to serialize the options passed to StripeCheckout." + t + "(). Please consult the doumentation to confirm that you're supplying values of the expected type: " + "https://stripe.com/docs/checkout#integration-custom")
                    }
                }
                ,
                e.prototype.setHost = function(e) {
                    return this.constructorOptions.host = e
                }
                ,
                e.prototype.getHost = function() {
                    return this.constructorOptions.host
                }
                ,
                e.prototype.setForceManhattan = function(e) {
                    return this.constructorOptions.forceManhattan = !!e
                }
                ,
                e.prototype.setForceView = function(e) {
                    return this.constructorOptions.forceView = e
                }
                ,
                e.prototype.setForceAppType = function(e) {
                    return this.constructorOptions.forceAppType = e
                }
                ,
                e.prototype.enableTracker = function(e) {
                    return s.setEnabled(!e.notrack)
                }
                ,
                e.prototype.trackOpen = function(e, t) {
                    return this.enableTracker(t),
                    s.track.outerOpen({
                        key: t.key,
                        lsid: "NA",
                        cid: "NA"
                    })
                }
                ,
                e.prototype.trackViewport = function(e, t) {
                    var n, r, i, o;
                    n = document.getElementsByTagName("meta"),
                    o = function() {
                        var e, t, i;
                        for (i = [],
                        e = 0,
                        t = n.length; e < t; e++)
                            "viewport" === (r = n[e]).name && r.content && i.push(r.content);
                        return i
                    }().join(",");
                    try {
                        return i = o.split(",").map(function(e) {
                            return e.trim().toLowerCase()
                        }).sort().join(", "),
                        s.track.viewport(i)
                    } catch (e) {}
                }
                ,
                e
            }(),
            n.exports = e
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "outer/controllers/button": function(e, t, n) {
        (function() {
            var e, r, i, o, s, a, u, c, l, p, h, f, d, m, g = function(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            };
            m = t("outer/lib/utils"),
            e = m.$$,
            a = m.hasClass,
            i = m.addClass,
            d = m.trigger,
            o = m.append,
            f = m.text,
            p = m.parents,
            c = m.insertAfter,
            s = m.hasAttr,
            h = m.resolve,
            u = t("lib/helpers"),
            l = t("lib/optionParser"),
            r = function() {
                function t(e, t) {
                    var n;
                    this.parseOptions = g(this.parseOptions, this),
                    this.parentHead = g(this.parentHead, this),
                    this.parentForm = g(this.parentForm, this),
                    this.onToken = g(this.onToken, this),
                    this.open = g(this.open, this),
                    this.submit = g(this.submit, this),
                    this.append = g(this.append, this),
                    this.render = g(this.render, this),
                    this.scriptEl = e,
                    this.app = t,
                    this.document = this.scriptEl.ownerDocument,
                    this.nostyle = u.isFallback(),
                    this.options = this.parseOptions(),
                    (n = this.options).label || (n.label = "Pay with Card"),
                    this.options.token = this.onToken,
                    this.options.buttonIntegration = !0,
                    this.$el = document.createElement("button"),
                    this.$el.setAttribute("type", "submit"),
                    this.$el.className = "stripe-button-el",
                    u.bind(this.$el, "click", this.submit),
                    u.bind(this.$el, "touchstart", function() {}),
                    this.render()
                }
                return t.totalButtonId = 0,
                t.load = function(n) {
                    var r, o;
                    if (o = e("stripe-button"),
                    o = (o = function() {
                        var e, t, n;
                        for (n = [],
                        e = 0,
                        t = o.length; e < t; e++)
                            r = o[e],
                            a(r, "active") || n.push(r);
                        return n
                    }())[o.length - 1])
                        return i(o, "active"),
                        new t(o,n).append()
                }
                ,
                t.prototype.render = function() {
                    return this.$el.innerHTML = "",
                    this.$span = document.createElement("span"),
                    f(this.$span, this.options.label),
                    this.nostyle || (this.$el.style.visibility = "hidden",
                    this.$span.style.display = "block",
                    this.$span.style.minHeight = "30px"),
                    this.$style = document.createElement("link"),
                    this.$style.setAttribute("type", "text/css"),
                    this.$style.setAttribute("rel", "stylesheet"),
                    this.$style.setAttribute("href", this.app.getHost() + "/v3/checkout/button-qpwW2WfkB0oGWVWIASjIOQ.css"),
                    o(this.$el, this.$span)
                }
                ,
                t.prototype.append = function() {
                    var e, t;
                    return this.scriptEl && c(this.scriptEl, this.$el),
                    this.nostyle || (e = this.parentHead()) && o(e, this.$style),
                    (this.$form = this.parentForm()) && (u.unbind(this.$form, "submit", this.submit),
                    u.bind(this.$form, "submit", this.submit)),
                    this.nostyle || setTimeout((t = this,
                    function() {
                        return t.$el.style.visibility = "visible"
                    }
                    ), 1e3),
                    this.app.setHost(u.host(this.scriptEl.src)),
                    this.appHandler = this.app.configure(this.options, {
                        form: this.$form
                    })
                }
                ,
                t.prototype.disable = function() {
                    return this.$el.setAttribute("disabled", !0)
                }
                ,
                t.prototype.enable = function() {
                    return this.$el.removeAttribute("disabled")
                }
                ,
                t.prototype.isDisabled = function() {
                    return s(this.$el, "disabled")
                }
                ,
                t.prototype.submit = function(e) {
                    return "function" == typeof e.preventDefault && e.preventDefault(),
                    this.isDisabled() || this.open(),
                    !1
                }
                ,
                t.prototype.open = function() {
                    return this.appHandler.open(this.options)
                }
                ,
                t.prototype.onToken = function(e, t) {
                    var n, r, i, s, a;
                    if (d(this.scriptEl, "token", e),
                    this.$form) {
                        if (r = this.renderInput("stripeToken", e.id),
                        o(this.$form, r),
                        i = this.renderInput("stripeTokenType", e.type),
                        o(this.$form, i),
                        e.email && o(this.$form, this.renderInput("stripeEmail", e.email)),
                        t)
                            for (s in t)
                                a = t[s],
                                n = this.renderInput(this.formatKey(s), a),
                                o(this.$form, n);
                        this.$form.submit()
                    }
                    return this.disable()
                }
                ,
                t.prototype.formatKey = function(e) {
                    var t, n, r, i;
                    for (n = e.split("_"),
                    e = "",
                    r = 0,
                    i = n.length; r < i; r++)
                        (t = n[r]).length > 0 && (e = e + t.substr(0, 1).toUpperCase() + t.substr(1).toLowerCase());
                    return "stripe" + e
                }
                ,
                t.prototype.renderInput = function(e, t) {
                    var n;
                    return (n = document.createElement("input")).type = "hidden",
                    n.name = e,
                    n.value = t,
                    n
                }
                ,
                t.prototype.parentForm = function() {
                    var e, t, n, r, i;
                    for (n = 0,
                    r = (t = p(this.$el)).length; n < r; n++)
                        if ("form" === (null != (i = (e = t[n]).tagName) ? i.toLowerCase() : void 0))
                            return e;
                    return null
                }
                ,
                t.prototype.parentHead = function() {
                    var e, t;
                    return (null != (e = this.document) ? e.head : void 0) || (null != (t = this.document) ? t.getElementsByTagName("head")[0] : void 0) || this.document.body
                }
                ,
                t.prototype.parseOptions = function() {
                    var e, t, n, r, i, o, s, a, c;
                    for (i = {},
                    s = 0,
                    a = (c = this.scriptEl.attributes).length; s < a; s++)
                        (null != (r = (e = c[s]).name.match(/^data-(.+)$/)) ? r[1] : void 0) && ("image" === (t = u.dashToCamelCase(r[1])) ? e.value && (o = h(e.value)) : o = e.value,
                        n = l.coerceButtonOption(t, o),
                        i[t] = n,
                        null == i.__originals && (i.__originals = {}),
                        i.__originals[t] = r[0]);
                    return i
                }
                ,
                t
            }(),
            n.exports = r
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "outer/controllers/checkout": function(e, t, n) {
        (function() {
            var e, r, i, o, s, a, u = function(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            };
            s = t("lib/helpers"),
            i = t("outer/views/iframeView"),
            o = t("outer/views/tabView"),
            r = t("outer/views/fallbackView"),
            a = t("lib/tracker"),
            e = function() {
                function e(e, t, n) {
                    this.shouldUseManhattan = u(this.shouldUseManhattan, this),
                    this.isLegacyIe = u(this.isLegacyIe, this),
                    this.invokeCallbacks = u(this.invokeCallbacks, this),
                    this.onTokenCallback = u(this.onTokenCallback, this),
                    this.preload = u(this.preload, this),
                    this.open = u(this.open, this),
                    this.createView = u(this.createView, this),
                    this.setOnToken = u(this.setOnToken, this),
                    this.host = t.host,
                    this.forceManhattan = t.forceManhattan,
                    this.forceView = t.forceView,
                    this.forceAppType = t.forceAppType,
                    this.opened = !1,
                    this.setOnToken(e),
                    this.shouldPopup = s.isSupportedMobileOS() && !(s.isNativeWebContainer() || s.isAndroidWebapp() || s.isAndroidFacebookApp() || s.isiOSWebView() || s.isiOSBroken()),
                    this.manhattanPending = !1,
                    this.manhattanCallbacks = [],
                    this.shouldUseManhattan(this.createView, n)
                }
                return e.activeView = null,
                e.prototype.setOnToken = function(e) {
                    var t, n;
                    return this.tokenCallback = e,
                    this.onToken = (n = this,
                    function(t) {
                        return e.trigger(t.token, t.args, n.onTokenCallback)
                    }
                    ),
                    null != (t = this.view) ? t.onToken = this.onToken : void 0
                }
                ,
                e.prototype.createView = function(e) {
                    var t, n, u;
                    if (null == e && (e = !1),
                    null == this.view)
                        return a.track.manhattanStatusSet(e),
                        t = {
                            FallbackView: r,
                            IframeView: i,
                            TabView: o
                        }[this.forceView],
                        u = function() {
                            switch (!1) {
                            case !t:
                                return t;
                            case !s.isFallback():
                                return r;
                            case !this.shouldPopup:
                                return o;
                            default:
                                return i
                            }
                        }
                        .call(this),
                        n = (n = function() {
                            switch (!1) {
                            case u !== r:
                                return "/v3/fallback/24sqJdoVPlgsECQUwS9Nw.html";
                            case !e:
                                return "/m/v3/index-567f7a5e4a9d05cffdab.html";
                            default:
                                return "/v3/jDnNl6JuCwDhUeV74LrwEQ.html"
                            }
                        }()) + "?distinct_id=" + a.getDistinctID(),
                        this.forceAppType && (n = n + "?force_app_type=" + this.forceAppType),
                        this.view = new u(this.onToken,this.host,n),
                        null != this.preloadOptions ? (this.view.preload(this.preloadOptions),
                        this.preloadOptions = null) : void 0
                }
                ,
                e.prototype.open = function(t) {
                    var n, r;
                    return null == t && (t = {}),
                    r = this,
                    n = function() {
                        var n;
                        return r.opened = !0,
                        e.activeView && e.activeView !== r.view && e.activeView.close(),
                        e.activeView = r.view,
                        t.supportsTokenCallback = r.tokenCallback.supportsTokenCallback(),
                        n = function() {
                            if (this.view instanceof o)
                                return this.view = new i(this.onToken,this.host,"/v3/jDnNl6JuCwDhUeV74LrwEQ.html"),
                                this.open(t)
                        }
                        ,
                        s.isiOSChrome() && !s.isUserGesture() ? n() : r.view.open(t, function(e) {
                            if (!e)
                                return n()
                        })
                    }
                    ,
                    this.manhattanPending ? this.shouldPopup ? (this.createView(),
                    n()) : this.manhattanCallbacks.push(n) : n()
                }
                ,
                e.prototype.close = function() {
                    var e;
                    return null != (e = this.view) ? e.close() : void 0
                }
                ,
                e.prototype.preload = function(e) {
                    return null != this.view ? this.view.preload(e) : this.preloadOptions = e
                }
                ,
                e.prototype.onTokenCallback = function() {
                    return this.view.triggerTokenCallback.apply(this.view, arguments)
                }
                ,
                e.prototype.invokeCallbacks = function() {
                    var e, t, n;
                    for (e = 0,
                    t = (n = this.manhattanCallbacks).length; e < t; e++)
                        (0,
                        n[e])();
                    return this.manhattanCallbacks = [],
                    this.manhattanPending = !1
                }
                ,
                e.prototype.isLegacyIe = function() {
                    return !(null != window.XMLHttpRequest && null != (new XMLHttpRequest).withCredentials)
                }
                ,
                e.prototype.shouldUseManhattan = function(e, t) {
                    var n, r, i, o, a, u;
                    if (this.manhattanPending = !0,
                    setTimeout((u = this,
                    function() {
                        return u.createView(),
                        u.invokeCallbacks()
                    }
                    ), 3e3),
                    s.isFallback())
                        return e(this.forceManhattan),
                        void this.invokeCallbacks();
                    if (null != this.manhattanFlagState && (e(this.manhattanFlagState),
                    this.invokeCallbacks()),
                    n = function(e) {
                        return function(t) {
                            var n;
                            try {
                                return n = JSON.parse(t),
                                !0 === e.forceManhattan ? e.manhattanFlagState = e.forceManhattan : e.manhattanFlagState = !!n.is_on
                            } catch (t) {
                                return e.manhattanFlagState = !1
                            }
                        }
                    }(this),
                    this.isLegacyIe()) {
                        if ("https:" !== window.location.protocol)
                            return void e();
                        (i = new window.XDomainRequest).onload = function(t) {
                            return function() {
                                try {
                                    n(i.responseText),
                                    e(t.manhattanFlagState)
                                } catch (t) {
                                    e()
                                }
                                return t.invokeCallbacks()
                            }
                        }(this)
                    } else
                        (i = new XMLHttpRequest).onreadystatechange = function(t) {
                            return function() {
                                if (4 === i.readyState)
                                    return 200 === i.status ? n(i.responseText) : t.manhattanFlagState = !1,
                                    e(t.manhattanFlagState),
                                    t.invokeCallbacks()
                            }
                        }(this);
                    for (r in o = this.host + "/api/outer/manhattan",
                    t)
                        a = t[r],
                        "token" !== r && "opened" !== r && "closed" !== r && (o = s.addQueryParameter(o, r, a));
                    return i.open("GET", o, !0),
                    i.send()
                }
                ,
                e
            }(),
            n.exports = e
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "outer/controllers/tokenCallback": function(e, t, n) {
        (function() {
            var e, t = function(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            };
            e = function() {
                function e(e) {
                    this.supportsTokenCallback = t(this.supportsTokenCallback, this),
                    this.trigger = t(this.trigger, this),
                    e.token ? (this.fn = e.token,
                    this.version = 1) : e.onToken && (this.fn = e.onToken,
                    this.version = 2)
                }
                return e.prototype.trigger = function(e, t, n) {
                    var r, i, o, s;
                    if (2 === this.version) {
                        for (i in r = {
                            token: e
                        },
                        o = null,
                        t)
                            s = t[i],
                            /^shipping_/.test(i) && (null == o && (o = {}),
                            o[i.replace(/^shipping_/, "")] = s);
                        return null != o && (r.shipping = o),
                        this.fn(r, n)
                    }
                    return this.fn(e, t)
                }
                ,
                e.prototype.supportsTokenCallback = function() {
                    return this.version > 1
                }
                ,
                e
            }(),
            n.exports = e
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "outer/views/fallbackView": function(e, t, n) {
        (function() {
            var e, r, i, o = function(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            }, s = {}.hasOwnProperty;
            e = t("outer/lib/fallbackRpc"),
            i = t("outer/views/view"),
            r = function(t) {
                function n() {
                    this.triggerTokenCallback = o(this.triggerTokenCallback, this),
                    this.close = o(this.close, this),
                    this.open = o(this.open, this),
                    n.__super__.constructor.apply(this, arguments)
                }
                return function(e, t) {
                    for (var n in t)
                        s.call(t, n) && (e[n] = t[n]);
                    function r() {
                        this.constructor = e
                    }
                    r.prototype = t.prototype,
                    e.prototype = new r,
                    e.__super__ = t.prototype
                }(n, i),
                n.prototype.open = function(t, r) {
                    var i, o, s;
                    if (n.__super__.open.apply(this, arguments),
                    o = this.host + this.path,
                    this.frame = window.open(o, "stripe_checkout_app", "width=400,height=400,location=yes,resizable=yes,scrollbars=yes"),
                    null == this.frame)
                        throw alert("Disable your popup blocker to proceed with checkout."),
                        o = "https://stripe.com/docs/checkout#integration-more-runloop",
                        new Error("To learn how to prevent the Stripe Checkout popup from being blocked, please visit " + o);
                    return this.rpc = new e(this.frame,o),
                    this.rpc.receiveMessage((s = this,
                    function(e) {
                        var t;
                        try {
                            t = JSON.parse(e.data)
                        } catch (e) {
                            return
                        }
                        return s.onToken(t)
                    }
                    )),
                    i = JSON.stringify(this.options),
                    this.rpc.invokeTarget(i),
                    r(!0)
                }
                ,
                n.prototype.close = function() {
                    var e;
                    return null != (e = this.frame) ? e.close() : void 0
                }
                ,
                n.prototype.triggerTokenCallback = function(e) {
                    if (e)
                        return alert(e)
                }
                ,
                n
            }(),
            n.exports = r
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "outer/views/iframeView": function(e, t, n) {
        (function() {
            var e, r, i, o, s, a, u = function(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            }, c = {}.hasOwnProperty;
            a = t("outer/lib/utils"),
            o = t("lib/helpers"),
            r = t("lib/rpc"),
            i = t("outer/views/view"),
            s = t("vendor/ready"),
            e = function(e) {
                function t() {
                    return this.configure = u(this.configure, this),
                    this.removeFrame = u(this.removeFrame, this),
                    this.removeTouchOverlay = u(this.removeTouchOverlay, this),
                    this.showTouchOverlay = u(this.showTouchOverlay, this),
                    this.attachIframe = u(this.attachIframe, this),
                    this.setToken = u(this.setToken, this),
                    this.closed = u(this.closed, this),
                    this.close = u(this.close, this),
                    this.preload = u(this.preload, this),
                    this.opened = u(this.opened, this),
                    this.open = u(this.open, this),
                    t.__super__.constructor.apply(this, arguments)
                }
                return function(e, t) {
                    for (var n in t)
                        c.call(t, n) && (e[n] = t[n]);
                    function r() {
                        this.constructor = e
                    }
                    r.prototype = t.prototype,
                    e.prototype = new r,
                    e.__super__ = t.prototype
                }(t, i),
                t.prototype.open = function(e, n) {
                    return t.__super__.open.apply(this, arguments),
                    s((r = this,
                    function() {
                        var e, t, i;
                        return r.originalOverflowValue = document.body.style.overflow,
                        null == r.frame && r.configure(),
                        ("undefined" != typeof $ && null !== $ && null != (i = $.fn) ? i.modal : void 0) && $(document).off("focusin.bs.modal").off("focusin.modal"),
                        r.frame.style.display = "block",
                        r.shouldShowTouchOverlay() && (r.showTouchOverlay(),
                        e = window.scrollX || window.pageXOffset,
                        r.iframeWidth() < window.innerWidth && (e += (window.innerWidth - r.iframeWidth()) / 2),
                        r.frame.style.top = (window.scrollY || window.pageYOffset) + "px",
                        r.frame.style.left = e + "px"),
                        t = !1,
                        setTimeout(function() {
                            if (!t)
                                return t = !0,
                                n(!1),
                                r.removeFrame()
                        }, 8e3),
                        r.rpc.ready(function() {
                            if (!t)
                                return t = !0,
                                n(!0),
                                r.rpc.invoke("render", "", "iframe", r.options),
                                o.isIE() && (document.body.style.overflow = "hidden"),
                                r.rpc.invoke("open", {
                                    timeLoaded: r.options.timeLoaded
                                })
                        })
                    }
                    ));
                    var r
                }
                ,
                t.prototype.opened = function() {
                    var e;
                    return "function" == typeof (e = this.options).opened ? e.opened() : void 0
                }
                ,
                t.prototype.preload = function(e) {
                    return s((t = this,
                    function() {
                        return t.configure(),
                        t.rpc.invoke("preload", e)
                    }
                    ));
                    var t
                }
                ,
                t.prototype.iframeWidth = function() {
                    return o.isSmallScreen() ? 328 : 380
                }
                ,
                t.prototype.close = function() {
                    if (this.rpc.target.window)
                        return this.rpc.invoke("close")
                }
                ,
                t.prototype.closed = function(e) {
                    var t, n;
                    return t = null != this.token,
                    document.body.style.overflow = this.originalOverflowValue,
                    this.removeFrame(),
                    clearTimeout(this.tokenTimeout),
                    t && this.onToken(this.token),
                    this.token = null,
                    "function" == typeof (n = this.options).closed && n.closed(),
                    "error.close" === (null != e ? e.type : void 0) ? alert(e.message) : t ? void 0 : this.preload(this.options)
                }
                ,
                t.prototype.setToken = function(e) {
                    return this.token = e,
                    null != this.tokenTimeout ? this.tokenTimeout : this.tokenTimeout = setTimeout((t = this,
                    function() {
                        return t.onToken(t.token),
                        t.tokenTimeout = null,
                        t.token = null
                    }
                    ), 3e3);
                    var t
                }
                ,
                t.prototype.attachIframe = function() {
                    var e, t;
                    return (t = document.createElement("iframe")).setAttribute("frameBorder", "0"),
                    t.setAttribute("allowtransparency", "true"),
                    e = "z-index: 2147483647;\ndisplay: none;\nbackground: transparent;\nbackground: rgba(0,0,0,0.005);\nborder: 0px none transparent;\noverflow-x: hidden;\noverflow-y: auto;\nvisibility: hidden;\nmargin: 0;\npadding: 0;\n-webkit-tap-highlight-color: transparent;\n-webkit-touch-callout: none;",
                    this.shouldShowTouchOverlay() ? e += "position: absolute;\nwidth: " + this.iframeWidth() + "px;\nheight: " + document.body.scrollHeight + "px;" : e += "position: fixed;\nleft: 0;\ntop: 0;\nwidth: 100%;\nheight: 100%;",
                    t.style.cssText = e,
                    o.bind(t, "load", function() {
                        return t.style.visibility = "visible"
                    }),
                    t.src = this.host + this.path,
                    t.className = t.name = "stripe_checkout_app",
                    a.append(document.body, t),
                    t
                }
                ,
                t.prototype.showTouchOverlay = function() {
                    if (!this.overlay)
                        return this.overlay = document.createElement("div"),
                        this.overlay.style.cssText = "z-index: 2147483646;\nbackground: #000;\nopacity: 0;\nborder: 0px none transparent;\noverflow: none;\nmargin: 0;\npadding: 0;\n-webkit-tap-highlight-color: transparent;\n-webkit-touch-callout: none;\ntransition: opacity 320ms ease;\n-webkit-transition: opacity 320ms ease;\n-moz-transition: opacity 320ms ease;\n-ms-transition: opacity 320ms ease;",
                        this.overlay.style.position = "absolute",
                        this.overlay.style.left = 0,
                        this.overlay.style.top = 0,
                        this.overlay.style.width = document.body.scrollWidth + "px",
                        this.overlay.style.height = document.body.scrollHeight + "px",
                        a.append(document.body, this.overlay),
                        this.overlay.offsetHeight,
                        this.overlay.style.opacity = "0.5"
                }
                ,
                t.prototype.removeTouchOverlay = function() {
                    var e;
                    if (this.overlay)
                        return (e = this.overlay).style.opacity = "0",
                        setTimeout(function() {
                            return a.remove(e)
                        }, 400),
                        this.overlay = null
                }
                ,
                t.prototype.removeFrame = function() {
                    var e;
                    return this.shouldShowTouchOverlay() && this.removeTouchOverlay(),
                    e = this.frame,
                    setTimeout(function() {
                        return a.remove(e)
                    }, 500),
                    this.frame = null
                }
                ,
                t.prototype.configure = function() {
                    return null != this.frame && this.removeFrame(),
                    this.frame = this.attachIframe(),
                    this.rpc = new r(this.frame.contentWindow,{
                        host: this.host
                    }),
                    this.rpc.methods.closed = this.closed,
                    this.rpc.methods.setToken = this.setToken,
                    this.rpc.methods.opened = this.opened
                }
                ,
                t.prototype.shouldShowTouchOverlay = function() {
                    return o.isSupportedMobileOS()
                }
                ,
                t
            }(),
            n.exports = e
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "outer/views/tabView": function(e, t, n) {
        (function() {
            var e, r, i, o, s = function(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            }, a = {}.hasOwnProperty;
            e = t("lib/rpc"),
            o = t("lib/helpers"),
            i = t("outer/views/view"),
            r = function(t) {
                function n() {
                    this.closed = s(this.closed, this),
                    this.checkForClosedTab = s(this.checkForClosedTab, this),
                    this.setToken = s(this.setToken, this),
                    this.fullPath = s(this.fullPath, this),
                    this.close = s(this.close, this),
                    this.open = s(this.open, this),
                    n.__super__.constructor.apply(this, arguments),
                    this.closedTabInterval = null,
                    this.color = null,
                    this.colorSet = !1
                }
                return function(e, t) {
                    for (var n in t)
                        a.call(t, n) && (e[n] = t[n]);
                    function r() {
                        this.constructor = e
                    }
                    r.prototype = t.prototype,
                    e.prototype = new r,
                    e.__super__ = t.prototype
                }(n, i),
                n.prototype.open = function(t, r) {
                    var i, s, a, u, c, l;
                    n.__super__.open.apply(this, arguments);
                    try {
                        null != (u = this.frame) && u.close()
                    } catch (e) {}
                    return "stripe_checkout_tabview" === window.name && (window.name = ""),
                    i = o.isiOSChrome() ? "_blank" : "stripe_checkout_tabview",
                    this.frame = window.open(this.fullPath(), i),
                    this.frame || -1 === (null != (c = this.options.key) ? c.indexOf("test") : void 0) || (s = "https://stripe.com/docs/checkout#integration-more-runloop",
                    console.error("Stripe Checkout was unable to open a new window, possibly due to a popup blocker.\nTo provide the best experience for your users, follow the guide at " + s + ".\nThis message will only appear when using a test publishable key.")),
                    this.frame && this.frame !== window ? ("function" == typeof (a = this.frame).focus && a.focus(),
                    this.rpc = new e(this.frame,{
                        host: this.host
                    }),
                    this.rpc.methods.setToken = this.setToken,
                    this.rpc.methods.closed = this.closed,
                    this.rpc.ready((l = this,
                    function() {
                        var e;
                        return r(!0),
                        l.rpc.invoke("render", "", "tab", l.options),
                        l.rpc.invoke("open"),
                        "function" == typeof (e = l.options).opened && e.opened(),
                        l.checkForClosedTab()
                    }
                    ))) : (this.close(),
                    void r(!1))
                }
                ,
                n.prototype.close = function() {
                    if (this.frame && this.frame !== window)
                        return this.frame.close()
                }
                ,
                n.prototype.fullPath = function() {
                    return this.host + this.path
                }
                ,
                n.prototype.setToken = function(e) {
                    return this.token = e,
                    null != this.tokenTimeout ? this.tokenTimeout : this.tokenTimeout = setTimeout((t = this,
                    function() {
                        return t.onToken(t.token),
                        t.tokenTimeout = null,
                        t.token = null
                    }
                    ), 3e3);
                    var t
                }
                ,
                n.prototype.checkForClosedTab = function() {
                    return this.closedTabInterval && clearInterval(this.closedTabInterval),
                    this.closedTabInterval = setInterval((e = this,
                    function() {
                        if (!e.frame || !e.frame.postMessage || e.frame.closed)
                            return e.closed()
                    }
                    ), 100);
                    var e
                }
                ,
                n.prototype.closed = function() {
                    var e;
                    return clearInterval(this.closedTabInterval),
                    clearTimeout(this.tokenTimeout),
                    null != this.token && this.onToken(this.token),
                    "function" == typeof (e = this.options).closed ? e.closed() : void 0
                }
                ,
                n
            }(),
            n.exports = r
        }
        ).call(this)
    }
}),
StripeCheckout.require.define({
    "outer/views/view": function(e, t, n) {
        (function() {
            var e, t = function(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            }, r = [].slice;
            e = function() {
                function e(e, n, r) {
                    this.triggerTokenCallback = t(this.triggerTokenCallback, this),
                    this.open = t(this.open, this),
                    this.onToken = e,
                    this.host = n,
                    this.path = r
                }
                return e.prototype.open = function(e, t) {
                    return this.options = e
                }
                ,
                e.prototype.close = function() {}
                ,
                e.prototype.preload = function(e) {}
                ,
                e.prototype.triggerTokenCallback = function() {
                    var e, t;
                    return e = arguments,
                    this.rpc.ready((t = this,
                    function() {
                        var n;
                        return (n = t.rpc).invoke.apply(n, ["tokenCallback"].concat(r.call(e)))
                    }
                    ))
                }
                ,
                e
            }(),
            n.exports = e
        }
        ).call(this)
    }
}),
function() {
    var e, t, n, r, i, o, s, a, u;
    t = (r = r || this.StripeCheckout.require)("outer/controllers/button"),
    e = r("outer/controllers/app"),
    null == (null != (i = this.StripeCheckout) ? i.__app : void 0) && (this.StripeCheckout || (this.StripeCheckout = {}),
    this.StripeCheckout.__app = n = new e,
    this.StripeCheckout.open = n.open,
    this.StripeCheckout.configure = n.configure,
    this.StripeButton = this.StripeCheckout,
    null != (null != (o = this.StripeCheckout) ? o.__forceManhattan : void 0) && n.setForceManhattan(this.StripeCheckout.__forceManhattan),
    null != (null != (s = this.StripeCheckout) ? s.__forceView : void 0) && n.setForceView(this.StripeCheckout.__forceView),
    null != (null != (a = this.StripeCheckout) ? a.__forceAppType : void 0) && n.setForceAppType(this.StripeCheckout.__forceAppType),
    (null != (u = this.StripeCheckout) ? u.__host : void 0) && "" !== this.StripeCheckout.__host && n.setHost(this.StripeCheckout.__host)),
    t.load(this.StripeCheckout.__app)
}
.call(this);
