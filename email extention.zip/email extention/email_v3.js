var Gmail = function(e) {
    var t;
    if (void 0 !== e)
        t = e;
    else if ("undefined" != typeof jQuery)
        t = jQuery;
    else
        try {
            t = require("jquery")
        } catch (e) {}
    var r = "undefined" != typeof window ? window.opener : null;
    if (r)
        try {
            r.document.domain !== window.document.domain && (console.warn("GmailJS: window.opener domain differs from window domain."),
            r = null)
        } catch (e) {
            console.warn("GmailJS: Unable to access window.opener!", e),
            r = null
        }
    var a = {
        get: {},
        observe: {},
        check: {
            data: {}
        },
        tools: {},
        tracker: {},
        dom: {},
        chat: {},
        compose: {},
        helper: {
            get: {}
        }
    };
    function o(e="Migrate to new API compatible with new Gmail to silence this warning!") {
        a.DISABLE_OLD_GMAIL_API_DEPRECATION_WARNINGS || console.warn("GmailJS: using deprecated API for old Gmail.", e)
    }
    a.DISABLE_OLD_GMAIL_API_DEPRECATION_WARNINGS = !1,
    a.version = "0.8.0",
    a.tracker.globals = "undefined" != typeof GLOBALS ? GLOBALS : r && r.GLOBALS || [],
    a.tracker.view_data = "undefined" != typeof VIEW_DATA ? VIEW_DATA : r && r.VIEW_DATA || [],
    a.tracker.ik = a.tracker.globals[9] || "",
    a.tracker.hangouts = void 0,
    a.cache = {},
    a.cache.debug_xhr_fetch = !1,
    a.cache.emailIdCache = {},
    a.cache.emailLegacyIdCache = {},
    a.cache.threadCache = {},
    a.get.last_active = function() {
        var e = a.tracker.globals[17][15];
        return {
            time: e[1],
            ip: e[3],
            mac_address: e[9],
            time_relative: e[10]
        }
    }
    ,
    a.get.user_email = function() {
        return a.tracker.globals[10]
    }
    ,
    a.helper.get.is_locale = function(e) {
        if (!e || "string" != typeof e || e.length < 2)
            return !1;
        if (e.match(/[0-9]/))
            return !1;
        var t = e.slice(0, 2);
        return t.toLowerCase() === t || t.toUpperCase() === t
    }
    ,
    a.helper.filter_locale = function(e) {
        return a.helper.get.is_locale(e) ? e.substring(0, 2).toLowerCase() : null
    }
    ,
    a.helper.array_starts_with = function(e, t) {
        return !!(e && e.length > 0 && e[0] === t)
    }
    ,
    a.helper.get.array_sublist = function(e, t) {
        if (e)
            for (var r = 0; r < e.length; r++) {
                var o = e[r];
                if (a.helper.array_starts_with(o, t))
                    return o
            }
        return null
    }
    ,
    a.helper.get.locale_from_url_params = function(e) {
        if (e && e.indexOf && (0 === e.indexOf("https://") || 0 === e.indexOf("http://"))) {
            var t = e.split("?");
            if (t.length > 1)
                for (var r = t[1].split("&"), a = 0; a < r.length; a++) {
                    var o = r[a].split("=");
                    if (2 === o.length && "hl" === o[0])
                        return o[1]
                }
        }
        return null
    }
    ,
    a.helper.get.locale_from_globals_item = function(e) {
        if (!e)
            return null;
        for (var t = 0; t < e.length; t++) {
            var r = e[t]
              , o = a.helper.get.locale_from_url_params(r);
            if (o)
                return o
        }
        return e[8]
    }
    ,
    a.get.localization = function() {
        var e = a.tracker.globals
          , t = a.helper.get.array_sublist(e[17], "ui");
        if (null !== t && t.length > 8) {
            let e = a.helper.get.locale_from_globals_item(t);
            if (e = a.helper.filter_locale(e))
                return e
        }
        if (null !== e[12]) {
            let t = a.helper.get.locale_from_url_params(e[12]);
            if (t = a.helper.filter_locale(t))
                return t
        }
        if (e[4]) {
            let t = e[4].split(".")[1];
            if (t = a.helper.filter_locale(t))
                return t
        }
        return null
    }
    ,
    a.check.is_new_data_layer = function() {
        return "true" === window.GM_SPT_ENABLED
    }
    ,
    a.check.is_new_gui = function() {
        return "true" === window.GM_RFT_ENABLED
    }
    ,
    a.check.is_thread = function() {
        var e = t(".nH .if").children(":eq(1)").children().children(":eq(1)").children()
          , r = a.get.email_ids();
        return e.length > 1 || r.length > 1
    }
    ,
    a.check.is_peoplekit_compose = function(e) {
        return 0 !== t(e).find("div[name=to] input[peoplekit-id]").length
    }
    ,
    a.dom.inbox_content = function() {
        return t("div[role=main]:first")
    }
    ,
    a.check.is_preview_pane = function() {
        var e = !1;
        return a.dom.inbox_content().find("[gh=tl]").each(function() {
            t(this).hasClass("aia") && (e = !0)
        }),
        e
    }
    ,
    a.check.is_multiple_inbox = function() {
        return a.dom.inboxes().length > 1
    }
    ,
    a.check.is_horizontal_split = function() {
        return 0 === a.dom.inbox_content().find("[gh=tl]").find(".nn").length
    }
    ,
    a.check.is_vertical_split = function() {
        return !1 === a.check.is_horizontal_split()
    }
    ,
    a.check.is_tabbed_inbox = function() {
        return 1 === t(".aKh").length
    }
    ,
    a.check.is_right_side_chat = function() {
        var e = t(".ApVoH");
        return 0 !== e.length && ":wf" === e[0].getAttribute("aria-labelledby")
    }
    ,
    a.check.should_compose_fullscreen = function() {
        console.warn("gmail.js: This function is known to be unreliable, and may be deprecated in a future release.");
        var e = [];
        try {
            e = a.tracker.globals[17][4][1][32]
        } catch (t) {
            e = ["bx_scfs", "false"]
        }
        return "true" === e[1]
    }
    ,
    a.check.is_google_apps_user = function() {
        var e = a.get.user_email();
        return -1 === e.indexOf("gmail.com", e.length - "gmail.com".length)
    }
    ,
    a.get.storage_info = function() {
        var e = document.querySelector(".md.mj div")
          , t = e.querySelectorAll("span")[0].textContent.replace(/,/g, ".")
          , r = e.querySelectorAll("span")[1].textContent.replace(/,/g, ".")
          , a = 100 * parseFloat(t.replace(/[^0-9\.]/g, "")) / parseFloat(r.replace(/[^0-9\.]/g, ""));
        return {
            used: t,
            total: r,
            percent: Math.floor(a)
        }
    }
    ,
    a.dom.inboxes = function() {
        return a.dom.inbox_content().find("[gh=tl]")
    }
    ,
    a.dom.email_subject = function() {
        for (var e = t(".hP"), r = 0; r < e.length; r++)
            if (t(e[r]).is(":visible"))
                return t(e[r]);
        return t()
    }
    ,
    a.get.email_subject = function() {
        return a.dom.email_subject().text()
    }
    ,
    a.dom.email_body = function() {
        return t(".nH.hx")
    }
    ,
    a.dom.toolbar = function() {
        for (var e = t("[gh='mtb']"); 1 === t(e).children().length; )
            e = t(e).children().first();
        return e
    }
    ,
    a.dom.right_toolbar = function() {
        for (var e = t("[gh='tm'] [gh='s']").parent(); 1 === t(e).children().length; )
            e = t(e).children().first();
        return e
    }
    ,
    a.check.is_inside_email = function() {
        if ("email" !== a.get.current_page() && !a.check.is_preview_pane())
            return !1;
        for (var e = t(".ii.gt .a3s"), r = [], o = 0; o < e.length; o++) {
            var n = e[o].getAttribute("class").split(" ")[2];
            "undefined" !== n && void 0 !== n && r.push(e[o])
        }
        return r.length > 0
    }
    ,
    a.check.is_plain_text = function() {
        for (var e = a.tracker.globals[17][4][1], t = 0; t < e.length; t++) {
            var r = e[t];
            if ("bx_cm" === r[0])
                return "0" === r[1]
        }
        return !1
    }
    ,
    a.dom.email_contents = function() {
        for (var e = t(".ii.gt div.a3s.aXjCH"), r = [], a = 0; a < e.length; a++) {
            var o = e[a].getAttribute("class").split(" ")[2]
              , n = e[a].getAttribute("contenteditable");
            "undefined" !== o && void 0 !== o && "true" !== n && r.push(e[a])
        }
        return r
    }
    ,
    a.get.email_ids = function() {
        if (o(),
        a.check.is_inside_email()) {
            var e = a.get.email_data();
            return Object.keys(e.threads)
        }
        return []
    }
    ,
    a.get.compose_ids = function() {
        for (var e = [], r = t(".M9 [name=draft]"), a = 0; a < r.length; a++)
            "undefined" !== r[a].value && e.push(r[a].value);
        return e
    }
    ,
    a.get.thread_id = function() {
        o();
        const e = document.querySelector("h2[data-legacy-thread-id]");
        return null !== e ? e.dataset.legacyThreadId : void 0
    }
    ,
    a.get.email_id = function() {
        return o(),
        a.get.thread_id()
    }
    ,
    a.check.is_priority_inbox = function() {
        return t(".qh").length > 0
    }
    ,
    a.check.is_rapportive_installed = function() {
        return 1 === t("#rapportive-sidebar").length
    }
    ,
    a.check.is_streak_installed = function() {
        return t("[id^='bentoBox'],[id*=' bentoBox'],[class*=' bentoBox'],[class*='bentoBox']").length > 0
    }
    ,
    a.check.is_anydo_installed = function() {
        return t("[id^='anydo'],[id*=' anydo'],[class*=' anydo'],[class*='anydo']").length > 0
    }
    ,
    a.check.is_boomerang_installed = function() {
        return t("[id^='b4g_'],[id*=' b4g_'],[class*=' b4g_'],[class*='b4g_']").length > 0
    }
    ,
    a.check.is_xobni_installed = function() {
        return t("#xobni_frame").length > 0
    }
    ,
    a.check.is_signal_installed = function() {
        return t("[id^='Signal'],[id*=' Signal'],[class*=' signal'],[class*='signal']").length > 0
    }
    ,
    a.check.are_shortcuts_enabled = function() {
        for (var e = void 0, t = !0, r = a.tracker.globals[17][4][1], o = 0; o < r.length; o++) {
            var n = r[o];
            if ("bx_hs" === n[0]) {
                e = n[1];
                break
            }
        }
        if (void 0 !== e) {
            t = {
                0: !0,
                1: !1
            }[e]
        }
        return t
    }
    ,
    a.dom.get_left_sidebar_links = function() {
        return t("div[role=navigation] [title]")
    }
    ,
    a.dom.header = function() {
        return t("#gb")
    }
    ,
    a.dom.search_bar = function() {
        return t("[gh=sb]")
    }
    ,
    a.get.search_query = function() {
        return a.dom.search_bar().find("input")[0].value
    }
    ,
    a.get.unread_inbox_emails = function() {
        return a.helper.get.navigation_count("inbox")
    }
    ,
    a.get.unread_draft_emails = function() {
        return a.helper.get.navigation_count("drafts")
    }
    ,
    a.get.unread_spam_emails = function() {
        return a.helper.get.navigation_count("spam")
    }
    ,
    a.get.unread_forum_emails = function() {
        return a.helper.get.navigation_count("forums")
    }
    ,
    a.get.unread_update_emails = function() {
        return a.helper.get.navigation_count("updates")
    }
    ,
    a.get.unread_promotion_emails = function() {
        return a.helper.get.navigation_count("promotions")
    }
    ,
    a.get.unread_social_emails = function() {
        return a.helper.get.navigation_count("social_updates")
    }
    ,
    a.helper.get.navigation_count = function(e) {
        const r = a.tools.i18n(e)
          , o = t("div[role=navigation]").find("[title*='" + r + "']");
        if ((o || o.length > 0) && -1 !== o[0].title.indexOf(r)) {
            const e = parseInt(o[0].attributes["aria-label"].value.replace(/[^0-9]/g, ""));
            if (!isNaN(e))
                return e
        }
        return 0
    }
    ,
    a.get.beta = function() {
        return {
            new_nav_bar: 0 === t("#gbz").length
        }
    }
    ,
    a.get.unread_emails = function() {
        return {
            inbox: a.get.unread_inbox_emails(),
            drafts: a.get.unread_draft_emails(),
            spam: a.get.unread_spam_emails(),
            forum: a.get.unread_forum_emails(),
            update: a.get.unread_update_emails(),
            promotions: a.get.unread_promotion_emails(),
            social: a.get.unread_social_emails()
        }
    }
    ,
    a.tools.error = function(e) {
        if (!console)
            throw e;
        console.error(e)
    }
    ,
    a.tools.parse_url = function(e) {
        for (var t = /[?&]([^=#]+)=([^&#]*)/g, r = {}, a = t.exec(e); a; )
            r[a[1]] = a[2],
            a = t.exec(e);
        return r
    }
    ,
    a.tools.sleep = function(e) {
        for (var t = (new Date).getTime(); !((new Date).getTime() - t > e); )
            ;
    }
    ,
    a.tools.multitry = function(e, t, r, o, n, i) {
        if (void 0 !== n && n >= t)
            return i;
        n = void 0 === n ? 0 : n;
        var s = r();
        if (o(s))
            return s;
        a.tools.sleep(e),
        a.tools.multitry(e, t, r, o, n + 1, s)
    }
    ,
    a.tools.deparam = function(e, t) {
        var r = Array.isArray || function(e) {
            return "[object Array]" === Object.prototype.toString.call(e)
        }
          , a = {}
          , o = {
            true: !0,
            false: !1,
            null: null
        };
        return function(e, t) {
            for (var r = [], a = 0; a < e.length; a++)
                r.push(t(e[a]))
        }(e.replace(/\+/g, " ").split("&"), function(e, n) {
            var i, s = e.split("="), l = decodeURIComponent(s[0]), c = a, d = 0, u = l.split("]["), _ = u.length - 1;
            if (/\[/.test(u[0]) && /\]$/.test(u[_]) ? (u[_] = u[_].replace(/\]$/, ""),
            _ = (u = u.shift().split("[").concat(u)).length - 1) : _ = 0,
            2 === s.length)
                if (i = decodeURIComponent(s[1]),
                t && (i = i && !isNaN(i) ? +i : "undefined" === i ? void 0 : void 0 !== o[i] ? o[i] : i),
                _)
                    for (; d <= _; d++)
                        c = c[l = "" === u[d] ? c.length : u[d]] = d < _ ? c[l] || (u[d + 1] && isNaN(u[d + 1]) ? {} : []) : i;
                else
                    r(a[l]) ? a[l].push(i) : void 0 !== a[l] ? a[l] = [a[l], i] : a[l] = i;
            else
                l && (a[l] = t ? void 0 : "")
        }),
        a
    }
    ,
    a.tools.get_pathname_from_url = function(e) {
        if ("undefined" != typeof document) {
            const t = document.createElement("a");
            return t.href = e,
            t.pathname
        }
        return e
    }
    ,
    a.tools.parse_actions = function(e, t) {
        if ("fup" === e.url.act || "fuv" === e.url.act || e.body_is_object)
            return !(!e.body_is_object || !a.observe.bound("upload_attachment")) && {
                upload_attachment: [e.body_params]
            };
        e.url.search;
        var r = {}
          , o = {
            tae: "add_to_tasks",
            "rc_^i": "archive",
            tr: "delete",
            dm: "delete_message_in_thread",
            dl: "delete_forever",
            dc_: "delete_label",
            dr: "discard_draft",
            el: "expand_categories",
            cffm: "filter_messages_like_these",
            arl: "label",
            mai: "mark_as_important",
            mani: "mark_as_not_important",
            us: "mark_as_not_spam",
            sp: "mark_as_spam",
            mt: "move_label",
            ib: "move_to_inbox",
            ig: "mute",
            rd: "read",
            sd: "save_draft",
            sm: "send_message",
            mo: "show_newly_arrived_message",
            st: "star",
            cs: "undo_send",
            ug: "unmute",
            ur: "unread",
            xst: "unstar",
            new_mail: "new_email",
            poll: "poll",
            refresh: "refresh",
            rtr: "restore_message_in_thread",
            open_email: "open_email",
            toggle_threads: "toggle_threads"
        };
        "string" == typeof e.url.ik && (a.tracker.ik = e.url.ik),
        "string" == typeof e.url.at && (a.tracker.at = e.url.at),
        "string" == typeof e.url.rid && -1 !== e.url.rid.indexOf("mail") && (a.tracker.rid = e.url.rid);
        var n = decodeURIComponent(e.url.act)
          , i = e.body_params
          , s = "string" == typeof i.t ? [i.t] : i.t
          , l = null;
        switch (n) {
        case "cs":
        case "ur":
        case "rd":
        case "tr":
        case "sp":
        case "us":
        case "ib":
        case "dl":
        case "st":
        case "xst":
        case "mai":
        case "mani":
        case "ig":
        case "ug":
        case "dr":
        case "mt":
        case "cffm":
        case "rc_^i":
            l = [s, e.url, e.body];
            break;
        case "arl":
        case "dc_":
            l = [s, e.url, e.body, e.url.acn];
            break;
        case "sd":
            l = [s, e.url, i];
            break;
        case "tae":
        case "sm":
            l = [e.url, e.body, i];
            break;
        case "el":
            l = [e.url, e.body, "1" === i.ex];
            break;
        case "dm":
        case "rtr":
        case "mo":
            l = [i.m, e.url, e.body]
        }
        return "string" == typeof e.url._reqid && "tl" === e.url.view && void 0 !== e.url.auto && (l = [e.url.th, e.url, e.body],
        a.observe.bound("new_email") && (r.new_email = l)),
        "cv" !== e.url.view && "ad" !== e.url.view || "string" != typeof e.url.th || "string" != typeof e.url.search || void 0 !== e.url.rid || (l = [e.url.th, e.url, e.body],
        a.observe.bound("open_email") && (r.open_email = l)),
        "cv" !== e.url.view && "ad" !== e.url.view || "object" != typeof e.url.th || "string" != typeof e.url.search || void 0 === e.url.rid || (l = [e.url.th, e.url, e.body],
        a.observe.bound("toggle_threads") && (r.toggle_threads = l)),
        "cv" !== e.url.view && "ad" !== e.url.view || "string" != typeof e.url.th || "string" != typeof e.url.search || void 0 === e.url.rid || void 0 !== e.url.msgs && (l = [e.url.th, e.url, e.body],
        a.observe.bound("toggle_threads") && (r.toggle_threads = l)),
        "string" == typeof e.url.SID && "string" == typeof e.url.zx && -1 !== e.body.indexOf("req0_") && (a.tracker.SID = e.url.SID,
        l = [e.url, e.body, i],
        a.observe.bound("poll") && (r.poll = l)),
        "string" == typeof e.url.ik && "string" == typeof e.url.search && 0 === e.body.length && "string" == typeof e.url._reqid && (l = [e.url, e.body, i],
        a.observe.bound("refresh") && (r.refresh = l)),
        l && o[n] && a.observe.bound(o[n]) && (r[o[n]] = l),
        "POST" === e.method && (r.http_event = [e]),
        a.check.is_new_data_layer() && a.tools.parse_request_payload(e, r),
        r
    }
    ,
    a.check.data.is_thread_id = function(e) {
        return e && "string" == typeof e && /^thread-[a|f]:/.test(e)
    }
    ,
    a.check.data.is_thread = function(e) {
        return e && "object" == typeof e && e[1] && a.check.data.is_thread_id(e[1])
    }
    ,
    a.check.data.is_email_id = function(e) {
        return e && "string" == typeof e && -1 === e.indexOf("bump-") && /^msg-[a|f]:/.test(e)
    }
    ,
    a.check.data.is_email = function(e) {
        return e && "object" == typeof e && e[1] && a.check.data.is_email_id(e[1])
    }
    ,
    a.check.data.is_legacy_email_id = function(e) {
        return e && "string" == typeof e && /^[0-9a-f]{16,}$/.test(e)
    }
    ,
    a.check.data.is_action = function(e) {
        return a.check.data.is_first_type_action(e) || a.check.data.is_second_type_action(e)
    }
    ,
    a.check.data.is_first_type_action = function(e) {
        return e && e[1] && Array.isArray(e[1]) && 1 === e[1].length && "string" == typeof e[1][0]
    }
    ,
    a.check.data.is_second_type_action = function(e) {
        return e && e[2] && Array.isArray(e[2]) && e[2].length && "string" == typeof e[2][0]
    }
    ,
    a.check.data.is_smartlabels_array = function(e) {
        if (!e || !Array.isArray(e) || 0 === e.length)
            return !1;
        for (let t of e) {
            if ("string" != typeof t)
                return !1;
            if (!/^\^[a-z]+/.test(t))
                return !1
        }
        return !0
    }
    ,
    a.check.data.is_json_string = function(e) {
        if (!e || "string" != typeof e)
            return !1;
        let t = e.trim();
        return t.startsWith("{") && t.endsWith("}") || t.startsWith("[") && t.endsWith("]")
    }
    ,
    a.tools.get_thread_id = function(e) {
        return a.check.data.is_thread(e) && e[1]
    }
    ,
    a.tools.get_thread_data = function(e) {
        return e && e[2] && "object" == typeof e[2] && e[2][7] && "object" == typeof e[2][7] && e[2][7]
    }
    ,
    a.tools.get_action = function(e) {
        return a.tools.get_first_type_action(e) || a.tools.get_second_type_action(e)
    }
    ,
    a.tools.get_first_type_action = function(e) {
        return e && e[1] && e[1].join("")
    }
    ,
    a.tools.get_second_type_action = function(e) {
        return e && e[2] && e[2].join("")
    }
    ,
    a.tools.get_message_ids = function(e) {
        return e && e[3] && Array.isArray(e[3]) && e[3]
    }
    ,
    a.tools.extract_from_graph = function(e, t) {
        const r = []
          , a = function(e) {
            try {
                return t(e)
            } catch (e) {
                return !1
            }
        }
          , o = function(e) {
            if (a(e))
                r.push(e);
            else
                for (let t in e) {
                    let n = e[t];
                    if (a(n))
                        r.push(n);
                    else if (Array.isArray(n))
                        for (let t of n)
                            o(t, e);
                    else
                        "object" == typeof n && o(n)
                }
        };
        return o(e),
        r
    }
    ,
    a.tools.check_event_type = function(e) {
        const t = {
            "^a": "archive",
            "^k": "delete",
            "^x_": "label",
            "^u^us": "read",
            "^u": "unread",
            "^us": "new_email",
            "^o": "open_email"
        }
          , r = a.tools.get_thread_data(e);
        if (r && a.check.data.is_action(r)) {
            const e = a.tools.get_action(r);
            return e.startsWith("^x_") && a.check.data.is_first_type_action(r) ? t["^x_"] : t[e]
        }
        return null
    }
    ,
    a.tools.parse_fd_bv_contacts = function(e) {
        if (!e || !Array.isArray(e))
            return [];
        const t = [];
        for (let r of e)
            t.push(a.tools.parse_fd_bv_contact(r));
        return t
    }
    ,
    a.tools.parse_fd_bv_is_draft = function(e) {
        try {
            return !!Array.isArray(e) && (e.includes("^r") && e.includes("^r_bt"))
        } catch (e) {
            return !1
        }
    }
    ,
    a.tools.parse_fd_bv_contact = function(e) {
        try {
            return {
                name: e[3],
                address: e[2]
            }
        } catch (e) {
            return null
        }
    }
    ,
    a.tools.parse_fd_attachments = function(e) {
        let t = [];
        if (Array.isArray(e))
            for (let r of e) {
                let e = r[1][4] || "";
                t.push({
                    attachment_id: r[1][2],
                    name: e[3],
                    type: e[4],
                    url: a.tools.check_fd_attachment_url(e[2]),
                    size: Number.parseInt(e[5])
                })
            }
        return t
    }
    ,
    a.tools.parse_fd_embedded_json_attachments = function(e) {
        let t = [];
        if (Array.isArray(e))
            for (let r of e)
                t.push({
                    attachment_id: r[4],
                    name: r[2],
                    type: r[1],
                    url: a.tools.check_fd_attachment_url(r[6]),
                    size: Number.parseInt(r[3])
                });
        return t
    }
    ,
    a.tools.check_fd_attachment_url = function(e) {
        var t = a.tracker.globals[7];
        return e && t && e.indexOf(t) < 0 && (e = e.replace("/mail/?", t + "?")),
        e
    }
    ,
    a.tools.parse_fd_request_html_payload = function(e) {
        let t = null;
        try {
            const r = e[2][6][2];
            for (let e of r)
                t = (t || "") + e[3][2]
        } catch (e) {}
        return t
    }
    ,
    a.tools.parse_fd_embedded_json_content_html = function(e) {
        let t = null;
        try {
            const r = e[9][2];
            for (let e of r)
                t = (t || "") + e[3][2]
        } catch (e) {}
        return t
    }
    ,
    a.tools.parse_fd_request_payload_get_email2 = function(e, t) {
        try {
            return e[2][2].filter(e => e[1] === t)[0]
        } catch (e) {
            return {}
        }
    }
    ,
    a.tools.parse_fd_embedded_json_get_email = function(e, t) {
        try {
            return e[2][5].filter(e => e[1] === t)[0]
        } catch (e) {
            return {}
        }
    }
    ,
    a.tools.parse_fd_request_payload = function(e) {
        let t = e[2];
        if (!t || !Array.isArray(t))
            return null;
        try {
            const e = []
              , r = t;
            for (let t of r) {
                const r = t[1];
                let o = t[3];
                for (let n of o) {
                    const o = n[1]
                      , i = a.tools.parse_fd_request_payload_get_email2(t, o)
                      , s = n[2][35]
                      , l = n[2][8]
                      , c = n[2][5]
                      , d = Number.parseInt(n[2][17])
                      , u = new Date(d)
                      , _ = a.tools.parse_fd_bv_is_draft(i[4])
                      , m = a.tools.parse_fd_request_html_payload(n)
                      , h = a.tools.parse_fd_attachments(n[2][14])
                      , f = n[2][11][17];
                    let p = a.tools.parse_fd_bv_contact(i[2]);
                    p || (p = {
                        address: f,
                        name: ""
                    });
                    const g = {
                        id: o,
                        is_draft: _,
                        legacy_email_id: s,
                        thread_id: r,
                        smtp_id: l,
                        subject: c,
                        timestamp: d,
                        content_html: m,
                        date: u,
                        from: p,
                        to: a.tools.parse_fd_bv_contacts(n[2][1]),
                        cc: a.tools.parse_fd_bv_contacts(n[2][2]),
                        bcc: a.tools.parse_fd_bv_contacts(n[2][3]),
                        attachments: h
                    };
                    a.cache.debug_xhr_fetch && (g.$email_node = n,
                    g.$thread_node = t),
                    e.push(g)
                }
            }
            return e
        } catch (e) {
            return console.warn("Gmail.js encountered an error trying to parse email-data on fd request!", e),
            null
        }
    }
    ,
    a.tools.parse_fd_embedded_json = function(e) {
        let t = e[2];
        if (!t || !Array.isArray(t))
            return null;
        try {
            const e = []
              , r = t;
            for (let t of r) {
                const r = t[2][4];
                let o = t[2][5];
                for (let n of o) {
                    const o = n[1]
                      , i = a.tools.parse_fd_embedded_json_get_email(t, o)
                      , s = n[56]
                      , l = n[14]
                      , c = n[8]
                      , d = a.tools.parse_fd_bv_is_draft(n[11])
                      , u = Number.parseInt(n[18])
                      , _ = new Date(u)
                      , m = a.tools.parse_fd_embedded_json_content_html(n)
                      , h = a.tools.parse_fd_embedded_json_attachments(n[12])
                      , f = n[19][17];
                    let p = a.tools.parse_fd_bv_contact(i[2]);
                    p || (p = {
                        address: f,
                        name: ""
                    });
                    const g = {
                        id: o,
                        is_draft: d,
                        legacy_email_id: s,
                        thread_id: r,
                        smtp_id: l,
                        subject: c,
                        timestamp: u,
                        content_html: m,
                        date: _,
                        from: p,
                        to: a.tools.parse_fd_bv_contacts(n[3]),
                        cc: a.tools.parse_fd_bv_contacts(n[4]),
                        bcc: a.tools.parse_fd_bv_contacts(n[5]),
                        attachments: h
                    };
                    a.cache.debug_xhr_fetch && (g.$email_node = n,
                    g.$thread_node = t),
                    e.push(g)
                }
            }
            return e
        } catch (e) {
            return console.warn("Gmail.js encountered an error trying to parse email-data on embedded json!", e),
            null
        }
    }
    ,
    a.tools.parse_bv_request_payload = function(e) {
        let t = e[3];
        if (!t || !Array.isArray(t))
            return null;
        try {
            const e = []
              , r = t;
            for (let t of r) {
                const r = t[1][1]
                  , o = t[1][4];
                let n = t[1][5];
                for (let i of n) {
                    const n = i[1]
                      , s = i[56]
                      , l = ""
                      , c = r
                      , d = Number.parseInt(i[18])
                      , u = new Date(d)
                      , _ = ""
                      , m = []
                      , h = {
                        id: n,
                        is_draft: a.tools.parse_fd_bv_is_draft(i[11]),
                        legacy_email_id: s,
                        thread_id: o,
                        smtp_id: l,
                        subject: c,
                        timestamp: d,
                        content_html: _,
                        date: u,
                        from: {
                            address: void 0 !== i[2][2] ? i[2][2] : "",
                            name: void 0 !== i[2][3] ? i[2][3] : ""
                        },
                        to: [],
                        cc: [],
                        bcc: [],
                        attachments: m
                    };
                    a.cache.debug_xhr_fetch && (h.$email_node = i,
                    h.$thread_node = t),
                    e.push(h)
                }
            }
            return e
        } catch (e) {
            return console.warn("Gmail.js encountered an error trying to parse email-data on bv request!", e),
            null
        }
    }
    ,
    a.tools.parse_bv_embedded_json = function(e) {
        let t = e[1][1];
        if (!t || !Array.isArray(t))
            return null;
        try {
            const e = []
              , r = t;
            for (let t of r) {
                const r = t[5][1]
                  , o = t[5][4];
                let n = t[5][5];
                for (let i of n) {
                    const n = i[1]
                      , s = i[56]
                      , l = ""
                      , c = r
                      , d = Number.parseInt(i[18])
                      , u = new Date(d)
                      , _ = ""
                      , m = []
                      , h = {
                        id: n,
                        is_draft: a.tools.parse_fd_bv_is_draft(i[11]),
                        legacy_email_id: s,
                        thread_id: o,
                        smtp_id: l,
                        subject: c,
                        timestamp: d,
                        content_html: _,
                        date: u,
                        from: {
                            address: void 0 !== i[2][2] ? i[2][2] : "",
                            name: void 0 !== i[2][3] ? i[2][3] : ""
                        },
                        to: [],
                        cc: [],
                        bcc: [],
                        attachments: m
                    };
                    a.cache.debug_xhr_fetch && (h.$email_node = i,
                    h.$thread_node = t),
                    e.push(h)
                }
            }
            return e
        } catch (e) {
            return console.warn("Gmail.js encountered an error trying to parse email-data on bv request!", e),
            null
        }
    }
    ,
    a.tools.parse_sent_message_html_payload = function(e) {
        let t = null;
        try {
            const r = e[9][2];
            for (let e of r)
                t = (t || "") + e[2]
        } catch (e) {}
        return t
    }
    ,
    a.tools.parse_sent_message_attachments = function(e) {
        let t = [];
        if (Array.isArray(e))
            for (let r of e)
                t.push({
                    id: r[5],
                    name: r[2],
                    type: r[1],
                    url: r[6],
                    size: Number.parseInt(r[3])
                });
        return t
    }
    ,
    a.tools.parse_sent_message_payload = function(e) {
        try {
            let t = e;
            const r = t[1]
              , o = t[8]
              , n = Number.parseInt(t[7])
              , i = new Date(n)
              , s = a.tools.parse_sent_message_html_payload(t)
              , l = t[9][7]
              , c = a.tools.parse_sent_message_attachments(t[12]);
            return {
                1: r,
                id: r,
                subject: o,
                timestamp: n,
                content_html: s,
                ishtml: l,
                date: i,
                from: a.tools.parse_fd_bv_contact(t[2]),
                to: a.tools.parse_fd_bv_contacts(t[3]),
                cc: a.tools.parse_fd_bv_contacts(t[4]),
                bcc: a.tools.parse_fd_bv_contacts(t[5]),
                attachments: c,
                email_node: e
            }
        } catch (e) {
            return console.warn("Gmail.js encountered an error trying to parse sent message!", e),
            null
        }
    }
    ,
    a.tools.parse_request_payload = function(e, t, r) {
        const o = a.tools.get_pathname_from_url(e.url_raw);
        if (!r && !o)
            return;
        const n = (o || "").endsWith("/i/s")
          , i = (o || "").endsWith("/i/fd");
        if (!r && !i && !n)
            return;
        i && (t.load_email_data = [null]);
        const s = a.tools.extract_from_graph(e, a.check.data.is_thread)
          , l = a.tools.extract_from_graph(e, a.check.data.is_email);
        for (let r of l)
            for (let o in r) {
                let n = r[o];
                if (a.check.data.is_smartlabels_array(n)) {
                    let o = a.tools.parse_sent_message_payload(r);
                    -1 !== n.indexOf("^pfg") ? t.send_message = [e.url, e.body, o] : n.indexOf("^scheduled") > -1 && (t.send_scheduled_message = [e.url, e.body, o])
                }
            }
        try {
            if (Array.isArray(s) && a.check.data.is_thread(s[0])) {
                const r = a.tools.check_event_type(s[0]);
                if (r) {
                    const o = s.map(e => a.tools.get_thread_data(e))
                      , n = s.map(e => a.tools.get_thread_id(e))
                      , i = o.map(e => a.tools.get_message_ids(e)).reduce( (e, t) => e.concat(t), []);
                    t[r] = [null, e.url, e.body, i, n]
                }
            }
        } catch (e) {
            console.error("Error: ", e)
        }
    }
    ,
    a.tools.parse_response = function(e) {
        if (a.check.data.is_json_string(e))
            try {
                return JSON.parse(e)
            } catch (e) {}
        if (e.startsWith("<!DOCTYPE html") || -1 !== e.indexOf("display:inline-block"))
            return [];
        let t = [];
        try {
            for (e = (e = e.replace(/\n/g, " ")).substring(e.indexOf("'") + 1, e.length); e.replace(/\s/g, "").length > 1; ) {
                let r = e.substring(0, e.indexOf("[")).replace(/\s/g, "");
                r || (r = e.length);
                let a = parseInt(r, 10) - 2 + e.indexOf("[")
                  , o = e.substring(e.indexOf("["), a)
                  , n = JSON.parse(o);
                t.push(n),
                e = (e = e.substring(e.indexOf("["), e.length)).substring(o.length, e.length)
            }
        } catch (e) {}
        return t
    }
    ,
    a.tools.parse_attachment_url = function(e) {
        var t = e.split(":");
        return {
            type: t[0],
            url: t[2] + ":" + t[3]
        }
    }
    ;
    var n = function(e, t) {
        for (var r in t)
            e[r] = t[r]
    }
      , i = function(e, t) {
        for (var r = 0; r < t.length; r++) {
            var a = t[r];
            e.push(a)
        }
        return e
    };
    a.tools.parse_requests = function(e, t) {
        e.url_raw = e.url,
        e.url = a.tools.parse_url(e.url),
        "object" == typeof e.body ? (e.body_params = e.body,
        e.body_is_object = !0) : a.check.data.is_json_string(e.body) ? e.body_params = JSON.parse(e.body) : void 0 !== e.body ? e.body_params = a.tools.deparam(e.body) : e.body_params = {},
        "object" != typeof a.tracker.events && "object" != typeof a.tracker.actions && (a.tracker.events = [],
        a.tracker.actions = []),
        a.tracker.events.unshift(e);
        var r = a.tools.parse_actions(e, t);
        return "POST" === e.method && "string" == typeof e.url.act && a.tracker.actions.unshift(e),
        a.tracker.events.length > 50 && a.tracker.events.pop(),
        a.tracker.actions.length > 10 && a.tracker.actions.pop(),
        r
    }
    ,
    a.tools.patch = function(e, t) {
        t(e)
    }
    ,
    a.tools.cache_email_data = function(e, t) {
        if (null === e)
            return;
        const r = a.cache;
        let o = !1;
        "fd_request_payload" !== t && "fd_embedded_json" !== t || (o = !0);
        for (let t of e) {
            void 0 === r.emailIdCache[t.id] ? (r.emailIdCache[t.id] = t,
            r.emailLegacyIdCache[t.legacy_email_id] = t) : o && (r.emailIdCache[t.id] = t,
            r.emailLegacyIdCache[t.legacy_email_id] = t);
            let e = r.threadCache[t.thread_id];
            if (e || (e = {
                thread_id: t.thread_id,
                emails: []
            },
            r.threadCache[t.thread_id] = e),
            0 === e.emails.filter(e => e.id === t.id).length)
                e.emails.push(t);
            else if (o) {
                let r = e.emails.findIndex(e => e.id === t.id);
                e.emails[r] = t
            }
        }
    }
    ,
    a.tools.xhr_watcher = function() {
        if (a.tracker.xhr_init)
            return;
        a.instanceId = Symbol("gmail-js-" + (performance ? performance.now() : Date.now())),
        a.tracker.xhr_init = !0;
        const e = a.helper.get_xhr_window();
        a.tools.patch(e.XMLHttpRequest.prototype.open, t => {
            e.XMLHttpRequest.prototype.open = function(e, r, o, n, i) {
                var s = t.apply(this, arguments);
                return this.xhrParams = {
                    method: e.toString(),
                    url: r.toString()
                },
                Object.defineProperty(this, a.instanceId, {
                    value: Object.freeze({
                        method: e.toString(),
                        url: r.toString()
                    })
                }),
                s
            }
        }
        ),
        a.tools.patch(e.XMLHttpRequest.prototype.send, r => {
            e.XMLHttpRequest.prototype.send = function(e) {
                var o = !1;
                if (this.xhrParams && (this.xhrParams.body = e,
                "string" != typeof this.xhrParams.url && this[a.instanceId] && this[a.instanceId].url && (this.xhrParams.url = this[a.instanceId].url,
                delete this.xhrParams.url_raw,
                delete this.xhrParams.body_params),
                o = a.tools.parse_requests(this.xhrParams, this)),
                a.observe.trigger("before", o, this) && (e = a.check.is_new_data_layer() ? arguments[0] = this.xhrParams.body_is_object ? this.xhrParams.body_params : JSON.stringify(this.xhrParams.body_params) : arguments[0] = this.xhrParams.body_is_object ? this.xhrParams.body_params : t.param(this.xhrParams.body_params, !0).replace(/\+/g, "%20")),
                a.observe.bound(o, "after") || a.check.is_new_data_layer()) {
                    var n = this.onreadystatechange
                      , i = this;
                    this.onreadystatechange = function(e) {
                        if (this.readyState === this.DONE) {
                            if ("" === e.target.responseType || "text" === e.target.responseType ? i.xhrResponse = a.tools.parse_response(e.target.responseText) : i.xhrResponse = e.target.response,
                            a.check.is_new_data_layer()) {
                                if (a.tools.get_pathname_from_url(i.xhrParams.url_raw).endsWith("/i/fd")) {
                                    let e = a.tools.parse_fd_request_payload(i.xhrResponse);
                                    void 0 !== e && null !== e && (a.tools.cache_email_data(e, "fd_request_payload"),
                                    o.load_email_data = [e])
                                }
                                if (a.tools.get_pathname_from_url(i.xhrParams.url_raw).endsWith("/i/bv")) {
                                    let e = a.tools.parse_bv_request_payload(i.xhrResponse);
                                    void 0 !== e && null !== e && (a.tools.cache_email_data(e, "bv_request_payload"),
                                    o.load_email_data = [e])
                                }
                            }
                            a.observe.trigger("after", o, i)
                        }
                        n && n.apply(this, arguments)
                    }
                }
                var s = r.apply(this, arguments);
                return a.observe.trigger("on", o, this),
                s
            }
        }
        )
    }
    ,
    a.tools.embedded_data_watcher = function() {
        if (!a.tracker.embedded_data_init) {
            a.tracker.embedded_data_init = !0;
            var e = window._GM_setData;
            window._GM_setData = function(t) {
                if (void 0 !== t && void 0 !== t.Cl6csf && void 0 !== t.Cl6csf[0] && void 0 !== t.Cl6csf[0][2]) {
                    let e = a.tools.parse_fd_embedded_json(JSON.parse(t.Cl6csf[0][2]));
                    a.tools.cache_email_data(e, "fd_embedded_json")
                }
                if (void 0 !== t && void 0 !== t.a6jdv && void 0 !== t.a6jdv[0] && void 0 !== t.a6jdv[0][2]) {
                    let e = a.tools.parse_bv_embedded_json(JSON.parse(t.a6jdv[0][2]));
                    a.tools.cache_email_data(e, "bv_embedded_json")
                }
                e(t)
            }
        }
    }
    ,
    a.helper.get_xhr_window = function() {
        if (a.check.is_new_gui())
            return top;
        var e = null;
        return top.document.getElementById("js_frame") ? e = top.document.getElementById("js_frame") : r && (e = r.top.document.getElementById("js_frame")),
        e || (e = r ? r.top : top),
        e.contentDocument ? e.contentDocument.defaultView : e
    }
    ,
    a.observe.http_requests = function() {
        return a.tracker.events
    }
    ,
    a.observe.actions = function() {
        return a.tracker.actions
    }
    ,
    a.observe.bind = function(e, t, r) {
        "object" != typeof a.tracker.watchdog && (a.tracker.watchdog = {
            before: {},
            on: {},
            after: {},
            dom: {}
        },
        a.tracker.bound = {}),
        "object" != typeof a.tracker.watchdog[e] && a.tools.error("api.observe.bind called with invalid type: " + e),
        "dom" !== e && a.tools.xhr_watcher(),
        "object" != typeof a.tracker.watchdog[e][t] && (a.tracker.watchdog[e][t] = []),
        a.tracker.watchdog[e][t].push(r),
        a.tracker.bound[t] = void 0 === a.tracker.bound[t] ? 1 : a.tracker.bound[t] + 1,
        a.tracker.bound[e] = void 0 === a.tracker.bound[e] ? 1 : a.tracker.bound[e] + 1
    }
    ,
    a.observe.on = function(e, t, r) {
        if (a.observe.on_dom(e, t))
            return !0;
        a.observe.bind("on", e, t),
        r && a.observe.after(e, t)
    }
    ,
    a.observe.before = function(e, t) {
        a.observe.bind("before", e, t)
    }
    ,
    a.observe.after = function(e, t) {
        a.observe.bind("after", e, t)
    }
    ,
    a.observe.bound = function(e, r) {
        if ("object" != typeof a.tracker.watchdog)
            return !1;
        if (e) {
            if ("object" == typeof e) {
                var o = !1;
                return t.each(e, function(e, t) {
                    "object" == typeof a.tracker.watchdog[r][e] && (o = !0)
                }),
                o
            }
            return r ? "object" == typeof a.tracker.watchdog[r][e] : a.tracker.bound[e] > 0
        }
        if (r)
            return a.tracker.bound[r] > 0;
        a.tools.error("api.observe.bound called with invalid args")
    }
    ,
    a.observe.off = function(e, r) {
        if ("object" != typeof a.tracker.watchdog)
            return !0;
        var o = r ? [r] : ["before", "on", "after", "dom"];
        t.each(o, function(r, o) {
            if ("object" != typeof a.tracker.watchdog[o])
                return !0;
            e ? "object" == typeof a.tracker.watchdog[o][e] && (a.tracker.bound[e] -= a.tracker.watchdog[o][e].length,
            a.tracker.bound[o] -= a.tracker.watchdog[o][e].length,
            delete a.tracker.watchdog[o][e]) : t.each(a.tracker.watchdog[o], function(e, t) {
                "object" == typeof a.tracker.watchdog[o][e] && (a.tracker.bound[e] -= a.tracker.watchdog[o][e].length,
                a.tracker.bound[o] -= a.tracker.watchdog[o][e].length,
                delete a.tracker.watchdog[o][e])
            })
        })
    }
    ,
    a.observe.trigger = function(e, r, o) {
        if (!r)
            return !1;
        var n = !1;
        return t.each(r, function(r, i) {
            i = t.extend([], i),
            "after" === e && i.push(o.xhrResponse),
            i.push(o),
            a.observe.bound(r, e) && (n = !0,
            t.each(a.tracker.watchdog[e][r], function(e, t) {
                t.apply(void 0, i)
            }))
        }),
        n
    }
    ,
    a.observe.trigger_dom = function(e, r, o) {
        o || (o = function(e, t) {
            t(e)
        }
        ),
        a.tracker.watchdog.dom[e] && t.each(a.tracker.watchdog.dom[e], function(e, t) {
            o(r, t)
        })
    }
    ,
    a.observe.initialize_dom_observers = function() {
        a.tracker.dom_observer_init = !0,
        a.tracker.supported_observers = ["view_thread", "view_email", "load_email_menu", "recipient_change", "compose"],
        a.tracker.dom_observers = {
            view_thread: {
                class: ["Bu", "nH"],
                sub_selector: "div.if",
                handler: function(e, t) {
                    t(e = new a.dom.thread(e))
                }
            },
            view_email: {
                class: ["Bu", "nH", ""],
                sub_selector: "div.adn",
                handler: function(e, t) {
                    t(e = new a.dom.email(e))
                }
            },
            load_email_menu: {
                class: "J-N",
                selector: "div[role=menu] div[role=menuitem]:first-child",
                handler: function(e, t) {
                    t(e = e.closest("div[role=menu]"))
                }
            },
            recipient_change: {
                class: ["vR", "afV"],
                handler: function(e, t) {
                    "object" != typeof a.tracker.recipient_matches && (a.tracker.recipient_matches = []),
                    a.tracker.recipient_matches.push(e),
                    setTimeout(function() {
                        if (!a.tracker.recipient_matches.length)
                            return;
                        let r = [];
                        a.tracker.recipient_matches.forEach(e => {
                            0 === r.length && (r = e.closest("div.M9"))
                        }
                        ),
                        0 === r.length && a.tools.error("Can't find composeRoot for " + e);
                        var o = new a.dom.compose(r)
                          , n = o.recipients();
                        t(o, n, a.tracker.recipient_matches),
                        a.tracker.recipient_matches = []
                    }, 100)
                }
            },
            compose: {
                class: "An",
                handler: function(e, t) {
                    var r = e;
                    if ((e = e.closest("div.M9")).length) {
                        if (!(e = new a.dom.compose(e)).is_inline())
                            r.closest("div.AD").find(".Ha").mouseup(function() {
                                return a.tracker.composeCancelledCallback && a.tracker.composeCancelledCallback(e),
                                !0
                            });
                        t(e, e.type())
                    }
                }
            }
        },
        a.tracker.custom_supported_observers && (t.merge(a.tracker.supported_observers, a.tracker.custom_supported_observers),
        t.extend(!0, a.tracker.dom_observers, a.tracker.custom_dom_observers)),
        a.tracker.dom_observer_map = {},
        t.each(a.tracker.dom_observers, function(e, r) {
            t.isArray(r.class) || (r.class = [r.class]),
            t.each(r.class, function(t, r) {
                a.tracker.dom_observer_map[r] || (a.tracker.dom_observer_map[r] = []),
                a.tracker.dom_observer_map[r].push(e)
            })
        })
    }
    ,
    a.observe.register = function(e, r) {
        a.tracker.dom_observer_init && a.tools.error("Error: Please register all custom DOM observers before binding handlers using gmail.observe.on etc"),
        a.tracker.custom_supported_observers || (a.tracker.custom_supported_observers = [],
        a.tracker.custom_dom_observers = {});
        var o = {};
        "object" != typeof r || t.isArray(r) ? o.class = r : t.each(["class", "selector", "sub_selector", "handler"], function(e, t) {
            r[t] && (o[t] = r[t])
        }),
        a.tracker.custom_supported_observers.push(e),
        a.tracker.custom_dom_observers[e] = o
    }
    ;
    var s = function() {
        var e;
        a.tracker.jackPreventionInstalled || (window.addEventListener("click", e => {
            const t = (e = e).path ? e.path[0] : e.target;
            if (t && t !== document.body) {
                const r = t.querySelector(":scope > .gmailjs");
                r && (r.click(),
                e.preventDefault())
            }
        }
        ),
        a.tracker.jackPreventionInstalled = !0)
    };
    a.observe.on_dom = function(e, r) {
        if (a.tracker.dom_observer_init || a.observe.initialize_dom_observers(),
        t.inArray(e, a.tracker.supported_observers) > -1) {
            if (!a.tracker.observing_dom)
                a.tracker.observing_dom = !0,
                t(window.document).on("DOMNodeInserted", function(e) {
                    a.tools.insertion_observer(e.target, a.tracker.dom_observers, a.tracker.dom_observer_map)
                }),
                new MutationObserver(function(e) {
                    for (var r = 0; r < e.length; r++)
                        for (var o = e[r], n = o.removedNodes, i = 0; i < n.length; i++) {
                            var s = n[i];
                            if ("agh" === s.className && s.querySelector("div[data-hovercard-id]")) {
                                let e = a.tracker.dom_observer_map.afV
                                  , r = a.tracker.dom_observers.recipient_change.handler;
                                a.observe.trigger_dom(e, t(o.target), r)
                            } else if ("vR" === s.className) {
                                let e = a.tracker.dom_observer_map.vR
                                  , r = a.tracker.dom_observers.recipient_change.handler;
                                a.observe.trigger_dom(e, t(o.target), r)
                            }
                        }
                }
                ).observe(document.body, {
                    subtree: !0,
                    childList: !0
                });
            return a.observe.bind("dom", e, r),
            !0
        }
        if ("compose_cancelled" === e)
            a.tracker.composeCancelledCallback = r;
        else if ("load" === e) {
            if (a.dom.inbox_content().length)
                return s(),
                r();
            var o = 0
              , n = setInterval(function() {
                if (a.dom.inbox_content().length > 0)
                    return clearInterval(n),
                    s(),
                    r();
                ++o > 50 && (clearInterval(n),
                setTimeout(r, 5e3))
            }, 200);
            return !0
        }
    }
    ,
    a.tools.insertion_observer = function(e, r, o, n) {
        if (o) {
            var i = e.className || ""
              , s = i.trim ? i.trim().split(/\s+/) : [];
            s.length || s.push(""),
            t.each(s, function(n, i) {
                var s = o[i];
                if (s)
                    for (var l of s)
                        if (l && a.tracker.watchdog && a.tracker.watchdog.dom[l]) {
                            var c = t(e)
                              , d = r[l];
                            if (d.selector && !c.is(d.selector))
                                return;
                            if (d.sub_selector && (c = c.find(d.sub_selector)),
                            c.length) {
                                var u = d.handler ? d.handler : function(e, t) {
                                    t(e)
                                }
                                ;
                                a.observe.trigger_dom(l, c, u)
                            }
                        }
            })
        }
    }
    ,
    a.tools.make_request = function(e, r, a) {
        var o = decodeURIComponent(e.replace(/%23/g, "#-#-#"))
          , n = {
            type: r = r || "GET",
            url: o = encodeURI(o).replace(/#-#-#/gi, "%23"),
            async: !1,
            dataType: "text"
        };
        return a && (n.cache = !1),
        t.ajax(n).responseText
    }
    ,
    a.tools.make_request_async = function(e, r, a, o, n) {
        var i = decodeURIComponent(e.replace(/%23/g, "#-#-#"))
          , s = {
            type: r = r || "GET",
            url: i = encodeURI(i).replace(/#-#-#/gi, "%23"),
            async: !0,
            dataType: "text"
        };
        n && (s.cache = !1),
        t.ajax(s).done(function(e, t, r) {
            a(r.responseText)
        }).fail(function(e, t, r) {
            console.error("Request Failed", r),
            "function" == typeof o && o(e, t, r)
        })
    }
    ,
    a.tools.make_request_download_promise = function(e, t) {
        const r = Date.now();
        e += "&cacheCounter=" + r;
        let a = "text";
        return t && (a = "arraybuffer"),
        new Promise( (r, o) => {
            const n = new XMLHttpRequest;
            n.open("GET", e, !0),
            n.responseType = a,
            n.onreadystatechange = ( () => {
                if (n.readyState === XMLHttpRequest.DONE && n.status >= 200 && n.status <= 302) {
                    const e = n.response;
                    if (e)
                        if (t) {
                            const t = new Uint8Array(e);
                            r(t)
                        } else
                            r(e)
                }
            }
            ),
            n.onerror = (e => {
                o(e)
            }
            ),
            n.send()
        }
        )
    }
    ,
    a.tools.parse_view_data = function(e) {
        for (var t = [], r = [], a = 0; a < e.length; a++)
            if ("tb" === e[a][0])
                for (var o = 0; o < e[a][2].length; o++)
                    r.push(e[a][2][o]);
        for (var n = 0; n < r.length; n++) {
            var i = r[n];
            t.push({
                id: i[0],
                title: i[9],
                excerpt: i[10],
                time: i[15],
                sender: i[28],
                attachment: i[13],
                labels: i[5]
            })
        }
        return t
    }
    ,
    a.helper.get.is_delegated_inbox = function() {
        return 1 === t(".identityUserDelegatedAccount").length
    }
    ,
    a.helper.get.visible_emails_pre = function(e) {
        var r = a.get.current_page()
          , o = window.location.origin + window.location.pathname + "?ui=2&ik=" + a.tracker.ik + "&rid=" + a.tracker.rid + "&view=tl&num=120&rt=1"
          , n = t(".aqK:visible .Dj").find("span:first").text().replace(",", "").replace(".", "").split("–")[0];
        o += n ? "&start=" + (n = parseInt(n - 1)) + "&sstart=" + n : "&start=0";
        var i = "";
        if (0 === r.indexOf("label/"))
            o += "&cat=" + r.split("/")[1] + "&search=cat";
        else if (0 === r.indexOf("category/"))
            -1 !== r.indexOf("forums") ? i = "group" : -1 !== r.indexOf("updates") ? i = "notification" : -1 !== r.indexOf("promotion") ? i = "promo" : -1 !== r.indexOf("social") && (i = "social"),
            o += "&cat=^smartlabel_" + i + "&search=category";
        else if (0 === r.indexOf("search/")) {
            var s = t("input[name=at]").val();
            o += "&qs=true&q=" + r.split("/")[1] + "&at=" + s + "&search=query"
        } else
            "inbox" === r ? "true" === t("div[aria-label='Social']").attr("aria-selected") ? o += "&cat=^smartlabel_" + (i = "social") + "&search=category" : "true" === t("div[aria-label='Promotions']").attr("aria-selected") ? o += "&cat=^smartlabel_" + (i = "promo") + "&search=category" : "true" === t("div[aria-label='Updates']").attr("aria-selected") ? o += "&cat=^smartlabel_" + (i = "notification") + "&search=category" : "true" === t("div[aria-label='Forums']").attr("aria-selected") ? o += "&cat=^smartlabel_" + (i = "group") + "&search=category" : e ? o += "&search=" + e : a.check.is_google_apps_user() ? o += "&search=inbox" : o += "&search=mbox" : o += "&search=" + r;
        return o
    }
    ,
    a.helper.get.visible_emails_post = function(e) {
        var t = [];
        if (!e)
            return t;
        var r = e.substring(e.indexOf("["), e.length)
          , o = JSON.parse(r);
        for (var n in a.tracker.view_data = o,
        a.tracker.view_data)
            if ("function" != typeof a.tracker.view_data[n]) {
                var s = a.tools.parse_view_data(a.tracker.view_data[n]);
                s.length > 0 && i(t, s)
            }
        return t
    }
    ,
    a.get.visible_emails = function(e) {
        var t = a.helper.get.visible_emails_pre(e)
          , r = a.tools.make_request(t);
        return a.helper.get.visible_emails_post(r)
    }
    ,
    a.get.visible_emails_async = function(e, t) {
        var r = a.helper.get.visible_emails_pre(t);
        a.tools.make_request_async(r, "GET", function(t) {
            var r = a.helper.get.visible_emails_post(t);
            e(r)
        })
    }
    ,
    a.get.selected_emails_data = function(e) {
        var r = [];
        if (a.check.is_inside_email())
            r.push(a.get.email_data());
        else if (t("[gh='tl'] div[role='checkbox'][aria-checked='true']").length) {
            var o = null
              , n = a.get.visible_emails(e);
            t("[gh='tl'] div[role='checkbox']").each(function(e) {
                "true" === t(this).attr("aria-checked") && (o = a.get.email_data(n[e].id),
                r.push(o))
            })
        }
        return r
    }
    ,
    a.get.current_page = function(e) {
        var t = (e = e || window.location.hash).split("#").pop().split("?").shift() || "inbox";
        if (t.match(/\/[0-9a-zA-Z]{16,}$/gi))
            return "email";
        if (0 === t.indexOf("search/") || 0 === t.indexOf("category/") || 0 === t.indexOf("label/")) {
            var r = t.split("/");
            return r[0] + "/" + r[1]
        }
        return t.split("/").shift()
    }
    ,
    a.tools.infobox = function(e, r, a) {
        var o = t(".b8.UC");
        if (o.length > 0) {
            o.stop(!1, !0);
            var n = o.find(".vh");
            if (a ? n.html(e) : n.text(e),
            void 0 !== r) {
                var i = o.attr("style");
                o.removeAttr("style").fadeTo(r, 0, function() {
                    t(this).attr("style", i)
                })
            } else
                o.removeAttr("style")
        }
    }
    ,
    a.tools.rerender = function(e) {
        var t, r = window.location.href;
        t = -1 !== window.location.hash.indexOf("/") ? r.replace(/#.*?\//, "#/") : r.replace(/#.*/, "#"),
        window.location.replace(t),
        setTimeout(function() {
            window.location.replace(r),
            window.history.back(),
            e && e()
        }, 0)
    }
    ,
    a.tools.get_reply_to = function(e) {
        var t = e ? e[4] : [];
        return 0 !== t.length ? a.tools.extract_email_address(t[0]) : null
    }
    ,
    a.tools.parse_attachment_data = function(e) {
        if (!e[7] || !e[7][0])
            return null;
        var t = "";
        "undefined" != typeof window && (t = window.location.origin + window.location.pathname);
        var r = e[7][0];
        a.tracker.attachment_data = r;
        for (var o = [], n = 0; n < r.length; n++) {
            var i = r[n];
            o.push({
                attachment_id: i[0],
                name: i[1],
                type: i[2],
                size: i[3],
                url: t + i[9]
            })
        }
        return o
    }
    ,
    a.tools.parse_email_data = function(e) {
        var r = {};
        for (var o in e) {
            var n = e[o];
            if ("cs" === n[0] && (r.thread_id = n[1],
            r.first_email = n[8][0],
            r.last_email = n[2],
            r.total_emails = n[3],
            r.total_threads = n[8],
            r.people_involved = n[15],
            r.subject = n[23]),
            "ms" === n[0]) {
                void 0 === r.threads && (r.threads = {}),
                r.threads[n[1]] = {},
                r.threads[n[1]].is_deleted = n[9] && n[9].indexOf("^k") > -1,
                r.threads[n[1]].reply_to_id = n[2],
                r.threads[n[1]].from = n[5],
                r.threads[n[1]].from_email = n[6],
                r.threads[n[1]].timestamp = n[7],
                r.threads[n[1]].datetime = n[24],
                r.threads[n[1]].attachments = n[21].split(","),
                r.threads[n[1]].attachments_details = n[13] ? a.tools.parse_attachment_data(n[13]) : null,
                r.threads[n[1]].subject = n[12],
                r.threads[n[1]].content_html = n[13] ? n[13][6] : n[8],
                r.threads[n[1]].to = n[13] ? n[13][1] : void 0 !== n[37] ? n[37][1] : [],
                r.threads[n[1]].cc = n[13] ? n[13][2] : [],
                r.threads[n[1]].bcc = n[13] ? n[13][3] : [],
                r.threads[n[1]].reply_to = a.tools.get_reply_to(n[13]),
                r.threads[n[1]].labels = n[9];
                try {
                    r.threads[n[1]].content_plain = n[13] ? t(n[13][6]).text() : n[8]
                } catch (e) {
                    r.threads[n[1]].content_plain = n[13] ? n[13][6] : n[8]
                }
            }
        }
        return r
    }
    ,
    a.helper.get.email_data_pre = function(e) {
        o("Migrate code to use gmail.new.get.email_data() to fix this problem."),
        a.check.is_inside_email() && void 0 === e && (e = a.get.thread_id());
        var t = null;
        return void 0 !== e && (t = window.location.origin + window.location.pathname + "?ui=2&ik=" + a.tracker.ik + "&rid=" + a.tracker.rid + "&view=cv&th=" + e + "&msgs=&mb=0&rt=1&search=inbox"),
        t
    }
    ,
    a.helper.get.email_data_post = function(e) {
        if (!e)
            return {};
        var t = e.substring(e.indexOf("["), e.length)
          , r = JSON.parse(t);
        return a.tracker.email_data = r[0],
        a.tools.parse_email_data(a.tracker.email_data)
    }
    ,
    a.get.email_data = function(e) {
        var t = a.helper.get.email_data_pre(e);
        if (null !== t) {
            var r = a.tools.make_request(t);
            return a.helper.get.email_data_post(r)
        }
        return {}
    }
    ,
    a.get.email_data_async = function(e, t) {
        var r = a.helper.get.email_data_pre(e);
        null !== r ? a.tools.make_request_async(r, "GET", function(e) {
            var r = a.helper.get.email_data_post(e);
            t(r)
        }) : t({})
    }
    ,
    a.helper.get.legacy_email_id = function(e) {
        if (!e)
            return null;
        if (a.check.data.is_legacy_email_id(e))
            return e;
        if (e.legacy_email_id)
            return e.legacy_email_id;
        if (a.check.data.is_email_id(e)) {
            console.warn("GmailJS: Warning! Using new-style ID in method expecting legacy-style IDs! Attempting to resolve via cache, but there's no guarantee this will work!");
            const t = a.cache.emailIdCache[e];
            return t && t.legacy_email_id
        }
        return e.$el && e.$el[0] && (e = e.$el[0]),
        e.dataset && e.dataset.legacyMessageId ? e.dataset.legacyMessageId : null
    }
    ,
    a.helper.get.new_email_id = function(e) {
        if (!e)
            return null;
        if (a.check.data.is_email_id(e))
            return e;
        if (e.id && !e.$el)
            return e.id;
        if (a.check.data.is_legacy_email_id(e)) {
            console.warn("GmailJS: Warning! Using legacy-style ID in method expecting new-style IDs! Attempting to resolve via cache, but there's no guarantee this will work!");
            const t = a.cache.emailLegacyIdCache[e];
            return t && t.id
        }
        if (e.$el && e.$el[0] && (e = e.$el[0]),
        e.dataset && e.dataset.messageId) {
            let t = e.dataset.messageId;
            return 0 === t.indexOf("#") && (t = t.substring(1)),
            t
        }
        return null
    }
    ,
    a.helper.get.thread_id = function(e) {
        if (!e)
            return null;
        if (a.check.data.is_thread_id(e))
            return e;
        if (e.thread_id)
            return e.thread_id;
        if (a.check.data.is_email_id(e)) {
            console.warn("GmailJS: Warning! Using email-ID in method expecting thread-ID! Attempting to resolve via cache, but there's no guarantee this will work!");
            const t = a.cache.emailIdCache[e];
            return t && t.thread_id
        }
        if (a.check.data.is_legacy_email_id(e)) {
            console.warn("GmailJS: Warning! Using legacy-style ID in method expecting thread-ID! Attempting to resolve via cache, but there's no guarantee this will work!");
            const t = a.cache.emailLegacyIdCache[e];
            return t && t.thread_id
        }
        if (e.$el && e.$el[0] && (e = e.$el[0]),
        e.dataset && e.dataset.threadPermId) {
            let t = e.dataset.threadPermId;
            return 0 === t.indexOf("#") && (t = t.substring(1)),
            t
        }
        if (e.dataset && e.dataset.messageId) {
            let t = e.dataset.messageId;
            0 === t.indexOf("#") && (t = t.substring(1)),
            console.warn("GmailJS: Warning! Using DomEmail instance to lookup thread-ID. Attempting to resolve via cache, but there's no guarantee this will work!");
            const r = a.cache.emailIdCache[t];
            return r && r.thread_id
        }
        return null
    }
    ,
    a.helper.clean_thread_id = function(e) {
        return e.startsWith("#") && (e = e.substring(1)),
        e
    }
    ,
    a.helper.get.email_source_pre = function(e) {
        if (!e && a.check.is_inside_email() && (e = a.get.email_id()),
        a.check.data.is_legacy_email_id(e))
            return window.location.origin + window.location.pathname + "?view=att&th=" + e + "&attid=0&disp=comp&safe=1&zw";
        const t = a.helper.get.new_email_id(e);
        return t ? window.location.origin + window.location.pathname + "?view=att&permmsgid=" + t + "&attid=0&disp=comp&safe=1&zw" : null
    }
    ,
    a.get.email_source = function(e) {
        console.warn("Gmail.js: This function has been deprecated and will be removed in an upcoming release! Please migrate to email_source_async or email_source_promise!");
        var t = a.helper.get.email_source_pre(e);
        return null !== t ? a.tools.make_request(t, "GET", !0) : ""
    }
    ,
    a.get.email_source_async = function(e, t, r, o) {
        a.get.email_source_promise(e, o).then(t).catch(r)
    }
    ,
    a.get.email_source_promise = function(e, t) {
        const r = a.helper.get.email_source_pre(e);
        return null !== r ? a.tools.make_request_download_promise(r, t) : new Promise( (e, t) => {
            t("Unable to resolve URL for email source!")
        }
        )
    }
    ,
    a.get.displayed_email_data = function() {
        var e = a.get.email_data();
        return a.check.is_conversation_view() ? l(e) : c(e)
    }
    ,
    a.get.displayed_email_data_async = function(e) {
        a.get.email_data_async(void 0, function(t) {
            a.check.is_conversation_view() ? e(l(t)) : e(c(t))
        })
    }
    ;
    var l = function(e) {
        var t = e
          , r = t.threads
          , a = t.total_threads
          , o = 0 === (window.location.hash.split("#")[1] || "").indexOf("trash");
        for (var n in r) {
            var i = r[n];
            (o ? i.is_deleted : !i.is_deleted) || (delete r[n],
            a.splice(a.indexOf(n), 1),
            t.total_emails--)
        }
        return t
    }
      , c = function(e) {
        var t = {};
        for (var r in e.threads) {
            if (document.querySelector("div[data-legacy-message-id='" + r + "']")) {
                var o = e.threads[r];
                t.first_email = r,
                t.last_email = r,
                t.subject = e.subject,
                t.threads = {},
                t.threads[r] = o,
                t.total_emails = 1,
                t.total_threads = [r],
                t.people_involved = [],
                t.people_involved.push([o.from, o.from_email]),
                o.to.forEach(function(e) {
                    var r = a.tools.extract_email_address(e)
                      , o = a.tools.extract_name(e.replace(r, "")) || "";
                    t.people_involved.push([o, r])
                });
                break
            }
        }
        return t
    };
    a.check.is_conversation_view = function() {
        if (a.check.is_new_data_layer()) {
            return -1 !== a.tracker.globals[24].indexOf(7164)
        }
        for (var e = void 0, t = a.tracker.globals[17][4][1], r = 0; r < t.length; r++) {
            var o = t[r];
            if ("bx_vmb" === o[0]) {
                e = o[1];
                break
            }
        }
        return "0" === e || void 0 === e
    }
    ,
    a.tools.extract_email_address = function(e) {
        var t = e ? e.match(/[\+a-z0-9._-]+@[a-z0-9._-]+\.[a-z0-9._-]+/gi) : void 0;
        return t ? t[0] : void 0
    }
    ,
    a.tools.extract_name = function(e) {
        var t = e ? e.match(/[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF"._\s-]+/gi) : void 0;
        return t && t[0] ? t[0].trim() : void 0
    }
    ,
    a.tools.i18n = function(e) {
        var t;
        switch (a.get.localization()) {
        case "fr":
            t = {
                inbox: "Boîte de réception",
                drafts: "Brouillons",
                spam: "Spam",
                forums: "Forums",
                updates: "Mises à jour",
                promotions: "Promotions",
                social_updates: "Réseaux sociaux"
            };
            break;
        case "no":
            t = {
                inbox: "Innboks",
                drafts: "Utkast",
                spam: "Søppelpost",
                forums: "Forumer",
                updates: "Oppdateringer",
                promotions: "Reklame",
                social_updates: "Sosialt"
            };
            break;
        case "nl":
            t = {
                inbox: "Postvak IN",
                drafts: "Concepten",
                spam: "Spam",
                forums: "Forums",
                updates: "Updates",
                promotions: "Reclame",
                social_updates: "Sociaal"
            };
            break;
        case "it":
            t = {
                inbox: "Posta in arrivo",
                drafts: "Bozza",
                spam: "Spam",
                forums: "Forum",
                updates: "Aggiornamenti",
                promotions: "Promozioni",
                social_updates: "Social"
            };
            break;
        case "en":
        default:
            t = {
                inbox: "Inbox",
                drafts: "Drafts",
                spam: "Spam",
                forums: "Forums",
                updates: "Updates",
                promotions: "Promotions",
                social_updates: "Social Updates"
            }
        }
        return t[e]
    }
    ;
    var d = function(e, r, a, o, n, i) {
        var s = t(document.createElement("div"));
        s.attr("class", "G-Ni J-J5-Ji");
        var l = t(document.createElement("div"))
          , c = "T-I J-J5-Ji gmailjs ";
        return c += void 0 !== n && null !== n && "" !== n ? a + n : a + o,
        l.attr("class", c),
        l.html(e),
        l.click(r),
        t(document.createElement("div")).attr("class", "asa"),
        s.html(l),
        i.append(s),
        s
    };
    return a.tools.add_toolbar_button = function(e, t, r) {
        return d(e, t, "lS ", "T-I-ax7 ar7", r, a.dom.toolbar())
    }
    ,
    a.tools.add_right_toolbar_button = function(e, t, r) {
        return d(e, t, "ash ", "T-I-ax7 L3", r, a.dom.right_toolbar())
    }
    ,
    a.tools.add_compose_button = function(e, r, a, o) {
        var n = t(document.createElement("div"));
        n.attr("class", "gU Up"),
        n.attr("style", "cursor: pointer !important; transform: translateY(1px);");
        var i = t(document.createElement("div"))
          , s = "T-I J-J5-Ji aoO T-I-atl L3 gmailjs gmailjscomposebutton ";
        void 0 !== o && (s += o),
        i.attr("class", s),
        i.attr("style", "margin-left: 8px; max-width: 500px;"),
        i.html(r),
        i.click(a),
        n.append(i);
        var l = e.find(".gU.Up").last();
        return n.insertAfter(l),
        i
    }
    ,
    a.tools.add_more_send_option = function(e, r, a, o, n) {
        var i = t(document.createElement("div"));
        i.attr("class", "J-N yr"),
        i.attr("style", "user-select: none;"),
        i.attr("role", "menuitem");
        var s = t(document.createElement("div"))
          , l = "J-N-Jz ";
        void 0 !== o && (l += o),
        s.attr("class", l),
        s.attr("style", "user-select: none;");
        var c = t(document.createElement("img"))
          , d = "J-N-JX";
        void 0 !== n && (d = n + " " + d),
        c.attr("class", d),
        c.attr("style", "user-select: none;"),
        c.attr("role", "menuitem"),
        c.attr("src", "images/cleardot.gif"),
        s.append(c),
        s.append(r),
        s.click(a),
        i.append(s);
        var u = e.find(".J-N.yr").last();
        return i.insertAfter(u),
        s
    }
    ,
    a.tools.add_attachment_button = function(e, r, a, o, n) {
        var i = t(document.createElement("div"));
        i.attr("class", "T-I J-J5-Ji aQv T-I-ax7 L3"),
        i.attr("style", "user-select: none;"),
        i.attr("aria-label", o),
        i.attr("data-tooltip", o);
        i.mouseover(function() {
            this.classList.add("T-I-JW")
        }),
        i.mouseout(function() {
            this.classList.remove("T-I-JW")
        });
        var s = t(document.createElement("div"))
          , l = "wtScjd J-J5-Ji aYr";
        return a && (l += " " + a),
        s.attr("class", l),
        r && s.html(r),
        i.append(s),
        i.click(n),
        e.$el.find("div.aQw").append(i),
        i
    }
    ,
    a.tools.remove_modal_window = function() {
        t("#gmailJsModalBackground").remove(),
        t("#gmailJsModalWindow").remove()
    }
    ,
    a.tools.add_modal_window = function(e, r, o, n, i, s, l) {
        i = i || a.tools.remove_modal_window,
        n = n || a.tools.remove_modal_window,
        s = s || "OK",
        l = l || "Cancel";
        var c = t(document.createElement("div"));
        c.attr("id", "gmailJsModalBackground"),
        c.attr("class", "Kj-JD-Jh"),
        c.attr("aria-hidden", "true"),
        c.attr("style", "opacity:0.75;width:100%;height:100%;");
        var d = t(document.createElement("div"));
        d.attr("id", "gmailJsModalWindow"),
        d.attr("class", "Kj-JD"),
        d.attr("tabindex", "0"),
        d.attr("role", "alertdialog"),
        d.attr("aria-labelledby", "gmailJsModalWindowTitle"),
        d.attr("style", "left:50%;top:50%;opacity:1;");
        var u = t(document.createElement("div"));
        u.attr("class", "Kj-JD-K7 Kj-JD-K7-GIHV4");
        var _ = t(document.createElement("span"));
        _.attr("id", "gmailJsModalWindowTitle"),
        _.attr("class", "Kj-JD-K7-K0"),
        _.attr("role", "heading"),
        _.html(e);
        var m = t(document.createElement("span"));
        m.attr("id", "gmailJsModalWindowClose"),
        m.attr("class", "Kj-JD-K7-Jq"),
        m.attr("role", "button"),
        m.attr("tabindex", "0"),
        m.attr("aria-label", "Close"),
        m.click(i),
        u.append(_),
        u.append(m);
        var h = t(document.createElement("div"));
        h.attr("id", "gmailJsModalWindowContent"),
        h.attr("class", "Kj-JD-Jz"),
        h.html(r);
        var f = t(document.createElement("div"));
        f.attr("class", "Kj-JD-Jl");
        var p = t(document.createElement("button"));
        p.attr("id", "gmailJsModalWindowOk"),
        p.attr("class", "J-at1-auR J-at1-atl"),
        p.attr("name", "ok"),
        p.text(s),
        p.click(o);
        var g = t(document.createElement("button"));
        g.attr("id", "gmailJsModalWindowCancel"),
        g.attr("name", "cancel"),
        g.text(l),
        g.click(n),
        f.append(p),
        f.append(g),
        d.append(u),
        d.append(h),
        d.append(f),
        t(document.body).append(c),
        t(document.body).append(d);
        var v = function() {
            d.css({
                top: (t(window).height() - d.outerHeight()) / 2,
                left: (t(window).width() - d.outerWidth()) / 2
            })
        };
        v(),
        d.on("DOMSubtreeModified", v),
        t(window).resize(v)
    }
    ,
    a.tools.toggle_minimize = function() {
        var e = t("[alt='Minimize']")[0];
        return !!e && (e.click(),
        !0)
    }
    ,
    a.chat.is_hangouts = function() {
        if (void 0 !== a.tracker.hangouts)
            return a.tracker.hangouts;
        var e = t(".dw");
        if (e.length > 1)
            throw "Figuring out is hangouts - more than one dw classes found";
        if (0 === e.length)
            throw "Figuring out is hangouts - no dw classes found";
        var r = e[0]
          , o = t(".nH.aJl.nn", r);
        return o.length > 0 ? (a.tracker.hangouts = !0,
        !0) : (o = t(".nH.nn", r)).length > 2 ? (a.tracker.hangouts = !1,
        !1) : void 0
    }
    ,
    a.dom.visible_messages = function() {
        const e = [];
        return t('tbody>tr.zA[role="row"]:visible', a.dom.inbox_content()).each( (r, o) => {
            const n = t("*[email][name]", o)
              , i = t("*[role=link]", o)
              , s = o.querySelector("span[data-thread-id]");
            e.push({
                from: {
                    name: n.attr("name"),
                    email: n.attr("email")
                },
                summary: i[0].innerText,
                thread_id: a.helper.clean_thread_id(s && s.dataset && s.dataset.threadId || ""),
                legacy_email_id: s && s.dataset && s.dataset.legacyMessageId || "",
                $el: t(o)
            })
        }
        ),
        e
    }
    ,
    a.dom.composes = function() {
        var e = [];
        return t("div.M9").each(function(t, r) {
            e.push(new a.dom.compose(r))
        }),
        e
    }
    ,
    a.dom.helper = {},
    a.dom.helper.trigger_address = function(e) {
        let t = e[0]
          , r = new KeyboardEvent("keydown",{
            bubbles: !0,
            cancelable: !0,
            key: "Tab",
            shiftKey: !0,
            keyCode: 9
        });
        t.focus(),
        t.dispatchEvent(r)
    }
    ,
    a.dom.compose = function(e) {
        return this.constructor !== a.dom.compose ? new a.dom.compose(e) : ((e = t(e)) && (e.hasClass("M9") || e.hasClass("AD")) || a.tools.error("api.dom.compose called with invalid element"),
        this.$el = e,
        this)
    }
    ,
    n(a.dom.compose.prototype, {
        id: function() {
            return this.dom("id").val()
        },
        email_id: function() {
            let e = this.dom("draft").val();
            return e && e.startsWith("#") ? e.substring(1) : e
        },
        thread_id: function() {
            let e = this.dom("thread").val() || "";
            return a.helper.clean_thread_id(e)
        },
        is_inline: function() {
            return this.$el.closest("td.Bu").length > 0
        },
        type: function() {
            return this.is_inline() ? 0 === this.find("input[name=subject]").val().indexOf("Fw") ? "forward" : "reply" : "compose"
        },
        recipients: function(e) {
            "object" != typeof e && (e = {});
            const t = a.check.is_peoplekit_compose(this.$el)
              , r = e.type ? "[name=" + e.type + "]" : ""
              , o = t ? this.$el.find("tr.bzf " + r + " div[data-hovercard-id]").map( (e, t) => ({
                type: t.closest("div[name]").getAttribute("name"),
                email: t.getAttribute("data-hovercard-id")
            })) : this.$el.find(".GS input[type=hidden]" + r).map( (e, t) => ({
                type: t.name,
                email: t.value
            }));
            if (e.flat)
                return o.toArray().map(e => e.email);
            {
                let t = {
                    to: [],
                    cc: [],
                    bcc: []
                };
                return e.type ? t[e.type] = o.toArray().filter(t => t.type === e.type).map(e => e.email) : ["to", "cc", "bcc"].forEach(e => {
                    t[e] = o.toArray().filter(t => t.type === e).map(e => e.email)
                }
                ),
                t
            }
        },
        to: function(e) {
            const t = this.dom("to").val(e);
            return a.dom.helper.trigger_address(t),
            t
        },
        cc: function(e) {
            if (e) {
                this.dom("show_cc").click()
            }
            const t = this.dom("cc").val(e);
            return a.dom.helper.trigger_address(t),
            t
        },
        bcc: function(e) {
            if (e) {
                this.dom("show_bcc").click()
            }
            const t = this.dom("bcc").val(e);
            return a.dom.helper.trigger_address(t),
            t
        },
        subject: function(e) {
            return e && this.dom("all_subjects").val(e),
            (e = this.dom("subjectbox").val()) || this.dom("subject").val()
        },
        from: function() {
            var e = this.dom("from");
            if (e.length) {
                var t = e.val();
                if (t)
                    return a.tools.extract_email_address(t)
            }
            return a.get.user_email()
        },
        body: function(e) {
            var t = this.dom("body");
            return e && t.html(e),
            t.html()
        },
        attachments: function() {
            var e = [];
            return this.dom("attachments").each(function() {
                var r = t(this)
                  , a = {};
                a.$el = r,
                a.name = r.find("div.vI").html(),
                a.size = r.find("div.vJ").html(),
                a.url = r.find("a.dO").attr("href"),
                a.type = "https",
                e.push(a)
            }),
            e
        },
        send: function() {
            return this.dom("send_button").click()
        },
        find: function(e) {
            return this.$el.find(e)
        },
        close: function() {
            const e = document.createEvent("Events");
            e.initEvent("keydown", !0, !0),
            e.which = 27,
            e.keyCode = 27;
            var t = this.dom("body");
            t.focus(),
            t[0].dispatchEvent(e)
        },
        dom: function(e) {
            if (!e)
                return this.$el;
            var t = {
                to: "textarea[name=to]",
                cc: "textarea[name=cc]",
                bcc: "textarea[name=bcc]",
                id: "input[name=composeid]",
                draft: "input[name=draft]",
                thread: "input[name=rt]",
                subject: "input[name=subject]",
                subjectbox: "input[name=subjectbox]",
                all_subjects: "input[name=subjectbox], input[name=subject]",
                body: "div[contenteditable=true]:not([id=subject])",
                quoted_reply: "input[name=uet]",
                reply: "M9",
                forward: "M9",
                from: "input[name=from]",
                attachments: "div.dL",
                send_button: "div.T-I.T-I-atl:not(.gmailjscomposebutton)",
                show_cc: "span.aB.gQ.pE",
                show_bcc: "span.aB.gQ.pB"
            };
            return a.check.is_peoplekit_compose(this.$el) && (t = Object.assign(t, {
                to: "div[name=to] input",
                cc: "div[name=cc] input",
                bcc: "div[name=bcc] input"
            })),
            t[e] || a.tools.error('Dom lookup failed. Unable to find config for "' + e + '"', t, e, t[e]),
            this.$el.find(t[e])
        }
    }),
    a.dom.email = function(e) {
        if (this.constructor !== a.dom.email)
            return new a.dom.email(e);
        if ("string" == typeof e && a.check.data.is_legacy_email_id(e))
            this.id = e,
            this.$el = t("div.adn[data-legacy-message-id='" + this.id + "']");
        else if ("string" == typeof e && a.check.data.is_email_id(e)) {
            const r = document.querySelector("div.adn[data-message-id='" + e.replace("msg-f:", "\\#msg-f\\:") + "']");
            this.id = r.dataset.legacyMessageId,
            this.$el = t(r)
        } else
            e && (e.classList && e.classList.contains("adn") || e.hasClass && e.hasClass("adn")) ? (this.$el = t(e),
            this.id = this.$el.data("legacyMessageId")) : a.tools.error("api.dom.email called with invalid element/id");
        return this
    }
    ,
    n(a.dom.email.prototype, {
        body: function(e) {
            var t = this.dom("body");
            return e && t.html(e),
            t.html()
        },
        from: function(e, t) {
            var r = this.dom("from");
            return e && r.attr("email", e),
            t && (r.attr("name", t),
            r.html(t)),
            {
                email: r.attr("email"),
                name: r.attr("name"),
                el: r
            }
        },
        to: function(e) {
            if (e) {
                t.isArray(e) || (e = [e]);
                var r = [];
                t.each(e, function(e, a) {
                    r.push(t("<span />").attr({
                        dir: "ltr",
                        email: a.email,
                        name: a.name
                    }).addClass("g2").html(a.name).wrap("<p/>").parent().html())
                }),
                this.dom("to_wrapper").html("to " + r.join(", "))
            }
            var a = [];
            return this.dom("to").each(function() {
                var e = t(this);
                a.push({
                    email: e.attr("email"),
                    name: e.attr("name"),
                    el: e
                })
            }),
            a
        },
        attachments: function() {
            var e = [];
            return this.dom("attachments").each(function() {
                var r = t(this)
                  , o = {};
                o.$el = r,
                o.name = r.find(".aV3").html(),
                o.size = r.find(".SaH2Ve").html();
                var n = r.attr("download_url");
                if (n) {
                    var i = a.tools.parse_attachment_url(n);
                    o.url = i.url,
                    o.type = i.type
                }
                e.push(o)
            }),
            e
        },
        data: function() {
            if ("object" != typeof a.dom.email_cache && (a.dom.email_cache = {}),
            !a.dom.email_cache[this.id]) {
                var e = a.get.email_data(this.id);
                t.each(e.threads, function(e, t) {
                    a.dom.email_cache[e] = t
                })
            }
            return a.dom.email_cache[this.id]
        },
        source: function() {
            return a.get.email_source(this.id)
        },
        dom: function(e) {
            if (!e)
                return this.$el;
            var t = {
                body: "div.a3s",
                from: "span[email].gD",
                to: "span[email].g2",
                to_wrapper: "span.hb",
                timestamp: "span.g3",
                star: "div.zd",
                attachments: "div.hq.gt div.aQH span.aZo",
                reply_button: "div[role=button].aaq",
                menu_button: "div[role=button].aap",
                details_button: "div[role=button].ajz"
            };
            return t[e] || a.tools.error('Dom lookup failed. Unable to find config for "' + e + '"'),
            this.$el.find(t[e])
        }
    }),
    a.dom.thread = function(e) {
        return this.constructor !== a.dom.thread ? new a.dom.thread(e) : (e && e.hasClass("if") || a.tools.error("api.dom.thread called with invalid element/id"),
        this.$el = e,
        this)
    }
    ,
    n(a.dom.thread.prototype, {
        dom: function(e) {
            if (!e)
                return this.$el;
            var t = {
                opened_email: "div.adn",
                subject: "h2.hP",
                labels: "div.hN"
            };
            return t[e] || a.tools.error('Dom lookup failed. Unable to find config for "' + e + '"'),
            this.$el.find(t[e])
        }
    }),
    a.compose.start_compose = function() {
        var e = document.getElementsByClassName("T-I T-I-KE L3")[0];
        return !!e && (e.click(),
        !0)
    }
    ,
    a.old = {},
    a.old.get = a.get,
    a.new = {},
    a.new.get = {},
    a.new.get.email_id = function(e) {
        if (!e) {
            const t = document.querySelectorAll(".adn[data-message-id]");
            if (!t || 0 === t.length)
                return null;
            e = t[t.length - 1]
        }
        return a.helper.get.new_email_id(e)
    }
    ,
    a.new.get.thread_id = function() {
        const e = document.querySelector("[data-thread-perm-id]");
        return e ? e.dataset.threadPermId : null
    }
    ,
    a.new.get.email_data = function(e) {
        e = e || a.new.get.email_id();
        const t = a.helper.get.new_email_id(e);
        return t ? a.cache.emailIdCache[t] : null
    }
    ,
    a.new.get.thread_data = function(e) {
        e = e || a.new.get.thread_id();
        const t = a.helper.get.thread_id(e);
        return t ? a.cache.threadCache[t] : null
    }
    ,
    "undefined" != typeof document && a.tools.xhr_watcher(),
    "undefined" != typeof document && a.tools.embedded_data_watcher(),
    a
};
"undefined" != typeof exports && (exports.Gmail = Gmail);
