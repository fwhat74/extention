window.addEventListener("focus", function() {
    reloader()
});
var isextensionenabled = !0
  , activeTab = function() {
    var e, n, t = {
        hidden: "visibilitychange",
        webkitHidden: "webkitvisibilitychange"
    };
    for (e in t)
        if (e in document) {
            n = t[e];
            break
        }
    return function(t) {
        return t && document.addEventListener(n, t),
        !document[e]
    }
}();
function reloader() {
    if (isextensionenabled) {
        var e = $("body").html()
          , n = $("body a");
        function t(e) {
            return mcUtils.extractEmails(e)
        }
        function o(e) {
            return mcUtils.extractLinks(e)
        }
        function i(e) {
            var n = [];
            return $.each(e, function(e, t) {
                -1 == $.inArray(t, n) && n.push(t)
            }),
            n
        }
        function r(e) {
            var n = "";
            for (var t in e)
                n += e[t] + "<br>";
            return n
        }
        if (null == t(e))
            chrome.runtime.sendMessage({
                from: "content",
                subject: "sendMailCount",
                mailCount: 0
            }),
            chrome.runtime.sendMessage({
                from: "content",
                subject: "sendEmails",
                mails: "None Found",
                mailsFound: "0"
            });
        else
            try {
                chrome.runtime.sendMessage({
                    from: "content",
                    subject: "sendMailCount",
                    mailCount: i(t(e)).length
                }),
                chrome.runtime.sendMessage({
                    from: "content",
                    subject: "sendEmails",
                    mails: r(i(t(e))),
                    mailsFound: i(t(e)).length,
                    url: window.location.href
                }),
                chrome.runtime.sendMessage({
                    options: "saveautosave",
                    mails: i(t(e)),
                    url: window.location.href
                })
            } catch (e) {
                console.log("Refresh the page to reload the Email Extractor Chrome extension.")
            }
        if (null == o(n))
            chrome.runtime.sendMessage({
                from: "content",
                subject: "sendLinks",
                links: []
            });
        else
            try {
                chrome.runtime.sendMessage({
                    from: "content",
                    subject: "sendLinks",
                    links: r(o(n))
                })
            } catch (e) {
                console.log("Refresh the page to reload the Email Extractor Chrome extension.")
            }
    }
}
var ee_running = !1;
if ("MutationObserver"in window) {
    var ee_observer = new MutationObserver(function(e) {
        e.forEach(function(e) {
            ee_running || 1 == activeTab() && (ee_running = !0,
            reloader(),
            setTimeout(function() {
                ee_running = !1
            }, 500))
        })
    }
    )
      , config = {
        childList: !0,
        subtree: !0
    };
    ee_observer.observe(document.body, config)
} else {
    var timeout = null;
    document.addEventListener("DOMSubtreeModified", function() {
        timeout && clearTimeout(timeout),
        1 == activeTab() && (timeout = setTimeout(reloader, 500))
    }, !1)
}
async function copyToTheClipboard(e, n) {
    var t = e
      , o = document.createElement("textarea");
    document.body.appendChild(o),
    t = t.replace(/<br\s*\/?>/gm, "\r\n"),
    o.value = t,
    o.focus(),
    o.select();
    var i = document.createElement("div");
    i.style.display = "none",
    i.style.textAlign = "center",
    i.id = "emailExtractorAlert",
    i.style.backgroundColor = "#ffffff",
    i.style.color = "#000000",
    i.style.position = "fixed",
    i.style.right = "5px",
    i.style.top = "5px",
    i.style.width = "300px",
    i.style.zIndex = "99999",
    i.style.border = "1px solid #000000",
    i.style.borderRadius = "5px",
    i.style.padding = "5px",
    document.body.appendChild(i),
    o.focus(),
    o.select(),
    navigator.clipboard.writeText(o.value).then( () => {
        i.style.color = "#008800",
        i.style.display = "block",
        i.innerHTML = "<img src='data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAR1JREFUeNpiYKAQMBJSsHDhQgEg1Q/ECVChD0DcGB8fP4GgAVDN+4HYAIt0IcgQJgIOQNZ8AYgnQF0AAvUgAqcBap7zFFpX/C3cdvpfIFSjI9DGQiC9AKoE5DoGFiwaQRLzgTgAxD9/9z8Q/z2A5CUHZPUsWDRj87OAnQ4TSG49ktwCFC9g0QzysyNIIVBzoK0O43o0uUJ4LODSXB3BXACkD0CjEUUOGB4fkA2YjxTPMM3Icc+ATTOyF9A1g9gKaJoPoGvGFgsbb21P+tDKAPbSBS9TpomGyowgDQ+AGh/gTMpAL7yHxitI8UQg9kfy8wagoYG40gvMCxOREkc9WoAl4kuqYM++vbPxgLCqPyNUIwdSPEeCvMRASwAQYADVrGCJVSOIewAAAABJRU5ErkJggg=='/> COPIED " + n + " EMAIL IDs TO CLIPBOARD"
    }
    ).catch(e => {
        i.style.color = "#ff0000",
        i.style.display = "block",
        i.innerHTML = "<img src='data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAR1JREFUeNpiYKAQMBJSsHDhQgEg1Q/ECVChD0DcGB8fP4GgAVDN+4HYAIt0IcgQJgIOQNZ8AYgnQF0AAvUgAqcBap7zFFpX/C3cdvpfIFSjI9DGQiC9AKoE5DoGFiwaQRLzgTgAxD9/9z8Q/z2A5CUHZPUsWDRj87OAnQ4TSG49ktwCFC9g0QzysyNIIVBzoK0O43o0uUJ4LODSXB3BXACkD0CjEUUOGB4fkA2YjxTPMM3Icc+ATTOyF9A1g9gKaJoPoGvGFgsbb21P+tDKAPbSBS9TpomGyowgDQ+AGh/gTMpAL7yHxitI8UQg9kfy8wagoYG40gvMCxOREkc9WoAl4kuqYM++vbPxgLCqPyNUIwdSPEeCvMRASwAQYADVrGCJVSOIewAAAABJRU5ErkJggg=='/> NOT COPIED TO CLIPBOARD!<br/> Please try again!"
    }
    ),
    setTimeout(function() {
        o.remove(),
        i.remove()
    }, 2e3);
    $("#showCurrentUrl").html()
}
chrome.runtime.sendMessage({
    options: "extensionenable"
}, function(e) {
    isextensionenabled = e.status,
    reloader()
}),
chrome.runtime.onMessage.addListener(function(e, n, t) {
    return "copyText" === e.message && copyToTheClipboard(e.textToCopy, e.elements),
    t(!0),
    !0
});
