function addLoadEvent(e) {
    var t = window.onload;
    "function" != typeof window.onload ? window.onload = e : window.onload = function() {
        t && t(),
        e()
    }
}
mcload = function() {
    chrome.runtime.onMessage.addListener(function(e, t, n) {
        void 0 !== e.message && "information_callback" === e.message && (void 0 !== e.vars ? (response = e.vars,
        document.getElementById("emailextractorinfo").setAttribute("version", "ext-" + response.version),
        document.getElementById("emailextractorinfo").setAttribute("localtoken", response.localtoken),
        document.getElementById("emailextractorinfo").setAttribute("useraccount", response.useraccount),
        document.getElementById("emailextractorinfo").setAttribute("useremails", JSON.stringify(response.useremails)),
        document.getElementById("emailextractorinfo").setAttribute("tabId", response.activeTabId)) : console.log("Email Extractor Extension error: " + JSON.stringify(chrome.runtime.lastError))),
        n({
            status: "ok"
        })
    });
    var e = document.createElement("div");
    e.id = "emailextractorinfo",
    e.setAttribute("extensionid", chrome.runtime.id),
    e.style.display = "none",
    document.getElementsByTagName("body")[0].appendChild(e),
    chrome.runtime.sendMessage(chrome.runtime.id, {
        options: "information",
        information: 1
    }, function(e) {
        chrome.runtime.lastError
    });
    var t = document.createElement("script");
    t.src = chrome.runtime.getURL("scripts/jquery.min.js"),
    t.async = !0,
    document.getElementsByTagName("body")[0].appendChild(t);
    var n = document.createElement("script");
    n.src = chrome.runtime.getURL("scripts/gmail_v3.js"),
    n.async = !0,
    document.getElementsByTagName("body")[0].appendChild(n);
    var o = document.createElement("script");
    o.src = chrome.runtime.getURL("scripts/main.js"),
    o.async = !0,
    document.getElementsByTagName("body")[0].appendChild(o);
    window.setTimeout(function() {
        var e = document.getElementById("emailextractorinfo").getAttribute("currentemail");
        null !== chrome.runtime && void 0 !== chrome.runtime && void 0 !== chrome.runtime.id && chrome.runtime.id && chrome.runtime.sendMessage(chrome.runtime.id, {
            options: "information",
            information: 1,
            useremail: e
        }, function(e) {
            chrome.runtime.lastError
        })
    }, 5e3),
    console.log("Email Extractor Chrome Extension ready!")
}
,
addLoadEvent(mcload);
