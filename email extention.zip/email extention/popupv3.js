var autovisitrefreshtimer, isdemo, bg = null;
function backgroundmanagerfunction(e) {
    chrome.runtime.sendMessage({
        message: "get_bg_vars",
        callback: e
    }, function(e) {
        chrome.runtime.lastError
    })
}
function br2nl(e) {
    return e.replace(/<br\s*\/?>/gm, "\r\n")
}
backgroundmanagerfunction("extensionInit"),
chrome.runtime.onMessage.addListener( (e, t, a) => {
    if ("got_bg_vars" === e.message || "extensionInit" === e.message)
        return (bg = e.vars).extensionenabled ? ($("#extensiononoff").attr("src", "images/iconenabled.svg"),
        $("#wrapper").show(),
        $("body").css("height", "315px"),
        $("#emailextractordisabled").hide(),
        $("#popuptitle").html("Email Extractor is enabled"),
        $("#showEmails").html("Refresh the page to capture email IDs")) : ($("#extensiononoff").attr("src", "images/icondisabled.svg"),
        $("#wrapper").hide(),
        $("body").css("height", "16px"),
        $("#emailextractordisabled").show(),
        $("#popuptitle").html("Email Extractor is disabled")),
        bg.needtorate && !bg.autosavepay && $(".ratestars").show(),
        a(!0),
        !0;
    if ("onDomReady" === e.message) {
        if (null == (bg = e.vars) && chrome.runtime.reload(),
        null !== bg) {
            document.getElementById("versionid").innerHTML = bg.version;
            var o = document.getElementById("versionid").innerHTML
              , i = bg.localtoken;
            $("#subscriptionlink").attr("href", "https://www.email-extractor.io/extension/autosave/token/" + bg.localtoken),
            $("#cleanvalidatebutton").attr("href", "https://www.email-extractor.io/extension/autosave/token/" + bg.localtoken),
            $("#buyautosave").attr("href", "https://www.email-extractor.io/extension/autosave/token/" + bg.localtoken),
            $("#currenttoken").html(bg.localtoken);
            var s = bg.useremails;
            Array.isArray(s) || (s = JSON.parse(s)),
            s.length > 0 && (i = JSON.stringify(s)),
            _gaq.push(["_trackEvent", "extensionOpened", i, o]),
            bg.autosavepay ? ($(".opennetwork").hide(),
            $("#viewtokenchange").hide(),
            $("#chkautosave").on("change", function() {
                chrome.runtime.sendMessage(chrome.runtime.id, {
                    options: "setautosave",
                    enabled: this.checked,
                    pay: !0
                }, function(e) {}),
                this.checked ? ($("#exportautosave").show(),
                $("#viewsubscription").show(),
                $("#viewtokenchange").hide(),
                enableautovisit(!0)) : enableautovisit(!1)
            }),
            bg.autosaveenabled && ($("#chkautosave").prop("checked", !0),
            enableautovisit(!0)),
            $("#exportautosave").show(),
            $("#viewsubscription").show(),
            $("#viewtokenchange").hide()) : ($("#showautovisit").addClass("notpay"),
            $("#buyautosave").show(),
            $("#fetchlinks").hide(),
            $("#trydemo").show(),
            $("#chkautosave").on("change", function() {
                this.checked ? chrome.runtime.sendMessage(chrome.runtime.id, {
                    options: "chkautosave",
                    information: 1,
                    useremail: ""
                }, function(e) {
                    chrome.runtime.lastError || (void 0 !== e ? window.setTimeout(function() {
                        bg.autosavepay ? ($("#exportautosave").show(),
                        $("#viewsubscription").show(),
                        $("#viewtokenchange").hide(),
                        enableautovisit(!0),
                        $("#showautovisit").removeClass("notpay"),
                        $("#buyautosave").hide(),
                        $("#fetchlinks").show(),
                        $("#trydemo").hide()) : (this.checked = !1,
                        $("#exportautosave").hide(),
                        $("#viewsubscription").hide(),
                        $("#viewtokenchange").show(),
                        enableautovisit(!1))
                    }, 2e3) : (console.log("Email Extractor Extension error: " + JSON.stringify(chrome.runtime.lastError)),
                    window.setTimeout(function() {
                        bg.autosavepay ? ($("#exportautosave").show(),
                        $("#viewsubscription").show(),
                        $("#viewtokenchange").hide(),
                        enableautovisit(!0),
                        $("#showautovisit").removeClass("notpay"),
                        $("#buyautosave").hide(),
                        $("#fetchlinks").show(),
                        $("#trydemo").hide()) : (this.checked = !1,
                        $("#exportautosave").hide(),
                        $("#viewsubscription").hide(),
                        $("#viewtokenchange").show(),
                        enableautovisit(!1))
                    }, 4e3)))
                }) : ($("#exportautosave").hide(),
                enableautovisit(!1))
            }),
            $("#trydemo").on("click", function() {
                $("#autovisitlinks").val("https://carlosmdh.es/en/contactar/\nhttps://orestbida.com/contact/\nhttps://www.horsetelex.com/horses/pedigree/118887/contact-me\nhttps://www.blackfemaletherapists.com/directory/listing/dr-markie-silverman/\nhttp://altkie.com/\nhttps://www.avc.edu/administration/marketing/contact\nhttps://www.stanbridge.edu/contact\nhttps://www.stowers.org/scientists/jennifer-gerton"),
                isdemo = !0,
                window.setTimeout(function() {
                    $("#autovisitbutton").click()
                }, 500)
            })),
            bg.slowenabled && $("#chkslow").prop("checked", !0)
        }
        return a(!0),
        !0
    }
    if ("fetchingEmailsAndCount" === e.message) {
        bg = e.vars;
        var n = e.variables.fetch._saveMailList
          , r = e.variables.fetch._emailsFound
          , c = e.variables.fetch._currentUrl;
        void 0 != n && "" != n || (n = "None Found"),
        void 0 == r && (r = "0"),
        bg.extensionenabled && ($("#popuptitle").html("Total Email ID's Found : <strong>" + r + "</strong>"),
        $("#showEmails").html(n),
        $("#showCurrentUrl").html(c));
        var l = $("#exportBtn");
        "" == n || "None Found" == n ? (l.attr("href", "#"),
        l.removeAttr("download"),
        $(".functionsmenu").hide()) : (bg.autosavepay || (n += "<br><br>Upgrade the extension to autosave and automate your emails ID capture."),
        l.attr("href", "data:text/plain;base64," + btoa(br2nl(n))),
        l.attr("download"),
        $(".functionsmenu").show());
        var u = $("#exportBtnCSV");
        return "" == n || "None Found" == n ? (u.attr("href", "#"),
        u.removeAttr("download")) : (bg.autosavepay || (n += "<br><br>Upgrade the extension to autosave and automate your emails ID capture."),
        u.attr("href", "data:text/csv;base64," + btoa(br2nl(n))),
        u.attr("download")),
        a(!0),
        !0
    }
    if ("autovisitrefresh" === e.message) {
        var h = (bg = e.vars).autovisitlinks;
        $("#autovisitlinks").val(h.join("\n"));
        var d = "<span>Automation";
        return h.length > 0 ? (d += " (" + h.length + ")",
        $("#showautovisit").css("width", "85px")) : $("#showautovisit").css("width", "65px"),
        d += "</span>",
        $("#showautovisit").html(d),
        -1 != bg.autovisitwindow ? ($("#autovisitlinks").attr("disabled", "disabled"),
        $("#autovisitdisabled").hide(),
        $("#autovisitlaunch").hide(),
        $("#autovisitstop").show(),
        autovisitrefreshtimer = window.setTimeout(autovisitrefresh, 1e3)) : ($("#autovisitlinks").removeAttr("disabled"),
        $("#autovisitlaunch").show(),
        $("#autovisitstop").hide(),
        $("#autovisitdisabled").hide(),
        window.clearTimeout(autovisitrefreshtimer)),
        a(!0),
        !0
    }
    if ("showsubscriptiondata" === e.message) {
        console.log(e);
        o = (bg = e.vars).version;
        var m = "https://www.email-extractor.io/extension/autosave/token/" + bg.localtoken;
        return $("#versionnumber").html("Version: " + o),
        $("#subscriptiondata").fadeIn(1e3),
        a(!0),
        !0
    }
    if ("downloadevent" === e.message) {
        m = "https://www.email-extractor.io/extension/autosave/token/" + (bg = e.vars).localtoken;
        return chrome.tabs.create({
            url: m
        }, function(e) {}),
        $("#localtoken").val(bg.localtoken),
        $("#overlay").fadeIn(1e3),
        a(!0),
        !0
    }
    if ("downloadeventxls" === e.message)
        return bg = e.vars,
        $("#localtokenxls").val(bg.localtoken),
        $("#downloadformxls").submit(),
        $("#overlay").fadeIn(1e3),
        a(!0),
        !0;
    if ("enableautovisit" === e.message)
        return bg = e.vars,
        enableautovisitafter(e.variables.status, bg),
        a(!0),
        !0;
    if ("showautovisit" === e.message)
        return bg = e.vars,
        $("#subscriptiondata").hide(),
        bg.autosavepay && !$("#chkautosave").prop("checked") && ($("#chkautosave").prop("checked", !0),
        $("#exportautosave").show(),
        $("#viewsubscription").show(),
        enableautovisit(!0),
        $("#viewtokenchange").show(),
        chrome.runtime.sendMessage(chrome.runtime.id, {
            options: "setautosave",
            enabled: !0,
            pay: !0
        }, function(e) {
            chrome.runtime.lastError
        })),
        autovisitrefresh(),
        $("#showautovisit").hide(),
        $("#autovisit").fadeIn(1e3),
        backgroundmanagerfunction("trackautovisitshow"),
        a(!0),
        !0;
    if ("executecopy" === e.message) {
        bg = e.vars;
        var v = e.variables.text
          , g = document.createElement("textarea");
        document.body.appendChild(g),
        bg.autosavepay || (v += "\n\nUpgrade the extension to autosave and automate your emails ID capture."),
        g.value = v,
        g.focus(),
        g.select(),
        document.execCommand("Copy"),
        g.remove();
        o = bg.version,
        i = bg.localtoken,
        s = bg.useremails;
        Array.isArray(s) || (s = JSON.parse(s)),
        s.length > 0 && (i = JSON.stringify(s)),
        _gaq.push(["_trackEvent", "copy", i, o]);
        var b = {
            url: $("#showCurrentUrl").html()
        };
        return chrome.runtime.sendMessage(chrome.runtime.id, {
            options: "stats",
            event: "copy",
            data: b
        }, function(e) {
            chrome.runtime.lastError
        }),
        a(!0),
        !0
    }
    if ("autovisitbutton" === e.message) {
        if (!(bg = e.vars).autosavepay && !isdemo) {
            m = "https://www.email-extractor.io/extension/autosave/token/" + bg.localtoken;
            window.setTimeout(function() {
                chrome.tabs.create({
                    url: m
                }, function(e) {})
            }, 3e3)
        }
        h = $("#autovisitlinks").val().split("\n");
        chrome.windows.create({
            width: 800,
            height: 600,
            type: "popup",
            focused: !0
        }, function(e) {
            chrome.runtime.sendMessage(chrome.runtime.id, {
                options: "autovisitnavigate",
                urls: h,
                autovisitwindow: e.id,
                isdemo: isdemo
            }, function(e) {
                autovisitrefresh()
            }),
            isdemo = !1
        }),
        h.length >= 1 ? ($("#autovisitlinks").attr("disabled", "disabled"),
        $("#autovisitdisabled").hide(),
        $("#autovisitlaunch").hide(),
        $("#autovisitstop").show()) : ($("#autovisitlinks").removeAttr("disabled"),
        $("#autovisitlaunch").show(),
        $("#autovisitdisabled").hide(),
        $("#autovisitstop").hide());
        o = bg.version,
        i = bg.localtoken,
        s = bg.useremails;
        return Array.isArray(s) || (s = JSON.parse(s)),
        s.length > 0 && (i = JSON.stringify(s)),
        isdemo ? _gaq.push(["_trackEvent", "autovisitlaunch-demo", i, o]) : _gaq.push(["_trackEvent", "autovisitlaunch", i, o]),
        a(!0),
        !0
    }
    if ("autovisitbuttonstop" === e.message)
        return bg = e.vars,
        chrome.windows.get(bg.autovisitwindow, function(e) {
            chrome.runtime.lastError || chrome.windows.remove(e.id, function() {})
        }),
        $("#autovisitlinks").removeAttr("disabled"),
        $("#autovisitlaunch").show(),
        $("#autovisitdisabled").hide(),
        $("#autovisitstop").hide(),
        window.clearTimeout(autovisitrefreshtimer),
        a(!0),
        !0;
    if ("autovisitbuttondisabled" === e.message) {
        if (!(bg = e.vars).autosavepay) {
            m = "https://www.email-extractor.io/extension/autosave/token/" + bg.localtoken;
            chrome.tabs.create({
                url: m
            }, function(e) {})
        }
        return a(!0),
        !0
    }
    if ("trackautovisitshow" === e.message) {
        i = (bg = e.vars).localtoken,
        s = bg.useremails;
        return Array.isArray(s) || (s = JSON.parse(s)),
        s.length > 0 && (i = JSON.stringify(s)),
        _gaq.push(["_trackEvent", "autovisitshow", i, bg.version]),
        a(!0),
        !0
    }
    if ("ratestar" === e.message) {
        bg = e.vars,
        selectedstar = e.variables.selectedstar;
        i = bg.localtoken;
        return _gaq.push(["_trackEvent", "rated", i, selectedstar.toString()]),
        a(!0),
        !0
    }
    if ("enableautovisitafter" === e.message)
        return bg = e.vars,
        status = e.variables.status,
        bg.autosavepay && $("#chkautosave").prop("checked") ? status ? ($("#autovisitlaunch").show(),
        $("#autovisitstop").hide(),
        $("#autovisitdisabled").hide()) : ($("#autovisitlaunch").hide(),
        $("#autovisitstop").hide(),
        $("#autovisitdisabled").show()) : ($("#autovisitlaunch").show(),
        $("#autovisitstop").hide(),
        $("#autovisitdisabled").hide()),
        a(!0),
        !0;
    if ("mailselectchk" === e.message)
        return bg = e.vars,
        selectedmails = e.variables.selectedmails,
        bg.autosavepay || (selectedmails += "<br><br>Upgrade the extension to autosave and automate your emails ID capture."),
        $("#exportBtn").attr("href", "data:text/plain;base64," + btoa(br2nl(selectedmails))),
        $("#exportBtnCSV").attr("href", "data:text/csv;base64," + btoa(br2nl(selectedmails))),
        a(!0),
        !0;
    if ("exportBtn" === e.message) {
        bg = e.vars;
        o = document.getElementById("versionid").innerHTML,
        i = bg.localtoken;
        return bg.useremails.length > 0 && (i = JSON.stringify(bg.useremails)),
        _gaq.push(["_trackEvent", "emailsExported", i, o]),
        a(!0),
        !0
    }
    if ("cleanvalidatebutton" === e.message) {
        bg = e.vars;
        o = document.getElementById("versionid").innerHTML,
        i = bg.localtoken;
        return bg.useremails.length > 0 && (i = JSON.stringify(bg.useremails)),
        _gaq.push(["_trackEvent", "cleanValidate", i, o]),
        a(!0),
        !0
    }
    if ("extensiononoff" === e.message)
        return (bg = e.vars).extensionenabled ? (chrome.runtime.sendMessage(chrome.runtime.id, {
            options: "extensionenable",
            enable: !1
        }, function(e) {
            chrome.runtime.lastError
        }),
        $(this).attr("src", "images/icondisabled.svg"),
        $("#wrapper").hide(),
        $("body").css("height", "16px"),
        $("#emailextractordisabled").show(),
        $("#popuptitle").html("Email Extractor is disabled")) : (chrome.runtime.sendMessage(chrome.runtime.id, {
            options: "extensionenable",
            enable: !0
        }, function(e) {
            chrome.runtime.lastError
        }),
        $(this).attr("src", "images/iconenabled.svg"),
        $("#wrapper").show(),
        $("body").css("height", "315px"),
        $("#emailextractordisabled").hide(),
        $("#popuptitle").html("Email Extractor is enabled"),
        $("#showEmails").html("Refresh the page to capture email IDs")),
        a(!0),
        !0;
    if ("showEmailscopy" === e.message) {
        o = (bg = e.vars).version,
        i = bg.localtoken;
        bg.useremails.length > 0 && (i = JSON.stringify(bg.useremails)),
        _gaq.push(["_trackEvent", "copy-keys", i, o]);
        b = {
            url: $("#showCurrentUrl").html()
        };
        return chrome.runtime.sendMessage(chrome.runtime.id, {
            options: "stats",
            event: "copy-keys",
            data: b
        }, function(e) {
            chrome.runtime.lastError
        }),
        bg.autosavepay || (event.preventDefault(),
        executeCopy(window.getSelection())),
        a(!0),
        !0
    }
}
),
$(".ratestar").on("mouseover", function(e) {
    e.preventDefault(),
    e.stopPropagation();
    var t = document.querySelectorAll(".ratestar")
      , a = 0;
    for (i = 0; i < t.length; i++)
        t[i] === this && (a = i);
    for (i = 0; i < t.length; i++)
        t[i].className = "ratestar",
        i <= a && (t[i].className += " on")
}),
$(".ratestar").on("click", function(e) {
    e.preventDefault(),
    e.stopPropagation();
    var t = document.querySelectorAll(".ratestar")
      , a = 0;
    for (i = 0; i < t.length; i++)
        t[i] === this && (a = i);
    var o = document.querySelectorAll(".ratestars");
    o.length > 0 && o[0].remove(),
    a += 1,
    chrome.runtime.sendMessage(chrome.runtime.id, {
        options: "rated"
    }, function(e) {
        chrome.runtime.sendMessage({
            message: "get_bg_vars",
            callback: "ratestar",
            variables: {
                selectedstar: a
            }
        }, function(e) {
            chrome.runtime.lastError,
            a >= 4 && window.open("https://chrome.google.com/webstore/detail/jdianbbpnakhcmfkcckaboohfgnngfcc/reviews", "_blank")
        })
    })
}),
$(".ratestars").on("mouseover", function(e) {
    e.preventDefault(),
    e.stopPropagation();
    var t = document.querySelectorAll(".ratestar");
    for (i = 0; i < t.length; i++)
        t[i].className = "ratestar"
}),
isdemo || (isdemo = !1),
chrome.runtime.sendMessage(chrome.runtime.id, {
    options: "counter"
}, function(e) {
    chrome.runtime.lastError
}),
chrome.storage.local.get(function(e) {
    chrome.runtime.sendMessage({
        message: "get_bg_vars",
        callback: "fetchingEmailsAndCount",
        variables: {
            fetch: e
        }
    }, function(e) {
        chrome.runtime.lastError
    })
});
var downloadevent = function() {
    return backgroundmanagerfunction("downloadevent"),
    !1
}
  , downloadeventxls = function() {
    return backgroundmanagerfunction("downloadeventxls"),
    !1
};
function enableautovisit(e) {
    chrome.runtime.sendMessage({
        message: "get_bg_vars",
        callback: "enableautovisit",
        variables: {
            status: e
        }
    }, function(e) {
        chrome.runtime.lastError
    })
}
function enableautovisitafter(e, t) {
    t.autosavepay && $("#chkautosave").prop("checked") ? e ? ($("#autovisitlaunch").show(),
    $("#autovisitstop").hide(),
    $("#autovisitdisabled").hide()) : ($("#autovisitlaunch").hide(),
    $("#autovisitstop").hide(),
    $("#autovisitdisabled").show()) : ($("#autovisitlaunch").show(),
    $("#autovisitstop").hide(),
    $("#autovisitdisabled").hide()),
    e ? ($("#selectblock").hide(),
    $("#showEmailsSelect").hide(),
    $("#showEmails").show(),
    $("#selectblockallnone").hide()) : ($("#selectblock").show(),
    $("#selectblockallnone").hide())
}
function executeCopy(e) {
    chrome.runtime.sendMessage({
        message: "get_bg_vars",
        callback: "executecopy",
        variables: {
            text: e
        }
    }, function(e) {
        chrome.runtime.lastError
    })
}
$("#overlay img").on("click", function() {
    $(this).parent().fadeOut(1e3)
}),
$("#autovisit img").on("click", function() {
    $(this).parent().fadeOut(1e3),
    $("#showautovisit").show()
}),
$("#fetchlinks").on("click", function() {
    chrome.storage.local.get(function(e) {
        var t = e._saveLinkList;
        $("#autovisitlinks").val(br2nl(t))
    })
}),
$("#clearlinks").on("click", function() {
    $("#autovisitlinks").val(""),
    $("#showautovisit").css("width", "65px"),
    $("#showautovisit").html("<span>Automation</span>")
}),
$("#clipboardcopy").on("click", function() {
    executeCopy(br2nl($("#showEmails").html())),
    $("#clipboardcopy").text("Copied"),
    window.setTimeout(function() {
        $("#clipboardcopy").text("Copy"),
        $(".clipboardcopy").text("Copy all")
    }, 1e3)
}),
$("#selectmailsall").on("click", function() {
    for (i = 0; i < $(".mailselectchk").length; i++)
        $(".mailselectchk")[i].checked = !0,
        $(".mainfunctionsmenu").show(),
        $("#clipboardcopy").text("Copy all")
}),
$("#selectmailsnone").on("click", function() {
    for (i = 0; i < $(".mailselectchk").length; i++)
        $(".mailselectchk")[i].checked = !1,
        $(".mainfunctionsmenu").hide()
}),
$("#selectmails").on("click", function() {
    $("#selectblock").hide(),
    $("#selectblockallnone").show();
    var e = $("#showEmails").html().split("<br>")
      , t = "<table style='width:265px;'><col width='238'>";
    for (i = 0; i < e.length; i++)
        e[i].length > 0 && (t += "<tr>",
        t += "<td style='width:238px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:238px;flex-grow:1;'><input checked class='mailselectchk' type='checkbox' name='email-" + i + "' value='" + e[i] + "'><span>" + e[i] + "</span></td>",
        t += "</tr>");
    t += "</table>",
    $("#showEmailsSelect").html(t),
    $("#showEmails").hide(),
    $("#showEmailsSelect").show(),
    $(".mailselectchk").on("change", function() {
        $(".mailselectchk").length == $(".mailselectchk:checked").length ? $("#clipboardcopy").text("Copy all") : $("#clipboardcopy").text("Copy"),
        this.checked ? $(".mainfunctionsmenu").show() : ($("#clipboardcopy").text("Copy"),
        0 == $(".mailselectchk:checked").length && $(".mainfunctionsmenu").hide());
        var e = "";
        for (i = 0; i < $(".mailselectchk:checked ~ span").length; i++)
            e += $(".mailselectchk:checked ~ span")[i].textContent + "<br>";
        $("#showEmails").html(e),
        chrome.runtime.sendMessage({
            message: "get_bg_vars",
            callback: "mailselectchk",
            variables: {
                selectedmails: e
            }
        }, function(e) {
            chrome.runtime.lastError
        })
    })
}),
$("#autovisitbutton").on("click", function(e) {
    e.preventDefault(),
    backgroundmanagerfunction("autovisitbutton")
}),
$("#autovisitbuttonstop").on("click", function() {
    backgroundmanagerfunction("autovisitbuttonstop")
}),
$("#autovisitbuttondisabled").on("click", function() {
    return backgroundmanagerfunction("autovisitbuttondisabled"),
    !1
});
var autovisitrefresh = function() {
    backgroundmanagerfunction("autovisitrefresh")
};
$("#help").on("click", function() {
    $("#overlay").fadeIn(1e3)
}),
$("#exportBtn").on("click", function() {
    backgroundmanagerfunction("exportBtn")
}),
$("#cleanvalidatebutton").on("click", function() {
    backgroundmanagerfunction("cleanvalidatebutton")
});
var _gaq = _gaq || [];
function getDomainName(e) {
    return e.indexOf("//") >= 0 && (e = e.substr(e.indexOf("//") + 2)),
    e.indexOf("/") >= 0 && (e = e.substr(0, e.indexOf("/"))),
    e.substring(e.lastIndexOf(".", e.lastIndexOf(".") - 1) + 1)
}
_gaq.push(["_setAccount", "UA-40620403-5"]),
_gaq.push(["_trackPageview"]),
function() {
    var e = document.createElement("script");
    e.type = "text/javascript",
    e.async = !0,
    e.src = chrome.runtime.getURL("scripts/ga.js");
    var t = document.getElementsByTagName("script")[0];
    t.parentNode.insertBefore(e, t),
    backgroundmanagerfunction("onDomReady"),
    document.getElementById("download-csv") && document.getElementById("download-csv").addEventListener("click", downloadevent),
    document.getElementById("download-xls") && document.getElementById("download-xls").addEventListener("click", downloadeventxls)
}(),
$("#overlay img").on("click", function() {
    $(this).parent().fadeOut(1e3)
}),
$("#subscriptiondata img").on("click", function() {
    $(this).parent().fadeOut(1e3)
}),
$("#extensiononoff").on("click", function() {
    backgroundmanagerfunction("extensiononoff")
}),
$("#help").on("click", function() {
    $("#overlay").fadeIn(1e3)
}),
$("#showautovisit").on("click", function() {
    backgroundmanagerfunction("showautovisit")
}),
$("#showEmails").bind("copy", function() {
    backgroundmanagerfunction("showEmailscopy")
}),
$("#showsubscriptiondata").on("click", function() {
    backgroundmanagerfunction("showsubscriptiondata")
}),
$("#changetoken").on("click", function() {
    var e = $("#newtoken").val();
    chrome.runtime.sendMessage(chrome.runtime.id, {
        options: "changetoken",
        token: e
    }, function(e) {
        chrome.runtime.lastError
    })
}),
$("#chkslow").on("change", function() {
    chrome.runtime.sendMessage(chrome.runtime.id, {
        options: "setslow",
        enabled: this.checked
    }, function(e) {
        chrome.runtime.lastError
    })
}),
autovisitrefresh();
