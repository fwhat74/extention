var Gmail_ = function(e) {
    var t;
    void 0 !== e ? t = e : "undefined" != typeof jQuery && (t = jQuery);
    var r = {
        get: {},
        observe: {},
        check: {},
        tools: {},
        tracker: {},
        dom: {},
        chat: {},
        compose: {},
        helper: {
            get: {}
        },
        version: "0.5"
    };
    return r.tracker.globals = "undefined" != typeof GLOBALS ? GLOBALS : null != window.opener && void 0 !== window.opener.GLOBALS ? window.opener.GLOBALS : [],
    r.tracker.view_data = "undefined" != typeof VIEW_DATA ? VIEW_DATA : null != window.opener && void 0 !== window.opener.VIEW_DATA ? window.opener.VIEW_DATA : [],
    r.tracker.ik = r.tracker.globals[9] || "",
    r.tracker.hangouts = void 0,
    r.get.last_active = function() {
        var e = r.tracker.globals[17][15];
        return {
            time: e[1],
            ip: e[3],
            mac_address: e[9],
            time_relative: e[10]
        }
    }
    ,
    r.get.loggedin_accounts = function() {
        var e, t, a, o = [], n = r.tracker.globals[17];
        for (e in n)
            if ("mla" === (a = n[e])[0]) {
                for (t in a[1])
                    o.push({
                        name: a[1][t][4],
                        email: a[1][t][0],
                        index: a[1][t][3]
                    });
                return o
            }
        return o
    }
    ,
    r.get.user_email = function() {
        return r.tracker.globals[10]
    }
    ,
    r.get.manager_email = function() {
        return r.helper.get.is_delegated_inbox() ? r.get.delegated_to_email() : r.get.user_email()
    }
    ,
    r.get.delegated_to_email = function() {
        if (!r.helper.get.is_delegated_inbox())
            return null;
        var e, a, o = window.location.pathname, n = parseInt(o.substring(o.indexOf("/u/") + "/u/".length), 10), i = r.get.loggedin_accounts();
        if (i && i.length > 0)
            for (e in i)
                if ((a = i[e]).index === n)
                    return a.email;
        return t(".gb_rb[href$='/u/" + n + "'] .gb_yb").text().split(" ")[0]
    }
    ,
    r.get.localization = function() {
        var e = function(e) {
            if (!e || "string" != typeof e || e.length < 2)
                return !1;
            var t = e.slice(0, 2);
            return t.toLowerCase() === t
        }
          , t = r.tracker.globals
          , a = t[17] && t[17][8] && t[17][8][8];
        return e(a) ? a : e(a = t[17] && t[17][9] && t[17][9][8]) ? a : null
    }
    ,
    r.check.is_thread = function() {
        var e = t(".nH .if").children(":eq(1)").children().children(":eq(1)").children()
          , a = r.get.email_ids();
        return e.length > 1 || a.length > 1
    }
    ,
    r.dom.inbox_content = function() {
        return t("div[role=main]:first")
    }
    ,
    r.check.is_preview_pane = function() {
        var e = !1;
        return r.dom.inbox_content().find("[gh=tl]").each(function() {
            t(this).hasClass("aia") && (e = !0)
        }),
        e
    }
    ,
    r.check.is_multiple_inbox = function() {
        return r.dom.inboxes().length > 1
    }
    ,
    r.check.is_horizontal_split = function() {
        return 0 == r.dom.inbox_content().find("[gh=tl]").find(".nn").length
    }
    ,
    r.check.is_vertical_split = function() {
        return 0 == r.check.is_horizontal_split()
    }
    ,
    r.check.is_tabbed_inbox = function() {
        return 1 == t(".aKh").length
    }
    ,
    r.check.is_right_side_chat = function() {
        var e = t(".ApVoH");
        return 0 !== e.length && ":wf" == e[0].getAttribute("aria-labelledby")
    }
    ,
    r.check.should_compose_fullscreen = function() {
        var e = [];
        try {
            e = r.tracker.globals[17][4][1][32]
        } catch (t) {
            e = ["bx_scfs", "false"]
        }
        return "true" == e[1]
    }
    ,
    r.check.is_google_apps_user = function() {
        var e = r.get.user_email();
        return -1 == e.indexOf("gmail.com", e.length - "gmail.com".length)
    }
    ,
    r.get.storage_info = function() {
        var e = t(".md.mj").find("div")[0]
          , r = t(e).find("span")[0].text
          , a = t(e).find("span")[1].text
          , o = 100 * parseFloat(r.replace(/[^0-9\.]/g, "")) / parseFloat(a.replace(/[^0-9\.]/g, ""));
        return {
            used: r,
            total: a,
            percent: Math.floor(o)
        }
    }
    ,
    r.dom.inboxes = function() {
        return r.dom.inbox_content().find("[gh=tl]")
    }
    ,
    r.dom.email_subject = function() {
        for (var e = t(".hP"), r = 0; r < e.length; r++)
            if (t(e[r]).is(":visible"))
                return t(e[r]);
        return t()
    }
    ,
    r.get.email_subject = function() {
        return r.dom.email_subject().text()
    }
    ,
    r.dom.email_body = function() {
        return t(".nH.hx")
    }
    ,
    r.dom.toolbar = function() {
        for (var e = t("[gh='mtb']"); 1 == t(e).children().length; )
            e = t(e).children().first();
        return e
    }
    ,
    r.check.is_inside_email = function() {
        if ("email" != r.get.current_page() && !r.check.is_preview_pane())
            return !1;
        for (var e = t(".ii.gt .a3s.aXjCH"), a = [], o = 0; o < e.length; o++) {
            var n = e[o].getAttribute("class").split(" ")[2];
            "undefined" != n && void 0 != n && t(e[o]).is(":visible") && a.push(e[o])
        }
        return a.length > 0
    }
    ,
    r.check.is_plain_text = function() {
        for (var e = GLOBALS[17][4][1], t = 0; t < e.length; t++) {
            var r = e[t];
            if ("bx_cm" === r[0])
                return "0" === r[1]
        }
        return !1
    }
    ,
    r.dom.email_contents = function() {
        for (var e = t(".ii.gt div.a3s.aXjCH"), r = [], a = 0; a < e.length; a++) {
            var o = e[a].getAttribute("class").split(" ")[2]
              , n = e[a].getAttribute("contenteditable");
            "undefined" != o && void 0 != o && "true" != n && r.push(e[a])
        }
        return r
    }
    ,
    r.get.email_ids = function() {
        if (r.check.is_inside_email()) {
            var e = r.get.email_data();
            return Object.keys(e.threads)
        }
        return []
    }
    ,
    r.get.compose_ids = function() {
        for (var e = [], r = t(".AD [name=draft]"), a = 0; a < r.length; a++)
            "undefined" != r[a].value && e.push(r[a].value);
        return e
    }
    ,
    r.get.email_id = function() {
        var e = null;
        if (r.check.is_inside_email())
            if (r.check.is_preview_pane()) {
                for (var t = r.dom.email_contents(), a = [], o = 0; o < t.length; o++) {
                    var n = t[o].children[0].getAttribute("class").split(" ")[2]
                      , i = t[o].getAttribute("contenteditable")
                      , s = t[o].offsetWidth > 0 && t[o].offsetHeight > 0;
                    "undefined" != n && void 0 != n && s && "true" != i && a.push(n)
                }
                e = a[0].substring(1, a[0].length)
            } else
                e = window.location.hash.split("/").pop().replace(/#/, "").split("?")[0];
        else
            e = r.tools.parse_url(window.location.href).th;
        return e
    }
    ,
    r.check.is_priority_inbox = function() {
        return t(".qh").length > 0
    }
    ,
    r.check.is_rapportive_installed = function() {
        return 1 == t("#rapportive-sidebar").length
    }
    ,
    r.check.is_streak_installed = function() {
        return t("[id^='bentoBox'],[id*=' bentoBox'],[class*=' bentoBox'],[class*='bentoBox']").length > 0
    }
    ,
    r.check.is_anydo_installed = function() {
        return t("[id^='anydo'],[id*=' anydo'],[class*=' anydo'],[class*='anydo']").length > 0
    }
    ,
    r.check.is_boomerang_installed = function() {
        return t("[id^='b4g_'],[id*=' b4g_'],[class*=' b4g_'],[class*='b4g_']").length > 0
    }
    ,
    r.check.is_xobni_installed = function() {
        return t("#xobni_frame").length > 0
    }
    ,
    r.check.is_signal_installed = function() {
        return t("[id^='Signal'],[id*=' Signal'],[class*=' signal'],[class*='signal']").length > 0
    }
    ,
    r.check.are_shortcuts_enabled = function() {
        for (var e = void 0, t = !0, a = r.tracker.globals[17][4][1], o = 0; o < a.length; o++) {
            var n = a[o];
            if ("bx_hs" === n[0]) {
                e = n[1];
                break
            }
        }
        if (void 0 !== e) {
            t = {
                0: !0,
                1: !1
            }[e]
        }
        return t
    }
    ,
    r.dom.get_left_sidebar_links = function() {
        return t("div[role=navigation] [title]")
    }
    ,
    r.dom.search_bar = function() {
        return t("[gh=sb]")
    }
    ,
    r.get.search_query = function() {
        return r.dom.search_bar().find("input")[0].value
    }
    ,
    r.get.unread_inbox_emails = function() {
        var e = t("div[role=navigation]").find("[title*='" + r.tools.i18n("inbox") + "']");
        return e.length > 0 && -1 != e[0].text.indexOf("(") ? parseInt(e[0].text.replace(/[^0-9]/g, "")) : 0
    }
    ,
    r.get.unread_draft_emails = function() {
        var e = t("div[role=navigation]").find("[title*='" + r.tools.i18n("drafts") + "']");
        return e.length > 0 && -1 != e[0].text.indexOf("(") ? parseInt(e[0].text.replace(/[^0-9]/g, "")) : 0
    }
    ,
    r.get.unread_spam_emails = function() {
        var e = t("div[role=navigation]").find("[title*='" + r.tools.i18n("spam") + "']");
        return e.length > 0 && -1 != e[0].text.indexOf("(") ? parseInt(e[0].text.replace(/[^0-9]/g, "")) : 0
    }
    ,
    r.get.unread_forum_emails = function() {
        var e = t("div[role=navigation]").find("[title*='" + r.tools.i18n("forums") + "']");
        return e.length > 0 && -1 != e[0].text.indexOf("(") ? parseInt(e[0].text.replace(/[^0-9]/g, "")) : 0
    }
    ,
    r.get.unread_update_emails = function() {
        var e = t("div[role=navigation]").find("[title*='" + r.tools.i18n("updates") + "']");
        return e.length > 0 && -1 != e[0].text.indexOf("(") ? parseInt(e[0].text.replace(/[^0-9]/g, "")) : 0
    }
    ,
    r.get.unread_promotion_emails = function() {
        var e = t("div[role=navigation]").find("[title*='" + r.tools.i18n("promotions") + "']");
        return e.length > 0 && -1 != e[0].text.indexOf("(") ? parseInt(e[0].text.replace(/[^0-9]/g, "")) : 0
    }
    ,
    r.get.unread_social_emails = function() {
        var e = t("div[role=navigation]").find("[title*='" + r.tools.i18n("social_updates") + "']");
        return e.length > 0 && -1 != e[0].text.indexOf("(") ? parseInt(e[0].text.replace(/[^0-9]/g, "")) : 0
    }
    ,
    r.get.beta = function() {
        return {
            new_nav_bar: 0 == t("#gbz").length
        }
    }
    ,
    r.get.unread_emails = function() {
        return {
            inbox: r.get.unread_inbox_emails(),
            drafts: r.get.unread_draft_emails(),
            spam: r.get.unread_spam_emails(),
            forum: r.get.unread_forum_emails(),
            update: r.get.unread_update_emails(),
            promotions: r.get.unread_promotion_emails(),
            social: r.get.unread_social_emails()
        }
    }
    ,
    r.tools.error = function(e) {
        if (!console)
            throw e;
        console.error(e)
    }
    ,
    r.tools.parse_url = function(e) {
        for (var t, r = /[?&]([^=#]+)=([^&#]*)/g, a = {}; t = r.exec(e); )
            a[t[1]] = t[2];
        return a
    }
    ,
    r.tools.sleep = function(e) {
        for (var t = (new Date).getTime(); !((new Date).getTime() - t > e); )
            ;
    }
    ,
    r.tools.multitry = function(e, t, a, o, n, i) {
        if (void 0 != n && n >= t)
            return i;
        n = void 0 == n ? 0 : n;
        var s = a();
        if (o(s))
            return s;
        r.tools.sleep(e),
        r.tools.multitry(e, t, a, o, n + 1, s)
    }
    ,
    r.tools.deparam = function(e, t) {
        var r = Array.isArray || function(e) {
            return "[object Array]" == Object.prototype.toString.call(e)
        }
          , a = {}
          , o = {
            true: !0,
            false: !1,
            null: null
        };
        return function(e, t) {
            for (var r = [], a = 0; a < e.length; a++)
                r.push(t(e[a]))
        }(e.replace(/\+/g, " ").split("&"), function(e, n) {
            var i, s = e.split("="), l = decodeURIComponent(s[0]), c = a, d = 0, u = l.split("]["), m = u.length - 1;
            if (/\[/.test(u[0]) && /\]$/.test(u[m]) ? (u[m] = u[m].replace(/\]$/, ""),
            m = (u = u.shift().split("[").concat(u)).length - 1) : m = 0,
            2 === s.length)
                if (i = decodeURIComponent(s[1]),
                t && (i = i && !isNaN(i) ? +i : "undefined" === i ? void 0 : void 0 !== o[i] ? o[i] : i),
                m)
                    for (; d <= m; d++)
                        c = c[l = "" === u[d] ? c.length : u[d]] = d < m ? c[l] || (u[d + 1] && isNaN(u[d + 1]) ? {} : []) : i;
                else
                    r(a[l]) ? a[l].push(i) : void 0 !== a[l] ? a[l] = [a[l], i] : a[l] = i;
            else
                l && (a[l] = t ? void 0 : "")
        }),
        a
    }
    ,
    r.tools.parse_actions = function(e, t) {
        if ("fup" == e.url.act || "fuv" == e.url.act || e.body_is_object)
            return !(!e.body_is_object || !r.observe.bound("upload_attachment")) && {
                upload_attachment: [e.body_params]
            };
        e.url.search;
        var a = {}
          , o = {
            tae: "add_to_tasks",
            "rc_^i": "archive",
            tr: "delete",
            cs: "undo_send",
            dm: "delete_message_in_thread",
            dl: "delete_forever",
            dc_: "delete_label",
            dr: "discard_draft",
            el: "expand_categories",
            cffm: "filter_messages_like_these",
            arl: "label",
            mai: "mark_as_important",
            mani: "mark_as_not_important",
            us: "mark_as_not_spam",
            sp: "mark_as_spam",
            mt: "move_label",
            ib: "move_to_inbox",
            ig: "mute",
            rd: "read",
            sd: "save_draft",
            sm: "send_message",
            mo: "show_newly_arrived_message",
            st: "star",
            ug: "unmute",
            ur: "unread",
            xst: "unstar",
            new_mail: "new_email",
            poll: "poll",
            refresh: "refresh",
            rtr: "restore_message_in_thread",
            open_email: "open_email",
            toggle_threads: "toggle_threads"
        };
        "string" == typeof e.url.ik && (r.tracker.ik = e.url.ik),
        "string" == typeof e.url.at && (r.tracker.at = e.url.at),
        "string" == typeof e.url.rid && -1 != e.url.rid.indexOf("mail") && (r.tracker.rid = e.url.rid);
        var n = decodeURIComponent(e.url.act)
          , i = e.body_params
          , s = "string" == typeof i.t ? [i.t] : i.t
          , l = null;
        switch (n) {
        case "cs":
        case "ur":
        case "rd":
        case "tr":
        case "sp":
        case "us":
        case "ib":
        case "dl":
        case "st":
        case "xst":
        case "mai":
        case "mani":
        case "ig":
        case "ug":
        case "dr":
        case "mt":
        case "cffm":
        case "rc_^i":
            l = [s, e.url, e.body];
            break;
        case "arl":
            l = [s, e.url, e.body, e.url.acn];
            break;
        case "sd":
            l = [s, e.url, i];
            break;
        case "tae":
        case "sm":
            l = [e.url, e.body, i];
            break;
        case "el":
            l = [e.url, e.body, "1" == i.ex];
            break;
        case "dm":
        case "rtr":
        case "mo":
            l = [i.m, e.url, e.body]
        }
        return "string" == typeof e.url._reqid && "tl" === e.url.view && void 0 != e.url.auto && (l = [e.url.th, e.url, e.body],
        r.observe.bound("new_email") && (a.new_email = l)),
        "cv" != e.url.view && "ad" != e.url.view || "string" != typeof e.url.th || "string" != typeof e.url.search || void 0 != e.url.rid || (l = [e.url.th, e.url, e.body],
        r.observe.bound("open_email") && (a.open_email = l)),
        "cv" != e.url.view && "ad" != e.url.view || "object" != typeof e.url.th || "string" != typeof e.url.search || void 0 == e.url.rid || (l = [e.url.th, e.url, e.body],
        r.observe.bound("toggle_threads") && (a.toggle_threads = l)),
        "cv" != e.url.view && "ad" != e.url.view || "string" != typeof e.url.th || "string" != typeof e.url.search || void 0 == e.url.rid || void 0 != e.url.msgs && (l = [e.url.th, e.url, e.body],
        r.observe.bound("toggle_threads") && (a.toggle_threads = l)),
        "string" == typeof e.url.SID && "string" == typeof e.url.zx && -1 != e.body.indexOf("req0_") && (r.tracker.SID = e.url.SID,
        l = [e.url, e.body, i],
        r.observe.bound("poll") && (a.poll = l)),
        "string" == typeof e.url.ik && "string" == typeof e.url.search && 0 == e.body.length && "string" == typeof e.url._reqid && (l = [e.url, e.body, i],
        r.observe.bound("refresh") && (a.refresh = l)),
        l && o[n] && r.observe.bound(o[n]) && (a[o[n]] = l),
        "POST" != e.method || "string" != typeof e.url.SID && "string" != typeof e.url.ik && "string" != typeof e.url.act || (a.http_event = [e]),
        a
    }
    ,
    r.tools.parse_response = function(e) {
        var t, r, a, o, n = [];
        try {
            for (e = (e = e.replace(/\n/g, " ")).substring(e.indexOf("'") + 1, e.length); e.replace(/\s/g, "").length > 1; ) {
                (r = e.substring(0, e.indexOf("[")).replace(/\s/g, "")) || (r = e.length),
                a = parseInt(r, 10) - 2 + e.indexOf("["),
                t = e.substring(e.indexOf("["), a),
                o = new Function('"use strict"; return ' + t)(),
                n.push(o),
                e = (e = e.substring(e.indexOf("["), e.length)).substring(t.length, e.length)
            }
        } catch (e) {
            console.log("Gmail post response parsing failed.", e)
        }
        return n
    }
    ,
    r.tools.parse_requests = function(e, t) {
        e.url_raw = e.url,
        e.url = r.tools.parse_url(e.url),
        "object" == typeof e.body ? (e.body_params = e.body,
        e.body_is_object = !0) : e.body_params = r.tools.deparam(e.body),
        "object" != typeof r.tracker.events && "object" != typeof r.tracker.actions && (r.tracker.events = [],
        r.tracker.actions = []),
        r.tracker.events.unshift(e);
        var a = r.tools.parse_actions(e, t);
        return "POST" == e.method && "string" == typeof e.url.act && r.tracker.actions.unshift(e),
        r.tracker.events.length > 50 && r.tracker.events.pop(),
        r.tracker.actions.length > 10 && r.tracker.actions.pop(),
        a
    }
    ,
    r.tools.xhr_watcher = function() {
        if (!r.tracker.xhr_init) {
            r.tracker.xhr_init = !0;
            var e = top.document.getElementById("js_frame") ? top.document.getElementById("js_frame").contentDocument.defaultView : window.opener.top.document.getElementById("js_frame").contentDocument.defaultView;
            e.gjs_XMLHttpRequest_open || (e.gjs_XMLHttpRequest_open = e.XMLHttpRequest.prototype.open),
            e.XMLHttpRequest.prototype.open = function(t, r, a, o, n) {
                var i = e.gjs_XMLHttpRequest_open.apply(this, arguments);
                return this.xhrParams = {
                    method: t.toString(),
                    url: r.toString()
                },
                i
            }
            ,
            e.gjs_XMLHttpRequest_send || (e.gjs_XMLHttpRequest_send = e.XMLHttpRequest.prototype.send),
            e.XMLHttpRequest.prototype.send = function(a) {
                var o = !1;
                if (this.xhrParams && (this.xhrParams.body = a,
                o = r.tools.parse_requests(this.xhrParams, this)),
                r.observe.trigger("before", o, this) && (a = arguments[0] = this.xhrParams.body_is_object ? this.xhrParams.body_params : t.param(this.xhrParams.body_params, !0).replace(/\+/g, "%20")),
                r.observe.bound(o, "after")) {
                    var n = this.onreadystatechange
                      , i = this;
                    this.onreadystatechange = function(e) {
                        this.readyState === this.DONE && (i.xhrResponse = r.tools.parse_response(e.target.responseText),
                        r.observe.trigger("after", o, i)),
                        n && n.apply(this, arguments)
                    }
                }
                var s = e.gjs_XMLHttpRequest_send.apply(this, arguments);
                return r.observe.trigger("on", o, this),
                s
            }
        }
    }
    ,
    r.observe.http_requests = function() {
        return r.tracker.events
    }
    ,
    r.observe.actions = function() {
        return r.tracker.actions
    }
    ,
    r.observe.bind = function(e, t, a) {
        "object" != typeof r.tracker.watchdog && (r.tracker.watchdog = {
            before: {},
            on: {},
            after: {},
            dom: {}
        },
        r.tracker.bound = {}),
        "object" != typeof r.tracker.watchdog[e] && r.tools.error("api.observe.bind called with invalid type: " + e),
        "dom" == e || r.tracker.xhr_init || r.tools.xhr_watcher(),
        "object" != typeof r.tracker.watchdog[e][t] && (r.tracker.watchdog[e][t] = []),
        r.tracker.watchdog[e][t].push(a),
        r.tracker.bound[t] = void 0 === r.tracker.bound[t] ? 1 : r.tracker.bound[t] + 1,
        r.tracker.bound[e] = void 0 === r.tracker.bound[e] ? 1 : r.tracker.bound[e] + 1
    }
    ,
    r.observe.on = function(e, t, a) {
        if (r.observe.on_dom(e, t))
            return !0;
        r.observe.bind("on", e, t),
        a && r.observe.after(e, t)
    }
    ,
    r.observe.before = function(e, t) {
        r.observe.bind("before", e, t)
    }
    ,
    r.observe.after = function(e, t) {
        r.observe.bind("after", e, t)
    }
    ,
    r.observe.bound = function(e, a) {
        if ("object" != typeof r.tracker.watchdog)
            return !1;
        if (e) {
            if ("object" == typeof e) {
                var o = !1;
                return t.each(e, function(e, t) {
                    "object" == typeof r.tracker.watchdog[a][e] && (o = !0)
                }),
                o
            }
            return a ? "object" == typeof r.tracker.watchdog[a][e] : r.tracker.bound[e] > 0
        }
        if (a)
            return r.tracker.bound[a] > 0;
        r.tools.error("api.observe.bound called with invalid args")
    }
    ,
    r.observe.off = function(e, a) {
        if ("object" != typeof r.tracker.watchdog)
            return !0;
        var o = a ? [a] : ["before", "on", "after", "dom"];
        t.each(o, function(a, o) {
            if ("object" != typeof r.tracker.watchdog[o])
                return !0;
            e ? "object" == typeof r.tracker.watchdog[o][e] && (r.tracker.bound[e] -= r.tracker.watchdog[o][e].length,
            r.tracker.bound[o] -= r.tracker.watchdog[o][e].length,
            delete r.tracker.watchdog[o][e]) : t.each(r.tracker.watchdog[o], function(e, t) {
                "object" == typeof r.tracker.watchdog[o][e] && (r.tracker.bound[e] -= r.tracker.watchdog[o][e].length,
                r.tracker.bound[o] -= r.tracker.watchdog[o][e].length,
                delete r.tracker.watchdog[o][e])
            })
        })
    }
    ,
    r.observe.trigger = function(e, a, o) {
        if (!a)
            return !1;
        var n = !1;
        return t.each(a, function(a, i) {
            i = t.extend([], i),
            "after" == e && i.push(o.xhrResponse),
            i.push(o),
            r.observe.bound(a, e) && (n = !0,
            t.each(r.tracker.watchdog[e][a], function(e, t) {
                t.apply(void 0, i)
            }))
        }),
        n
    }
    ,
    r.observe.trigger_dom = function(e, a, o) {
        o || (o = function(e, t) {
            t(e)
        }
        ),
        r.tracker.watchdog.dom[e] && t.each(r.tracker.watchdog.dom[e], function(e, t) {
            o(a, t)
        })
    }
    ,
    r.observe.initialize_dom_observers = function() {
        r.tracker.dom_observer_init = !0,
        r.tracker.supported_observers = ["view_thread", "view_email", "load_email_menu", "recipient_change", "compose"],
        r.tracker.dom_observers = {
            view_thread: {
                class: ["Bu", "nH"],
                sub_selector: "div.if",
                handler: function(e, t) {
                    t(e = new r.dom.thread(e));
                    var a = e.dom("opened_email");
                    a.length && r.observe.trigger_dom("view_email", a, r.tracker.dom_observers.view_thread.sub_observers.view_email.handler)
                },
                sub_observers: {
                    view_email: {
                        class: "",
                        sub_selector: "div.adn",
                        handler: function(e, t) {
                            t(e = new r.dom.email(e))
                        }
                    },
                    load_email_menu: {
                        class: "J-N",
                        selector: "div[role=menu] div[role=menuitem]:first-child",
                        handler: function(e, t) {
                            t(e = e.closest("div[role=menu]"))
                        }
                    }
                }
            },
            recipient_change: {
                class: "vR",
                handler: function(e, t) {
                    "object" != typeof r.tracker.recipient_matches && (r.tracker.recipient_matches = []),
                    r.tracker.recipient_matches.push(e),
                    setTimeout(function() {
                        if (r.tracker.recipient_matches.length) {
                            var e = new r.dom.compose(r.tracker.recipient_matches[0].closest("div.M9"))
                              , a = e.recipients();
                            t(e, a, r.tracker.recipient_matches),
                            r.tracker.recipient_matches = []
                        }
                    }, 100)
                }
            },
            compose: {
                class: "An",
                handler: function(e, t) {
                    (e = e.closest("div.M9")).length && t(e = new r.dom.compose(e), e.is_inline() ? 0 == e.find("input[name=subject]").val().indexOf("Fw") ? "forward" : "reply" : "compose")
                }
            }
        },
        r.tracker.custom_supported_observers && (t.merge(r.tracker.supported_observers, r.tracker.custom_supported_observers),
        t.extend(!0, r.tracker.dom_observers, r.tracker.custom_dom_observers)),
        r.tracker.dom_observer_map = {},
        t.each(r.tracker.dom_observers, function(e, a) {
            t.isArray(a.class) || (a.class = [a.class]),
            t.each(a.class, function(t, a) {
                r.tracker.dom_observer_map[a] = e
            })
        })
    }
    ,
    r.observe.register = function(e, a, o) {
        r.tracker.dom_observer_init && r.tools.error("Error: Please register all custom DOM observers before binding handlers using gmail.observe.on etc"),
        r.tracker.custom_supported_observers || (r.tracker.custom_supported_observers = [],
        r.tracker.custom_dom_observers = {});
        var n = {};
        "object" != typeof a || t.isArray(a) ? n.class = a : t.each(["class", "selector", "sub_selector", "handler"], function(e, t) {
            a[t] && (n[t] = a[t])
        }),
        r.tracker.custom_supported_observers.push(e),
        o ? (r.tracker.custom_dom_observers[o] || (r.tracker.custom_dom_observers[o] = {
            sub_observers: {}
        }),
        r.tracker.custom_dom_observers[o].sub_observers[e] = n) : r.tracker.custom_dom_observers[e] = n
    }
    ,
    r.observe.on_dom = function(e, a) {
        if (r.tracker.dom_observer_init || r.observe.initialize_dom_observers(),
        t.inArray(e, r.tracker.supported_observers) > -1) {
            if (!r.tracker.observing_dom)
                r.tracker.observing_dom = !0,
                t(window.document).bind("DOMNodeInserted", function(e) {
                    r.tools.insertion_observer(e.target, r.tracker.dom_observers, r.tracker.dom_observer_map)
                }),
                new MutationObserver(function(e) {
                    for (var a = 0; a < e.length; a++)
                        for (var o = e[a], n = o.removedNodes, i = 0; i < n.length; i++) {
                            if ("vR" == n[i].className) {
                                var s = r.tracker.dom_observer_map.vR
                                  , l = r.tracker.dom_observers.recipient_change.handler;
                                r.observe.trigger_dom(s, t(o.target), l)
                            }
                        }
                }
                ).observe(document.body, {
                    subtree: !0,
                    childList: !0
                });
            return r.observe.bind("dom", e, a),
            !0
        }
        if ("load" == e) {
            if (r.dom.inbox_content().length)
                return a();
            var o = 0
              , n = setInterval(function() {
                if (r.dom.inbox_content().length > 0)
                    return clearInterval(n),
                    a();
                ++o > 50 && (clearInterval(n),
                console.log("Failed to detect interface load in 10 seconds. Will automatically fire event in 5 further seconds."),
                setTimeout(a, 5e3))
            }, 200);
            return !0
        }
    }
    ,
    r.tools.insertion_observer = function(e, a, o, n) {
        if (r.tracker.dom_observer_map) {
            var i = (e.className || "").trim().split(/\s+/);
            i.length || i.push(""),
            t.each(i, function(n, i) {
                var s = o[i];
                if (s && r.tracker.watchdog.dom[s]) {
                    var l = t(e)
                      , c = a[s];
                    if (c.selector && !l.is(c.selector))
                        return;
                    if (c.sub_selector && (l = l.find(c.sub_selector)),
                    l.length) {
                        var d = c.handler ? c.handler : function(e, t) {
                            t(e)
                        }
                        ;
                        if (r.observe.trigger_dom(s, l, d),
                        c.sub_observers) {
                            var u = {};
                            t.each(c.sub_observers, function(e, t) {
                                u[t.class] = e
                            }),
                            l.bind("DOMNodeInserted", function(e) {
                                r.tools.insertion_observer(e.target, c.sub_observers, u, "SUB ")
                            })
                        }
                    }
                }
            })
        }
    }
    ,
    r.tools.make_request = function(e, r) {
        var a = decodeURIComponent(e.replace(/%23/g, "#-#-#"));
        return r = void 0 == typeof r || null == typeof r ? "GET" : r,
        a = encodeURI(a).replace(/#-#-#/gi, "%23"),
        t.ajax({
            type: r,
            url: a,
            async: !1
        }).responseText
    }
    ,
    r.tools.make_request_async = function(e, r, a) {
        var o = decodeURIComponent(e.replace(/%23/g, "#-#-#"));
        r = void 0 == typeof r || null == typeof r ? "GET" : r,
        o = encodeURI(o).replace(/#-#-#/gi, "%23"),
        t.ajax({
            type: r,
            url: o,
            async: !0,
            dataType: "text"
        }).done(function(e, t, r) {
            a(r.responseText)
        }).fail(function(e, t, r) {
            console.error("Request Failed", r)
        })
    }
    ,
    r.tools.parse_view_data = function(e) {
        for (var t = [], r = [], a = 0; a < e.length; a++)
            if ("tb" == e[a][0])
                for (var o = 0; o < e[a][2].length; o++)
                    r.push(e[a][2][o]);
        for (var n = 0; n < r.length; n++) {
            var i = r[n];
            t.push({
                id: i[0],
                title: i[9],
                excerpt: i[10],
                time: i[15],
                sender: i[28],
                attachment: i[13],
                labels: i[5]
            })
        }
        return t
    }
    ,
    r.helper.get.is_delegated_inbox = function() {
        return "fwd" === r.tracker.globals[17][5][0]
    }
    ,
    r.helper.get.visible_emails_pre = function(e, a) {
        var o = !1;
        void 0 === e && (e = r.get.current_page()),
        void 0 === a && (o = !0);
        var n = window.location.origin + window.location.pathname + "?ui=2&ik=" + r.tracker.ik + "&rid=" + r.tracker.rid + "&view=tl&num=120&rt=1";
        if (o ? t(".Dj:visible").find("b:first").text() ? n += "&start=" + +parseInt(t(".Dj:visible").find("b:first").text() - 1) + "&start=" + parseInt(t(".Dj:visible").find("b:first").text() - 1) : n += "&start=0" : n += "&start=" + a,
        0 == e.indexOf("label/"))
            n += "&cat=" + e.split("/")[1] + "&search=cat";
        else if (0 == e.indexOf("category/")) {
            var i = "";
            -1 != e.indexOf("forums") ? i = "group" : -1 != e.indexOf("updates") ? i = "notification" : -1 != e.indexOf("promotion") ? i = "promo" : -1 != e.indexOf("social") && (i = "social"),
            n += "&cat=^smartlabel_" + i + "&search=category"
        } else
            0 == e.indexOf("search/") ? (at = t("input[name=at]").val(),
            n += "&qs=true&q=" + e.split("/")[1] + "&at=" + at + "&search=query") : "inbox" == e ? "true" == t('div[aria-label="Social"]').attr("aria-selected") ? n += "&cat=^smartlabel_" + (i = "social") + "&search=category" : "true" == t('div[aria-label="Promotions"]').attr("aria-selected") ? n += "&cat=^smartlabel_" + (i = "promo") + "&search=category" : "true" == t('div[aria-label="Updates"]').attr("aria-selected") ? n += "&cat=^smartlabel_" + (i = "notification") + "&search=category" : "true" == t('div[aria-label="Forums"]').attr("aria-selected") ? n += "&cat=^smartlabel_" + (i = "group") + "&search=category" : n += "&search=inbox" : n += "&search=" + e;
        return n
    }
    ,
    r.helper.get.visible_emails_post = function(e) {
        var a = [];
        if (!e)
            return a;
        for (var o in e = '"use strict"; return ' + (e = e.substring(e.indexOf("["), e.length)),
        e = new Function(e),
        r.tracker.view_data = e(),
        r.tracker.view_data)
            if ("function" != typeof r.tracker.view_data[o]) {
                var n = r.tools.parse_view_data(r.tracker.view_data[o]);
                n.length > 0 && t.merge(a, n)
            }
        return a
    }
    ,
    r.get.visible_emails = function() {
        var e = r.helper.get.visible_emails_pre()
          , t = r.tools.make_request(e);
        return r.helper.get.visible_emails_post(t)
    }
    ,
    r.get.visible_emails_async = function(e) {
        var t = r.helper.get.visible_emails_pre();
        r.tools.make_request_async(t, "GET", function(t) {
            var a = r.helper.get.visible_emails_post(t);
            e(a)
        })
    }
    ,
    r.get.all_emails_async = function(e, t) {
        void 0 === t && (t = 1);
        var a = r.helper.get.visible_emails_pre(r.get.current_page(), 120 * t);
        r.tools.make_request_async(a, "GET", function(t) {
            var a = r.helper.get.visible_emails_post(t);
            e(a)
        })
    }
    ,
    r.get.selected_emails_data = function() {
        var e = [];
        if (r.check.is_inside_email())
            e.push(r.get.email_data());
        else if (t('[gh="tl"] div[role="checkbox"][aria-checked="true"]').length) {
            var a = null
              , o = r.get.visible_emails();
            t('[gh="tl"] div[role="checkbox"]').each(function(n) {
                "true" == t(this).attr("aria-checked") && (a = r.get.email_data(o[n].id),
                e.push(a))
            })
        }
        return e
    }
    ,
    r.get.current_page = function() {
        var e = window.location.hash.split("#").pop().split("?").shift() || "inbox"
          , r = null;
        return t.inArray(e, ["sent", "inbox", "starred", "drafts", "imp", "chats", "all", "spam", "trash", "settings", "label", "category", "circle", "search"]) > -1 && (r = e),
        -1 !== e.indexOf("inbox/") ? r = "email" : e.match(/\/[0-9a-f]{16,}$/gi) && (r = "email"),
        r || e
    }
    ,
    r.tools.infobox = function(e, r, a) {
        var o = t(".b8.UC");
        if (o.length > 0) {
            o.stop(!1, !0);
            var n = o.find(".vh");
            if (a ? n.html(e) : n.text(e),
            void 0 !== r) {
                var i = o.attr("style");
                o.removeAttr("style").fadeTo(r, 0, function() {
                    t(this).attr("style", i)
                })
            } else
                o.removeAttr("style")
        }
    }
    ,
    r.tools.rerender = function(e) {
        var t, r = window.location.href;
        t = -1 !== window.location.hash.indexOf("/") ? r.replace(/#.*?\//, "#/") : r.replace(/#.*/, "#"),
        window.location.replace(t),
        setTimeout(function() {
            window.location.replace(r),
            window.history.back(),
            e && e()
        }, 0)
    }
    ,
    r.tools.get_reply_to = function(e) {
        var t = void 0 != e ? e[4] : [];
        return 0 !== t.length ? r.tools.extract_email_address(t[0]) : null
    }
    ,
    r.tools.parse_email_data = function(e) {
        var a = {};
        for (var o in e) {
            var n = e[o];
            if ("cs" == n[0] && (a.thread_id = n[1],
            a.first_email = n[8][0],
            a.last_email = n[2],
            a.total_emails = n[3],
            a.total_threads = n[8],
            a.people_involved = n[15],
            a.subject = n[23]),
            "ms" == n[0]) {
                void 0 == a.threads && (a.threads = {}),
                a.threads[n[1]] = {},
                a.threads[n[1]].is_deleted = void 0 == n[13],
                a.threads[n[1]].reply_to_id = n[2],
                a.threads[n[1]].from = n[5],
                a.threads[n[1]].from_email = n[6],
                a.threads[n[1]].timestamp = n[7],
                a.threads[n[1]].datetime = n[24],
                a.threads[n[1]].attachments = n[21].split(","),
                a.threads[n[1]].subject = n[12],
                a.threads[n[1]].content_html = void 0 != n[13] ? n[13][6] : n[8],
                a.threads[n[1]].to = void 0 != n[13] ? n[13][1] : void 0 != n[37] ? n[37][1] : [],
                a.threads[n[1]].cc = void 0 != n[13] ? n[13][2] : [],
                a.threads[n[1]].bcc = void 0 != n[13] ? n[13][3] : [],
                a.threads[n[1]].reply_to = r.tools.get_reply_to(n[13]);
                try {
                    a.threads[n[1]].content_plain = void 0 != n[13] ? t(n[13][6]).text() : n[8]
                } catch (e) {
                    a.threads[n[1]].content_plain = void 0 != n[13] ? n[13][6] : n[8]
                }
            }
        }
        return a
    }
    ,
    r.helper.get.email_data_pre = function(e) {
        r.check.is_inside_email() && void 0 == e && (e = r.get.email_id());
        var t = null;
        return void 0 != e && (t = window.location.origin + window.location.pathname + "?ui=2&ik=" + r.tracker.ik + "&rid=" + r.tracker.rid + "&view=cv&th=" + e + "&msgs=&mb=0&rt=1&search=mbox"),
        t
    }
    ,
    r.helper.get.email_data_post = function(e) {
        if (!e)
            return {};
        e = '"use strict"; return ' + (e = e.substring(e.indexOf("["), e.length));
        var t = (e = new Function(e))();
        return r.tracker.email_data = t[0],
        r.tools.parse_email_data(r.tracker.email_data)
    }
    ,
    r.get.email_data = function(e) {
        var t = r.helper.get.email_data_pre(e);
        if (null != t) {
            var a = r.tools.make_request(t);
            return r.helper.get.email_data_post(a)
        }
        return {}
    }
    ,
    r.get.email_data_async = function(e, t) {
        var a = r.helper.get.email_data_pre(e);
        null != a ? r.tools.make_request_async(a, "GET", function(e) {
            var a = r.helper.get.email_data_post(e);
            t(a)
        }) : t({})
    }
    ,
    r.helper.get.email_source_pre = function(e) {
        r.check.is_inside_email() && void 0 == e && (e = r.get.email_id());
        var t = null;
        return void 0 != e && (t = window.location.origin + window.location.pathname + "?ui=2&ik=" + r.tracker.ik + "&view=om&th=" + e),
        t
    }
    ,
    r.get.email_source = function(e) {
        var t = r.helper.get.email_source_pre(e);
        return null != t ? r.tools.make_request(t) : ""
    }
    ,
    r.get.email_source_async = function(e, t) {
        var a = r.helper.get.email_source_pre(e);
        null != a ? r.tools.make_request_async(a, "GET", t) : t("")
    }
    ,
    r.get.displayed_email_data = function() {
        var e = r.get.email_data()
          , a = {};
        if (r.check.is_conversation_view()) {
            var o = (a = e).threads
              , n = a.total_threads
              , i = 0 === (window.location.hash.split("#")[1] || "").indexOf("trash");
            for (var s in o) {
                var l = o[s];
                (i ? l.is_deleted : !l.is_deleted) || (delete o[s],
                n.splice(n.indexOf(s), 1),
                a.total_emails--)
            }
        } else
            for (s in e.threads) {
                if (t(".ii.gt .a3s.aXjCH." + ("m" + s)).length > 0) {
                    l = e.threads[s];
                    a.first_email = s,
                    a.last_email = s,
                    a.subject = e.subject,
                    a.threads = {},
                    a.threads[s] = l,
                    a.total_emails = 1,
                    a.total_threads = [s],
                    a.people_involved = [],
                    a.people_involved.push([l.from, l.from_email]),
                    l.to.forEach(function(e) {
                        var t = r.tools.extract_email_address(e)
                          , o = r.tools.extract_name(e.replace(t, "")) || "";
                        a.people_involved.push([o, t])
                    });
                    break
                }
            }
        return a
    }
    ,
    r.check.is_conversation_view = function() {
        for (var e = void 0, t = r.tracker.globals[17][4][1], a = 0; a < t.length; a++) {
            var o = t[a];
            if ("bx_vmb" === o[0]) {
                e = o[1];
                break
            }
        }
        return "0" === e || void 0 === e
    }
    ,
    r.tools.extract_email_address = function(e) {
        var t = e ? e.match(/[\+a-z0-9._-]+@[a-z0-9._-]+\.[a-z0-9._-]+/gi) : void 0;
        return t ? t[0] : void 0
    }
    ,
    r.tools.extract_name = function(e) {
        var t = e ? e.match(/[a-z'._-\s]+/gi) : void 0;
        return t && t[0] ? t[0].trim() : void 0
    }
    ,
    r.tools.i18n = function(e) {
        var t;
        switch (r.get.localization()) {
        case "fr":
            t = {
                inbox: "Boîte de réception",
                drafts: "Brouillons",
                spam: "Spam",
                forums: "Forums",
                updates: "Mises à jour",
                promotions: "Promotions",
                social_updates: "Réseaux sociaux"
            };
            break;
        case "nl":
            t = {
                inbox: "Postvak IN",
                drafts: "Concepten",
                spam: "Spam",
                forums: "Forums",
                updates: "Updates",
                promotions: "Reclame",
                social_updates: "Sociaal"
            };
            break;
        case "en":
        default:
            t = {
                inbox: "Inbox",
                drafts: "Drafts",
                spam: "Spam",
                forums: "Forums",
                updates: "Updates",
                promotions: "Promotions",
                social_updates: "Social Updates"
            }
        }
        return t[e]
    }
    ,
    r.tools.add_toolbar_button = function(e, a, o) {
        var n = t(document.createElement("div"));
        n.attr("class", "G-Ni J-J5-Ji");
        var i = t(document.createElement("div"))
          , s = "T-I J-J5-Ji lS ";
        return s += void 0 != o && null != o && "" != o ? o : "T-I-ax7 ar7",
        i.attr("class", s),
        i.html(e),
        i.click(a),
        t(document.createElement("div")).attr("class", "asa"),
        n.html(i),
        r.dom.toolbar().append(n),
        n
    }
    ,
    r.tools.add_compose_button = function(e, r, a, o) {
        var n = t(document.createElement("div"))
          , i = "T-I J-J5-Ji aoO L3 ";
        return void 0 != o && (i += o),
        n.attr("class", i),
        n.html(r),
        n.click(a),
        e.find(".gU.Up  > .J-J5-Ji").append(n),
        n
    }
    ,
    r.tools.remove_modal_window = function() {
        t("#gmailJsModalBackground").remove(),
        t("#gmailJsModalWindow").remove()
    }
    ,
    r.tools.add_modal_window = function(e, a, o, n, i) {
        i = i || r.tools.remove_modal_window,
        n = n || r.tools.remove_modal_window;
        var s = t(document.createElement("div"));
        s.attr("id", "gmailJsModalBackground"),
        s.attr("class", "Kj-JD-Jh"),
        s.attr("aria-hidden", "true"),
        s.attr("style", "opacity:0.75;width:100%;height:100%;");
        var l = t(document.createElement("div"));
        l.attr("id", "gmailJsModalWindow"),
        l.attr("class", "Kj-JD"),
        l.attr("tabindex", "0"),
        l.attr("role", "alertdialog"),
        l.attr("aria-labelledby", "gmailJsModalWindowTitle"),
        l.attr("style", "left:50%;top:50%;opacity:1;");
        var c = t(document.createElement("div"));
        c.attr("class", "Kj-JD-K7 Kj-JD-K7-GIHV4");
        var d = t(document.createElement("span"));
        d.attr("id", "gmailJsModalWindowTitle"),
        d.attr("class", "Kj-JD-K7-K0"),
        d.attr("role", "heading"),
        d.html(e);
        var u = t(document.createElement("span"));
        u.attr("id", "gmailJsModalWindowClose"),
        u.attr("class", "Kj-JD-K7-Jq"),
        u.attr("role", "button"),
        u.attr("tabindex", "0"),
        u.attr("aria-label", "Close"),
        u.click(i),
        c.append(d),
        c.append(u);
        var m = t(document.createElement("div"));
        m.attr("id", "gmailJsModalWindowContent"),
        m.attr("class", "Kj-JD-Jz"),
        m.html(a);
        var _ = t(document.createElement("div"));
        _.attr("class", "Kj-JD-Jl");
        var h = t(document.createElement("button"));
        h.attr("id", "gmailJsModalWindowOk"),
        h.attr("class", "J-at1-auR J-at1-atl"),
        h.attr("name", "ok"),
        h.text("OK"),
        h.click(o);
        var f = t(document.createElement("button"));
        f.attr("id", "gmailJsModalWindowCancel"),
        f.attr("name", "cancel"),
        f.text("Cancel"),
        f.click(n),
        _.append(h),
        _.append(f),
        l.append(c),
        l.append(m),
        l.append(_),
        t(document.body).append(s),
        t(document.body).append(l);
        var p = function() {
            l.css({
                top: (t(window).height() - l.outerHeight()) / 2,
                left: (t(window).width() - l.outerWidth()) / 2
            })
        };
        p(),
        t(window).resize(p)
    }
    ,
    r.chat.is_hangouts = function() {
        if (void 0 != r.tracker.hangouts)
            return r.tracker.hangouts;
        var e = t(".dw");
        if (e.length > 1)
            throw "Figuring out is hangouts - more than one dw classes found";
        if (0 == e.length)
            throw "Figuring out is hangouts - no dw classes found";
        var a = e[0]
          , o = t(".nH.aJl.nn", a);
        return o.length > 0 ? (r.tracker.hangouts = !0,
        !0) : (o = t(".nH.nn", a)).length > 2 ? (r.tracker.hangouts = !1,
        !1) : void 0
    }
    ,
    r.dom.composes = function() {
        var e = [];
        return t("div.M9").each(function(t, a) {
            e.push(new r.dom.compose(a))
        }),
        e
    }
    ,
    r.dom.compose = function(e) {
        return (e = t(e)) && (e.hasClass("M9") || e.hasClass("AD")) || r.tools.error("api.dom.compose called with invalid element"),
        this.$el = e,
        this
    }
    ,
    t.extend(r.dom.compose.prototype, {
        id: function() {
            return this.dom("id").val()
        },
        email_id: function() {
            return this.dom("draft").val()
        },
        is_inline: function() {
            return this.$el.closest("td.Bu").length > 0
        },
        recipients: function(e) {
            "object" != typeof e && (e = {});
            var t = e.type ? "[name=" + e.type + "]" : ""
              , r = e.flat ? [] : {};
            return this.$el.find(".GS input[type=hidden]" + t).each(function(t, a) {
                e.flat ? r.push(a.value) : (r[a.name] || (r[a.name] = []),
                r[a.name].push(a.value))
            }),
            r
        },
        to: function(e) {
            return this.dom("to").val(e)
        },
        cc: function(e) {
            return this.dom("cc").val(e)
        },
        bcc: function(e) {
            return this.dom("bcc").val(e)
        },
        subject: function(e) {
            this.dom("subjectbox");
            return e && this.dom("all_subjects").val(e),
            (e = this.dom("subjectbox").val()) || this.dom("subject").val()
        },
        from: function() {
            var e = this.dom("from");
            if (e.length) {
                var t = e.val();
                if (t)
                    return gmail.tools.extract_email_address(t)
            }
            return gmail.get.user_email()
        },
        body: function(e) {
            var t = this.dom("body");
            return e && t.html(e),
            t.html()
        },
        find: function(e) {
            return this.$el.find(e)
        },
        dom: function(e) {
            if (!e)
                return this.$el;
            var t = {
                to: "textarea[name=to]",
                cc: "textarea[name=cc]",
                bcc: "textarea[name=bcc]",
                id: "input[name=composeid]",
                draft: "input[name=draft]",
                subject: "input[name=subject]",
                subjectbox: "input[name=subjectbox]",
                all_subjects: "input[name=subjectbox], input[name=subject]",
                body: "div[contenteditable=true]",
                reply: "M9",
                forward: "M9",
                from: "input[name=from]"
            };
            return t[e] || r.tools.error("Dom lookup failed. Unable to find config for '" + e + "'", t, e, t[e]),
            this.$el.find(t[e])
        }
    }),
    r.dom.email = function(e) {
        if ("string" == typeof e) {
            this.id = e;
            var a = "m" + this.id;
            this.id_element = t("div.ii.gt div.a3s.aXjCH." + a),
            e = this.id_element.closest("div.adn")
        } else
            e = t(e);
        if (e && e.hasClass("adn") || r.tools.error("api.dom.email called with invalid element/id"),
        !this.id) {
            this.id_element = e.find("div.ii.gt div.a3s.aXjCH");
            var o = this.id_element.attr("class");
            if (null != o) {
                var n = o.match(/(^|\s)m([\S]*)/);
                null !== n && (this.id = n.pop())
            }
        }
        return this.$el = e,
        this
    }
    ,
    t.extend(r.dom.email.prototype, {
        body: function(e) {
            var t = this.dom("body");
            return e && t.html(e),
            t.html()
        },
        from: function(e, t) {
            var r = this.dom("from");
            return e && r.attr("email", e),
            t && (r.attr("name", t),
            r.html(t)),
            {
                email: r.attr("email"),
                name: r.attr("name"),
                el: r
            }
        },
        to: function(e) {
            if (e) {
                t.isArray(e) || (e = [e]);
                var r = [];
                t.each(e, function(e, a) {
                    r.push(t("<span />").attr({
                        dir: "ltr",
                        email: a.email,
                        name: a.name
                    }).addClass("g2").html(a.name).wrap("<p/>").parent().html())
                }),
                this.dom("to_wrapper").html("to " + r.join(", "))
            }
            var a = new Array;
            return this.dom("to").each(function(e) {
                el = t(this),
                a.push({
                    email: el.attr("email"),
                    name: el.attr("name"),
                    el: el
                })
            }),
            a
        },
        data: function() {
            if ("object" != typeof r.dom.email_cache && (r.dom.email_cache = {}),
            !r.dom.email_cache[this.id]) {
                var e = r.get.email_data(this.id);
                t.each(e.threads, function(e, t) {
                    r.dom.email_cache[e] = t
                })
            }
            return r.dom.email_cache[this.id]
        },
        source: function() {
            return r.get.email_source(this.id)
        },
        dom: function(e) {
            if (!e)
                return this.$el;
            var t = {
                body: "div.a3s",
                from: "span[email].gD",
                to: "span[email].g2",
                to_wrapper: "span.hb",
                timestamp: "span.g3",
                star: "div.zd",
                reply_button: "div[role=button].aaq",
                menu_button: "div[role=button].aap",
                details_button: "div[role=button].ajz"
            };
            return t[e] || r.tools.error("Dom lookup failed. Unable to find config for '" + e + "'"),
            this.$el.find(t[e])
        }
    }),
    r.dom.thread = function(e) {
        return e && e.hasClass("if") || r.tools.error("api.dom.thread called with invalid element/id"),
        this.$el = e,
        this
    }
    ,
    t.extend(r.dom.thread.prototype, {
        dom: function(e) {
            if (!e)
                return this.$el;
            var t = {
                opened_email: "div.adn",
                subject: "h2.hP",
                labels: "div.hN"
            };
            return t[e] || r.tools.error("Dom lookup failed. Unable to find config for '" + e + "'"),
            this.$el.find(t[e])
        }
    }),
    r.compose.start_compose = function() {
        var e = t(".T-I.J-J5-Ji.T-I-KE.L3")[0];
        if (e) {
            var r = document.createEvent("MouseEvents");
            r.initEvent("mousedown", !0, !1),
            e.dispatchEvent(r);
            var a = document.createEvent("MouseEvents");
            return a.initEvent("mouseup", !0, !1),
            e.dispatchEvent(a),
            !0
        }
        return !1
    }
    ,
    r
};
function initalizeOnce(e) {
    var t;
    return function() {
        return e && (t = e.apply(this, arguments)),
        e = null,
        t
    }
}
window.Gmail || (window.Gmail = initalizeOnce(Gmail_));
