const LS = {
    getAllItems: () => chrome.storage.local.get(),
    getItem: async t => (await chrome.storage.local.get(t))[t],
    setItem: (t, e) => chrome.storage.local.set({
        [t]: e
    }),
    removeItems: t => chrome.storage.local.remove(t)
};
var emailsarray;
chrome.alarms.onAlarm.addListener(function(t) {
    "autovisitcontinuealarm" == t.name && autovisitcontinue()
}),
chrome.commands.onCommand.addListener(function(t) {
    "copy-emails-to-clipboard" == t && chrome.storage.local.get(function(t) {
        var e = t._saveMailList;
        if (void 0 == e || "" == e)
            e = "";
        else {
            var o = e;
            t.autosavepay || (o += "\n\nUpgrade the extension to autosave and automate your emails ID capture."),
            chrome.tabs.query({
                active: !0,
                currentWindow: !0
            }, function(e) {
                chrome.tabs.sendMessage(e[0].id, {
                    message: "copyText",
                    textToCopy: o,
                    elements: t._emailsFound
                }, function(t) {
                    chrome.runtime.lastError
                })
            })
        }
    })
}),
chrome.runtime.onMessage.addListener(function(t, e, o) {
    if ("get_bg_vars" === t.message) {
        var a = "got_bg_vars"
          , r = null;
        return t.callback && "" !== t.callback && (a = t.callback),
        t.variables && "" !== t.variables && (r = t.variables),
        LS.getAllItems().then(t => {
            chrome.runtime.sendMessage({
                message: a,
                vars: t,
                variables: r
            }, function(t) {
                chrome.runtime.lastError
            })
        }
        ),
        o(!0),
        !0
    }
    if ("counter" == t.options)
        return chrome.storage.local.get(function(t) {
            var e = 0;
            void 0 === typeof t._counter || "" === t._counter || isNaN(t._counter) || (e = t._counter),
            e += 1,
            chrome.storage.local.set({
                _counter: e
            }),
            20 != e || autosavepay || chrome.tabs.create({
                url: "https://www.manycontacts.com"
            }, function(t) {})
        }),
        o(!0),
        !0;
    if ("content" == t.from && "sendMailCount" == t.subject)
        return chrome.tabs.query({
            currentWindow: !0,
            active: !0,
            windowId: chrome.windows.WINDOW_ID_CURRENT
        }, function(e) {
            0 == t.mailCount ? extensionenabled ? (chrome.action.setBadgeText({
                text: "0"
            }),
            LS.getItem("autovisittab").then(t => {
                t >= 0 ? chrome.action.setBadgeBackgroundColor({
                    color: [0, 0, 255, 255]
                }) : chrome.action.setBadgeBackgroundColor({
                    color: [0, 0, 0, 255]
                })
            }
            )) : chrome.action.setBadgeText({
                text: ""
            }) : extensionenabled ? (chrome.action.setBadgeText({
                text: t.mailCount.toString()
            }),
            LS.getItem("autovisittab").then(t => {
                t >= 0 ? chrome.action.setBadgeBackgroundColor({
                    color: [0, 0, 255, 255]
                }) : chrome.action.setBadgeBackgroundColor({
                    color: [0, 0, 0, 255]
                })
            }
            )) : chrome.action.setBadgeText({
                text: ""
            })
        }),
        o(!0),
        !0;
    if ("content" == t.from && "sendEmails" == t.subject)
        return chrome.tabs.query({
            currentWindow: !0,
            active: !0,
            windowId: chrome.windows.WINDOW_ID_CURRENT
        }, function(e) {
            var o = t.mails
              , a = t.mailsFound
              , i = t.url;
            chrome.storage.local.set({
                _saveMailList: o,
                _emailsFound: a,
                _currentUrl: i
            })
        }),
        o(!0),
        !0;
    if ("content" == t.from && "sendLinks" == t.subject)
        return chrome.tabs.query({
            currentWindow: !0,
            active: !0,
            windowId: chrome.windows.WINDOW_ID_CURRENT
        }, function(e) {
            var o = t.links;
            chrome.storage.local.set({
                _saveLinkList: o
            })
        }),
        o(!0),
        !0;
    if ("gmailemail" === t.options)
        return o({
            status: "ok"
        }),
        !0;
    if ("information" === t.options) {
        a = "information_callback",
        r = null;
        t.callback && "" !== t.callback && (a = t.callback),
        t.variables && "" !== t.variables && (r = t.variables);
        var s = 0;
        return e.tab.id && (s = e.tab.id),
        getUserInfo(!1, function(e) {
            var o = e.useremails;
            if (t.useremail) {
                var n = !1;
                for (i = 0; i < o.length; i++)
                    t.useremail == o[i] && (n = !0);
                n || (o.push(t.useremail),
                chrome.storage.local.set({
                    useremails: JSON.stringify(o)
                }))
            }
            return s > 0 ? void chrome.tabs.sendMessage(s, {
                message: a,
                vars: e,
                variables: r
            }, function(t) {
                chrome.runtime.lastError
            }) : void chrome.runtime.sendMessage({
                message: a,
                vars: e,
                variables: r
            }, function(t) {
                chrome.runtime.lastError
            })
        }),
        o(!0),
        !0
    }
    if ("in" === t.options)
        return o(!0),
        !0;
    if ("chkautosave" === t.options)
        getUserInfo(!1, function(t) {
            sendData("autosavesubscriber", "token=" + t.localtoken + "&user=" + t.useraccount + "&usermails=" + t.useremails + "&version=" + t.version, chkpaid)
        }),
        o({
            status: "wait"
        });
    else {
        if ("changetoken" !== t.options) {
            if ("setautosave" === t.options)
                return autosaveenabled = truefalse(t.enabled),
                autosavepay = truefalse(t.pay),
                chrome.storage.local.set({
                    autosaveenabled: autosaveenabled
                }),
                chrome.storage.local.set({
                    autosavepay: autosavepay
                }),
                o(!0),
                !0;
            if ("saveautosave" == t.options)
                return autosaveenabled && t.mails.length > 0 && chrome.tabs.query({
                    currentWindow: !0,
                    active: !0,
                    windowId: chrome.windows.WINDOW_ID_CURRENT
                }, function(e) {
                    url = "",
                    void 0 !== t.url && "" !== t.url ? url = t.url : void 0 !== e[0] ? url = e[0].url : (autovisitlinks[0],
                    url = autovisitlinks[0]);
                    var o = {
                        _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                        encode: function(t) {
                            var e, a, i, r, s, n, c, l = "", u = 0;
                            for (t = o._utf8_encode(t); u < t.length; )
                                r = (e = t.charCodeAt(u++)) >> 2,
                                s = (3 & e) << 4 | (a = t.charCodeAt(u++)) >> 4,
                                n = (15 & a) << 2 | (i = t.charCodeAt(u++)) >> 6,
                                c = 63 & i,
                                isNaN(a) ? n = c = 64 : isNaN(i) && (c = 64),
                                l = l + this._keyStr.charAt(r) + this._keyStr.charAt(s) + this._keyStr.charAt(n) + this._keyStr.charAt(c);
                            return l
                        },
                        decode: function(t) {
                            var e, a, i, r, s, n, c = "", l = 0;
                            for (t = t.replace(/[^A-Za-z0-9+/=]/g, ""); l < t.length; )
                                e = this._keyStr.indexOf(t.charAt(l++)) << 2 | (r = this._keyStr.indexOf(t.charAt(l++))) >> 4,
                                a = (15 & r) << 4 | (s = this._keyStr.indexOf(t.charAt(l++))) >> 2,
                                i = (3 & s) << 6 | (n = this._keyStr.indexOf(t.charAt(l++))),
                                c += String.fromCharCode(e),
                                64 != s && (c += String.fromCharCode(a)),
                                64 != n && (c += String.fromCharCode(i));
                            return c = o._utf8_decode(c)
                        },
                        _utf8_encode: function(t) {
                            t = t.replace(/rn/g, "n");
                            for (var e = "", o = 0; o < t.length; o++) {
                                var a = t.charCodeAt(o);
                                a < 128 ? e += String.fromCharCode(a) : a > 127 && a < 2048 ? (e += String.fromCharCode(a >> 6 | 192),
                                e += String.fromCharCode(63 & a | 128)) : (e += String.fromCharCode(a >> 12 | 224),
                                e += String.fromCharCode(a >> 6 & 63 | 128),
                                e += String.fromCharCode(63 & a | 128))
                            }
                            return e
                        },
                        _utf8_decode: function(t) {
                            for (var e = "", o = 0, a = c1 = c2 = 0; o < t.length; )
                                (a = t.charCodeAt(o)) < 128 ? (e += String.fromCharCode(a),
                                o++) : a > 191 && a < 224 ? (c2 = t.charCodeAt(o + 1),
                                e += String.fromCharCode((31 & a) << 6 | 63 & c2),
                                o += 2) : (c2 = t.charCodeAt(o + 1),
                                c3 = t.charCodeAt(o + 2),
                                e += String.fromCharCode((15 & a) << 12 | (63 & c2) << 6 | 63 & c3),
                                o += 3);
                            return e
                        }
                    };
                    payload = "token=" + localtoken,
                    payload += "&source=" + o.encode(url),
                    payload += "&mails=" + JSON.stringify(t.mails),
                    sendData("autosavemails", payload, verifyaccount)
                }),
                o(!0),
                !0;
            if ("setslow" === t.options)
                return slowenabled = truefalse(t.enabled),
                chrome.storage.local.set({
                    slowenabled: slowenabled
                }),
                o(!0),
                !0;
            if ("autovisitnavigate" == t.options)
                return autovisitwindow = t.autovisitwindow,
                LS.setItem("autovisitwindow", autovisitwindow),
                autovisitlinks = t.urls,
                LS.setItem("autovisitlinks", autovisitlinks),
                autovisitlinks.length > 1e3 && (autovisitlinks.splice(1e3, autovisitlinks.length - 1e3),
                LS.setItem("autovisitlinks", autovisitlinks)),
                url = autovisitlinks[0],
                isdemo = t.isdemo,
                LS.setItem("isdemo", isdemo),
                chrome.storage.local.get("autovisittab", function(t) {
                    -1 == (autovisittab = t.autovisittab) ? (chrome.action.setBadgeBackgroundColor({
                        color: [0, 0, 255, 255]
                    }),
                    chrome.windows.update(autovisitwindow, {
                        state: "minimized"
                    }, function(t) {}),
                    chrome.tabs.create({
                        windowId: autovisitwindow,
                        url: url
                    }, function(t) {
                        autovisittab = t.id,
                        LS.setItem("autovisittab", autovisittab)
                    })) : chrome.tabs.get(autovisittab, function(t) {
                        chrome.runtime.lastError ? (chrome.action.setBadgeBackgroundColor({
                            color: [0, 0, 255, 255]
                        }),
                        chrome.windows.update(autovisitwindow, {
                            state: "minimized"
                        }, function(t) {}),
                        chrome.tabs.create({
                            windowId: autovisitwindow,
                            url: url
                        }, function(t) {
                            autovisittab = t.id,
                            LS.setItem("autovisittab", autovisittab)
                        })) : (autovisittab = t.id,
                        chrome.tabs.update(autovisittab, {
                            url: url
                        }, function() {}))
                    })
                }),
                o(!0),
                !0;
            if ("extensionenable" == t.options)
                return void 0 === t.enable ? (o({
                    status: extensionenabled
                }),
                !0) : (extensionenabled = t.enable,
                chrome.storage.local.set({
                    extensionenabled: extensionenabled
                }),
                extensionenabled ? (chrome.action.setBadgeText({
                    text: "0"
                }),
                autovisittab >= 0 ? chrome.action.setBadgeBackgroundColor({
                    color: [0, 0, 255, 255]
                }) : chrome.action.setBadgeBackgroundColor({
                    color: [0, 0, 0, 255]
                }),
                chrome.action.setIcon({
                    path: {
                        16: "icon16.png",
                        19: "icon19.png",
                        38: "icon38.png",
                        48: "icon48.png",
                        128: "icon128.png"
                    }
                }, function() {})) : (chrome.action.setBadgeText({
                    text: ""
                }),
                chrome.action.setBadgeBackgroundColor({
                    color: [0, 0, 0, 0]
                }),
                chrome.action.setIcon({
                    path: {
                        16: "icondisabled16.png",
                        19: "icondisabled19.png",
                        38: "icondisabled38.png",
                        48: "icondisabled48.png",
                        128: "icondisabled128.png"
                    }
                }, function() {})),
                o(!0),
                !0);
            if ("stats" == t.options) {
                if (void 0 !== t.data && void 0 !== t.event) {
                    url = "",
                    void 0 !== t.data.url && "" !== t.data.url && (url = t.data.url,
                    delete t.data.url);
                    var n = {
                        _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                        encode: function(t) {
                            var e, o, a, i, r, s, c, l = "", u = 0;
                            for (t = n._utf8_encode(t); u < t.length; )
                                i = (e = t.charCodeAt(u++)) >> 2,
                                r = (3 & e) << 4 | (o = t.charCodeAt(u++)) >> 4,
                                s = (15 & o) << 2 | (a = t.charCodeAt(u++)) >> 6,
                                c = 63 & a,
                                isNaN(o) ? s = c = 64 : isNaN(a) && (c = 64),
                                l = l + this._keyStr.charAt(i) + this._keyStr.charAt(r) + this._keyStr.charAt(s) + this._keyStr.charAt(c);
                            return l
                        },
                        decode: function(t) {
                            var e, o, a, i, r, s, c = "", l = 0;
                            for (t = t.replace(/[^A-Za-z0-9+/=]/g, ""); l < t.length; )
                                e = this._keyStr.indexOf(t.charAt(l++)) << 2 | (i = this._keyStr.indexOf(t.charAt(l++))) >> 4,
                                o = (15 & i) << 4 | (r = this._keyStr.indexOf(t.charAt(l++))) >> 2,
                                a = (3 & r) << 6 | (s = this._keyStr.indexOf(t.charAt(l++))),
                                c += String.fromCharCode(e),
                                64 != r && (c += String.fromCharCode(o)),
                                64 != s && (c += String.fromCharCode(a));
                            return c = n._utf8_decode(c)
                        },
                        _utf8_encode: function(t) {
                            t = t.replace(/rn/g, "n");
                            for (var e = "", o = 0; o < t.length; o++) {
                                var a = t.charCodeAt(o);
                                a < 128 ? e += String.fromCharCode(a) : a > 127 && a < 2048 ? (e += String.fromCharCode(a >> 6 | 192),
                                e += String.fromCharCode(63 & a | 128)) : (e += String.fromCharCode(a >> 12 | 224),
                                e += String.fromCharCode(a >> 6 & 63 | 128),
                                e += String.fromCharCode(63 & a | 128))
                            }
                            return e
                        },
                        _utf8_decode: function(t) {
                            for (var e = "", o = 0, a = c1 = c2 = 0; o < t.length; )
                                (a = t.charCodeAt(o)) < 128 ? (e += String.fromCharCode(a),
                                o++) : a > 191 && a < 224 ? (c2 = t.charCodeAt(o + 1),
                                e += String.fromCharCode((31 & a) << 6 | 63 & c2),
                                o += 2) : (c2 = t.charCodeAt(o + 1),
                                c3 = t.charCodeAt(o + 2),
                                e += String.fromCharCode((15 & a) << 12 | (63 & c2) << 6 | 63 & c3),
                                o += 3);
                            return e
                        }
                    };
                    return payload = "token=" + localtoken,
                    payload += "&source=" + n.encode(url),
                    payload += "&event=" + t.event,
                    "{}" !== JSON.stringify(t.data) && (payload += "&data=" + JSON.stringify(t.data)),
                    sendData("stats", payload),
                    !0
                }
                return o(!0),
                !0
            }
            return "rated" == t.options ? (chrome.storage.local.set({
                rated: !0
            }),
            chrome.storage.local.set({
                needtorate: !1
            }),
            needtorate = !1,
            o({
                status: "ok"
            }),
            !0) : (o({
                status: "ok"
            }),
            !0)
        }
        if (void 0 !== t.token) {
            var c = t.token;
            getUserInfo(!1, function(t) {
                sendData("autosavesubscriber", "token=" + c + "&user=" + t.useraccount + "&usermails=" + t.useremails + "&version=" + t.version, function(t) {
                    changetoken(t, c)
                })
            }),
            o({
                status: "wait"
            })
        }
    }
});
var mailsinfo = {}
  , version = chrome.runtime.getManifest().version;
chrome.storage.local.set({
    version: version
});
var localtoken, autovisittimer, activeTabId = 0, mailsdata = {}, stillworking = !1, useremails = [], useraccount = "", requestpayloadobject = {}, autosaveenabled = !1, autosavepay = !1, autovisitwindow = -1, autovisittab = -1, autovisitlinks = [], slowenabled = !1, isdemo = !1, demostring = '"Email","Source URL"\nhola@carlosmdh.es,https://carlosmdh.es/en/contactar/\ndev@orestbida.com,https://orestbida.com/contact/\nhanna.juergensmeier@gmx.de,https://www.horsetelex.com/horses/pedigree/118887/contact-me\nmsilvermantherapy@gmail.com,https://www.blackfemaletherapists.com/directory/listing/dr-markie-silverman/\nsupport@altkie.com,http://altkie.com/\ndlee35@avc.edu,https://www.avc.edu/administration/marketing/contact\nlearn@stanbridge.edu,https://www.stanbridge.edu/contact\ninformation@stowers.org,https://www.stowers.org/scientists/jennifer-gerton\n\n\n>>> SUBSCRIBE TO "AUTOSAVE & AUTOMATION" AND EXTRACT THOUSANDS OF EMAILS IDs IN MINUTES\n\n\nHOW AUTOMATION WORKS ?\n- You paste a list of up to 1.000 URL in the widget, and you start the automation. A new tab will open and start visiting all the URL, one at a time. All email ID\'s found in those pages will be autosaved.\n- If you close the Automation Tab, the process will stop, but you can restart the process at any time.\n- When the 1.000 URL have been processed, you can launch a new batch of 1.000 new URLs.', extensionenabled = !0, needtorate = !0;
function waittime(t) {
    var e = (new Date).getTime()
      , o = 1e3 * t;
    for (chrome.action.setBadgeBackgroundColor({
        color: [255, 0, 0, 255]
    }),
    chrome.action.setBadgeText({
        text: "zzz"
    }); (new Date).getTime() < e + o; )
        ;
    chrome.action.setBadgeBackgroundColor({
        color: [0, 0, 255, 255]
    }),
    chrome.action.setBadgeText({
        text: ""
    })
}
async function postData(t="", e={}) {
    const o = await fetch(t, {
        method: "POST",
        mode: "cors",
        cache: "no-cache",
        credentials: "omit",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        redirect: "follow",
        referrerPolicy: "no-referrer",
        body: e
    })
      , a = await o.text();
    try {
        return JSON.parse(a)
    } catch (t) {
        return a
    }
}
function sendData(t, e, o) {
    "mux" == t ? (url = "https://www.email-extractor.io/api/" + t,
    e = {
        request: e
    }) : url = "https://www.email-extractor.io/extension/" + t,
    postData(url, e).then(t => {
        "function" == typeof o && o(t)
    }
    )
}
function getRandomToken() {
    var t = new Uint8Array(32);
    crypto.getRandomValues(t);
    for (var e = "", o = 0; o < t.length; ++o)
        e += t[o].toString(16);
    return e
}
function getUserInfo(t, e) {
    void 0 === t && (t = !1),
    chrome.storage.local.get(function(o) {
        return localtoken && "" != localtoken || (void 0 === o.localtoken ? (localtoken = getRandomToken(),
        chrome.storage.local.set({
            localtoken: localtoken
        })) : localtoken = o.localtoken),
        useraccount || (void 0 === o.useraccount ? (useraccount = "",
        chrome.storage.local.set({
            useraccount: useraccount
        })) : useraccount = o.useraccount),
        useremails && 0 != useremails.length || (void 0 === o.useremails ? (useremails = [],
        chrome.storage.local.set({
            useremails: JSON.stringify(useremails)
        })) : (useremails = o.useremails,
        Array.isArray(useremails) || (useremails = JSON.parse(useremails)))),
        version && "" != version || (void 0 === o.version ? (version = chrome.runtime.getManifest().version,
        chrome.storage.local.set({
            version: version
        })) : version = o.version),
        result = t ? "token=" + localtoken + "&user=" + useraccount + "&usermails=" + JSON.stringify(useremails) + "&version=" + version : {
            localtoken: localtoken,
            useraccount: useraccount,
            useremails: useremails,
            version: version
        },
        "function" == typeof e && e(result),
        result
    })
}
function verifyaccount(t) {
    void 0 !== t.active && setpaid(t)
}
function setpaid(t) {
    t.active ? (autosavepay = !0,
    chrome.storage.local.set({
        autosavepay: !0
    })) : (autosavepay = !1,
    chrome.storage.local.set({
        autosavepay: !1
    }),
    autosaveenabled = !1,
    chrome.storage.local.set({
        autosaveenabled: !1
    }))
}
function chkpaid(t) {
    t.active ? (autosavepay = !0,
    chrome.storage.local.set({
        autosavepay: !0
    })) : chrome.tabs.create({
        url: "https://www.email-extractor.io/extension/autosave/token/" + localtoken
    }, function(t) {})
}
function changetoken(t, e) {
    t.active ? (chrome.storage.local.set({
        localtoken: e
    }),
    chrome.storage.local.set({
        autosavepay: !0
    }),
    chrome.runtime.reload()) : chrome.tabs.create({
        url: "https://www.email-extractor.io/extension/autosave/token/" + localtoken
    }, function(t) {})
}
function truefalse(t) {
    return "false" !== t && !1 !== t && ("true" === t || !0 === t || void 0)
}
chrome.storage.local.get(function(t) {
    void 0 === t.autosaveenabled ? chrome.storage.local.set({
        autosaveenabled: autosaveenabled
    }) : autosaveenabled = truefalse(t.autosaveenabled),
    void 0 === t.autosavepay ? chrome.storage.local.set({
        autosavepay: autosavepay
    }) : autosavepay = truefalse(t.autosavepay),
    void 0 === t.needtorate ? chrome.storage.local.set({
        needtorate: needtorate
    }) : needtorate = truefalse(t.needtorate),
    void 0 !== t.rated && (needtorate = !1),
    void 0 === t.slowenabled ? chrome.storage.local.set({
        slowenabled: slowenabled
    }) : slowenabled = truefalse(t.slowenabled),
    void 0 === t.useremails ? chrome.storage.local.set({
        useremails: JSON.stringify(useremails)
    }) : useremails = JSON.parse(t.useremails),
    void 0 === t.autovisitlinks ? chrome.storage.local.set({
        autovisitlinks: []
    }) : autovisitlinks = t.autovisitlinks,
    void 0 === t.autovisitwindow ? chrome.storage.local.set({
        autovisitwindow: -1
    }) : autovisitwindow = t.autovisitwindow,
    void 0 === t.autovisittab ? chrome.storage.local.set({
        autovisittab: -1
    }) : autovisittab = t.autovisittab,
    void 0 === t.extensionenabled ? chrome.storage.local.set({
        extensionenabled: !0
    }) : extensionenabled = t.extensionenabled,
    void 0 === t.stillworking ? chrome.storage.local.set({
        stillworking: !1
    }) : stillworking = t.stillworking,
    void 0 === t.isdemo ? chrome.storage.local.set({
        isdemo: !1
    }) : isdemo = t.isdemo
}),
chrome.windows.onRemoved.addListener(function(t) {
    LS.getItem("autovisitwindow").then(e => {
        e == t && (LS.setItem("autovisitwindow", -1),
        LS.setItem("autovisittab", -1))
    }
    )
}),
autovisitcontinue = function() {
    chrome.alarms.clearAll(),
    LS.getAllItems().then(t => {
        autovisitlinks = t.autovisitlinks,
        autovisitwindow = t.autovisitwindow,
        autovisittab = t.autovisittab,
        localtoken = t.localtoken,
        isdemo = t.isdemo,
        autovisitlinks.splice(0, 1),
        LS.setItem("autovisitlinks", autovisitlinks),
        autovisitlinks.length >= 1 ? (chrome.action.setBadgeBackgroundColor({
            color: [0, 0, 255, 255]
        }),
        url = autovisitlinks[0],
        url = -1 === url.indexOf("://") ? "http://" + url : url,
        chrome.tabs.get(autovisittab, function(t) {
            chrome.runtime.lastError || (autovisittab = t.id,
            chrome.tabs.update(autovisittab, {
                url: url
            }, function() {
                chrome.alarms.create("autovisitcontinuealarm", {
                    when: Date.now() + 15e3
                })
            }))
        })) : isdemo ? (isdemo = !1,
        LS.setItem("isdemo", !1),
        autovisittab > 0 && (chrome.tabs.create({
            url: "https://www.email-extractor.io/extension/autosave/token/" + localtoken
        }, function(t) {}),
        chrome.tabs.update(autovisittab, {
            url: "data:text/csv;base64," + btoa(demostring)
        }, function() {
            chrome.alarms.create("autovisitcontinuealarm", {
                when: Date.now() + 15e3
            })
        }))) : (autovisitwindow >= 0 && chrome.windows.get(autovisitwindow, function(t) {
            chrome.runtime.lastError || chrome.windows.remove(t.id, function() {
                LS.setItem("autovisittab", -1),
                LS.setItem("autovisitwindow", -1)
            })
        }),
        autovisittab = -1,
        autovisitwindow = -1,
        LS.setItem("autovisittab", -1),
        LS.setItem("autovisitwindow", -1),
        chrome.action.setBadgeBackgroundColor({
            color: [0, 0, 0, 255]
        }))
    }
    )
}
,
chrome.webNavigation.onCompleted.addListener(function(t) {
    if (0 === t.frameId) {
        t.tabId;
        LS.getAllItems().then(e => {
            t.tabId === e.autovisittab && (autovisitlinks = e.autovisitlinks,
            autovisitwindow = e.autovisitwindow,
            autovisittab = e.autovisittab,
            localtoken = e.localtoken,
            isdemo = e.isdemo,
            autovisitlinks.splice(0, 1),
            LS.setItem("autovisitlinks", autovisitlinks),
            autovisitlinks.length >= 1 ? (chrome.action.setBadgeBackgroundColor({
                color: [0, 0, 255, 255]
            }),
            chrome.alarms.clearAll(),
            url = autovisitlinks[0],
            url = -1 === url.indexOf("://") ? "http://" + url : url,
            slowenabled && waittime(5),
            chrome.tabs.update(autovisittab, {
                url: url
            }, function() {
                chrome.alarms.create("autovisitcontinuealarm", {
                    when: Date.now() + 15e3
                })
            })) : isdemo ? (isdemo = !1,
            LS.setItem("isdemo", !1),
            autovisittab > 0 && (chrome.tabs.create({
                url: "https://www.email-extractor.io/extension/autosave/token/" + localtoken
            }, function(t) {}),
            chrome.tabs.update(autovisittab, {
                url: "data:text/csv;base64," + btoa(demostring)
            }, function() {
                chrome.alarms.create("autovisitcontinuealarm", {
                    when: Date.now() + 15e3
                })
            }))) : (autovisitwindow >= 0 && chrome.windows.get(autovisitwindow, function(t) {
                chrome.runtime.lastError || chrome.windows.remove(t.id, function() {
                    LS.setItem("autovisittab", -1),
                    LS.setItem("autovisitwindow", -1)
                })
            }),
            autovisittab = -1,
            autovisitwindow = -1,
            LS.setItem("autovisittab", -1),
            LS.setItem("autovisitwindow", -1),
            chrome.action.setBadgeBackgroundColor({
                color: [0, 0, 0, 255]
            })))
        }
        )
    }
}),
chrome.webNavigation.onErrorOccurred.addListener(function(t) {
    if (0 === t.frameId) {
        t.tabId;
        LS.getAllItems().then(e => {
            t.tabId === e.autovisittab && (autovisitlinks = e.autovisitlinks,
            autovisitwindow = e.autovisitwindow,
            localtoken = e.localtoken,
            isdemo = e.isdemo,
            autovisitlinks.splice(0, 1),
            LS.setItem("autovisitlinks", autovisitlinks),
            autovisitlinks.length >= 1 ? (chrome.action.setBadgeBackgroundColor({
                color: [0, 0, 255, 255]
            }),
            chrome.alarms.clearAll(),
            url = autovisitlinks[0],
            url = -1 === url.indexOf("://") ? "http://" + url : url,
            chrome.tabs.get(autovisittab, function(t) {
                chrome.runtime.lastError || (autovisittab = t.id,
                chrome.tabs.update(autovisittab, {
                    url: url
                }, function(t) {
                    waittime(5),
                    chrome.alarms.create("autovisitcontinuealarm", {
                        when: Date.now() + 15e3
                    })
                }))
            })) : isdemo ? (isdemo = !1,
            LS.setItem("isdemo", !1),
            autovisittab > 0 && (chrome.tabs.create({
                url: "https://www.email-extractor.io/extension/autosave/token/" + localtoken
            }, function(t) {}),
            chrome.tabs.update(autovisittab, {
                url: "data:text/csv;base64," + btoa(demostring)
            }, function() {
                chrome.alarms.create("autovisitcontinuealarm", {
                    when: Date.now() + 15e3
                })
            }))) : (autovisitwindow >= 0 && chrome.windows.get(autovisitwindow, function(t) {
                chrome.runtime.lastError || chrome.windows.remove(t.id, function() {
                    LS.setItem("autovisittab", -1),
                    LS.setItem("autovisitwindow", -1)
                })
            }),
            autovisittab = -1,
            autovisitwindow = -1,
            LS.setItem("autovisittab", -1),
            LS.setItem("autovisitwindow", -1),
            chrome.action.setBadgeBackgroundColor({
                color: [0, 0, 0, 255]
            })))
        }
        )
    }
}),
getUserInfo(!1, function(t) {
    (autosaveenabled || autosavepay) && sendData("autosavesubscriber", "token=" + t.localtoken + "&user=" + t.useraccount + "&usermails=" + t.useremails + "&version=" + t.version, setpaid)
}),
chrome.runtime.onInstalled.addListener(function(t) {
    if ("install" == t.reason)
        console.log("This is a first install!"),
        chrome.storage.local.clear(function() {
            chrome.runtime.lastError
        }),
        chrome.tabs.create({
            url: "help.html"
        }, function(t) {});
    else if ("update" == t.reason) {
        var e = chrome.runtime.getManifest().version;
        console.log("Updated from " + t.previousVersion + " to " + e + "!"),
        LS.setItem("autovisitwindow", -1),
        LS.setItem("autovisittab", -1),
        t.previousVersion != e && getUserInfo(!1, function(t) {
            sendData("autosavesubscriber", "token=" + t.localtoken + "&user=" + t.useraccount + "&usermails=" + t.useremails + "&version=" + t.version, setpaid)
        })
    }
});
